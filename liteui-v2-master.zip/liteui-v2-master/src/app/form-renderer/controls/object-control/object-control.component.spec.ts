import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { TranslatePipe } from 'src/app/translate.pipe';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { By } from '@angular/platform-browser';
import { element } from 'protractor';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { ConfigService } from 'src/app/services/config.service';

import { ObjectControlComponent } from './object-control.component';

describe('ObjectControlComponent', () => {
  let component: ObjectControlComponent;
  let fixture: ComponentFixture<ObjectControlComponent>;
  let configService:ConfigService;
  let formValidatorService:FormvalidatorService;
  let pageId: '190107196208';
  let properties=
    {
      'type': 'object',
      'readonly': true,
      'hidden': false,
      'label': 'Reage History',
      'collapsible': false,
      'sectionId': 'section1',
      'order': 43,
      'fields': {
          'table2': {
              'type': 'table',
              'collapsible': false,
              'label': 'Reage History',
              'collapsed': true,
              'readonly': true,
              'showActionsColumn': false,
              'datatables': {
                  'pageLength': 10,
                  'paging': true,
                  'lengthChange': false,
                  'info': false,
                  'searching': true,
                  'ordering': false,
                  'autoWidth': false,
                  'transpose': false,
                  'showSubmitButton': true,
                  'language': {
                      'info': 'Record _START_ to _END_ of _TOTAL_'
                  },
                  'descColumn': [],
                  'actionLinks': []
              },
              'fields': {
                  '7002': {
                      'type': 'date',
                      'readonly': true,
                      'hidden': false,
                      'label': 'Prev Reage Date',
                      'name': '7002',
                      'order': 72,
                      'fieldClass': 'col-lg-4 col-md-6 col-xxl-2 col-xxl-2',
                      'messages': {
                          'pattern': ''
                      },
                      'data': [
                          '00/00/0000',
                          '00/00/0000',
                          '00/00/0000',
                          '00/00/0000',
                          '00/00/0000',
                          '00/00/0000',
                          '00/00/0000',
                          '00/00/0000'
                      ],
                      'schema': {
                          'type': 'string',
                          'format': 'date',
                          'title': 'Prev Reage Date'
                      }
                  },
                  
                  '7004': {
                      'readonly': true,
                      'hidden': false,
                      'label': 'Reage Cat Cd',
                      'name': '7004',
                      'order': 74,
                      'fieldClass': 'col-lg-4 col-md-6 col-xxl-2 col-xxl-2',
                      'messages': {
                          'pattern': ''
                      },
                      'data': [
                          ' ',
                          ' ',
                          ' ',
                          ' ',
                          ' ',
                          ' ',
                          ' ',
                          ' '
                      ],
                      'schema': {
                          'type': 'string',
                          'title': 'Reage Cat Cd',
                          'format': 'uppercase',
                          'maxLength': 2
                      },
                      'type': 'text'
                  },
                  '7005': {
                      'type': 'number',
                      'readonly': true,
                      'hidden': false,
                      'label': 'Reage Excp Flag',
                      'name': '7005',
                      'order': 75,
                      'fieldClass': 'col-lg-4 col-md-6 col-xxl-2 col-xxl-2',
                      'data': [
                          '0',
                          '0',
                          '0',
                          '0',
                          '0',
                          '0',
                          '0',
                          '0'
                      ],
                      'schema': {
                          'type': 'number',
                          'default': 0,
                          'minimum': 0,
                          'maximum': 9,
                          'title': 'Reage Excp Flag'
                      }
                  }
              },
              'name': 'table2',
              'fieldClass': 'col-12',
              'data': [
                  {
                      '7002': '00/00/0000',
                      '7003': ' ',
                      '7004': ' ',
                      '7005': '0'
                  },
                  {
                      '7002': '00/00/0000',
                      '7003': ' ',
                      '7004': ' ',
                      '7005': '0'
                  },
                  
                  {
                      '7002': '00/00/0000',
                      '7003': ' ',
                      '7004': ' ',
                      '7005': '0'
                  }
              ],
              'schema': {
                  'type': 'array',
                  'useEditableTablePlugin': true,
                  'transpose': false,
                  'linkName': '',
                  'items': {
                      'type': 'object',
                      'properties': {
                          '7002': {
                              'type': 'string',
                              'format': 'date',
                              'title': 'Prev Reage Date'
                          },
                          '7003': {
                              'type': 'string',
                              'title': 'Pmt Reaged By',
                              'format': 'uppercase',
                              'maxLength': 3
                          }
                      }
                  }
              }
          }
      },
      'name': 'object2',
      'fieldClass': 'col-12',
      'view': 'fullPage-bottom',
      'schema': {
          'type': 'object',
          'properties': {
              'table2': {
                  'type': 'array',
                  'useEditableTablePlugin': true,
                  'transpose': false,
                  'linkName': '',
                  'items': {
                      'type': 'object',
                      'properties': {
                          '7002': {
                              'type': 'string',
                              'format': 'date',
                              'title': 'Prev Reage Date'
                          },
                          
                      }
                  }
              }
          }
      }
  }
  

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ObjectControlComponent,TranslatePipe],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[FormvalidatorService,ConfigService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ObjectControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have correct value to label',()=>{
    component.updateProperties(properties,pageId);
    expect(component.label).toEqual('Reage History')
  })

  it('should showlabel has correct value',()=>{
    let showFields=[]
    component.updateProperties(properties,pageId)
    showFields = Object.keys(component.fields).map(e => {
      if (component.fields[e].type === 'table' || component.fields[e].type === 'tableMaker') {
        if (component.label === component.fields[e].label ) {
         expect(component.showLabel).toBe(false);
        }
      }
      return component.fields[e];
    });
  })

  it('should showfields have correct values',()=>{
    let showFields=[]
    component.updateProperties(properties,pageId)
    showFields = Object.keys(component.fields).map(e => {
      if (component.fields[e].type === 'table' || component.fields[e].type === 'tableMaker') {
        if (component.label === component.fields[e].label ) {
         expect(component.showLabel).toBe(false);
        }
      }
      return component.fields[e];
    });

    expect(component.showFields).toEqual(showFields);
  })

  it('should have heading',()=>{
    component.label='Some Mock Heading'
    const ref: DebugElement = fixture.debugElement;
    const heading = ref.query(By.css('#heading'));
    const displayEle: HTMLElement = heading.nativeElement
    fixture.detectChanges();
    expect(displayEle.textContent).toEqual(' Some Mock Heading ');
  })

  it('should have form when required',()=>{
    let fieldGroup = {};
    fieldGroup['4001'] = new UntypedFormControl({ value: ''} );
    component.form = new UntypedFormGroup(fieldGroup);
    fixture.detectChanges();
    let form=fixture.debugElement.query(By.css('#form'))
    expect(form).toBeTruthy();
  })


  it('should not  have heading when showAsLabel return false', () => {
    component.showLabel=false
    fixture.detectChanges();
    const ref: DebugElement = fixture.debugElement;
    const heading = ref.query(By.css('#heading'));
    expect(heading).not.toBeTruthy()
  })

 
});
