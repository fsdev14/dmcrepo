import { Component, Input, OnInit } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';

@Component({
  selector: 'app-object-control',
  templateUrl: './object-control.component.html',
  styleUrls: ['./object-control.component.css']
})
export class ObjectControlComponent implements OnInit {

  label: string;
  name: string;
  type = 'object';
  data: string;
  readonly: false;
  hidden: false;
  order: number;
  view: string;
  pattern: string;
  schema: any;
  fieldClass: string;
  sectionId: string;
  isKeyField: boolean;
  fields: {};
  showFields = [];
  form: UntypedFormGroup;
  showLabel = true;
  pageId:any;
  constructor(private formValidatorSerivce: FormvalidatorService) { }

  ngOnInit(): void {
    this.form = this.formValidatorSerivce.getFormGroup(this.pageId);
  }

  updateProperties(properties: any, pageId:any) {
    this.pageId = pageId;
    for (const ob of Object.keys(properties)) {
      this[ob] = properties[ob];
    }
    if (this.label === undefined) { this.label = this.schema.title; }
    this.showFields = Object.keys(this.fields).map(e => {
      if (this.fields[e].type === 'table' || this.fields[e].type === 'tableMaker') {
        if (this.label === this.fields[e].label ) {
          this.showLabel = false;
        }
      }
      return this.fields[e];
    });
  }

}
