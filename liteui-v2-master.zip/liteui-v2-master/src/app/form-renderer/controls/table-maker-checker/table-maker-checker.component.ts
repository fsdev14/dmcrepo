import { FormlinkService } from './../../../services/formlink.service';
import { Component, Input, OnInit, Output , EventEmitter, ChangeDetectorRef} from '@angular/core';
import { RestService } from 'src/app/services/rest.service';

@Component({
  selector: 'app-table-maker-checker',
  templateUrl: './table-maker-checker.component.html',
  styleUrls: ['./table-maker-checker.component.css']
})

export class TableMakerCheckerComponent implements OnInit {
  @Input() context: any;
  @Input() pageId: any;
  @Output() hideModelData: EventEmitter<boolean> = new EventEmitter<boolean>();
  pageContainerOptions = {showBreadcrumbs: false, hideButtons: true};
  allFields = [];
  activeSection: any;
  existData: any;
  updateData: any;
  makerCheckerModal = true;
  makerCheckerStatus = false;
  outpurResponse: any;
  constructor(private restService: RestService,
    private formlinkService: FormlinkService, 
    private cd: ChangeDetectorRef) { }

  ngOnInit(): void {
    this.existData = this.context[0];
    this.updateData = this.context[1];
    this.existData.pageData = 'makerChecker';
    this.updateData.pageData = 'makerChecker';
    this.existData.dataType = 'existData';
    this.updateData.dataType = 'updateData';
    this.formlinkService.shareData.subscribe((receiveddata) => {
    if (receiveddata.type == 'existData' || receiveddata.type == 'updateData' && receiveddata.links == undefined) {
      this.existData = '';
      this.updateData = '';
    }  
    if (receiveddata[0]?.type == 'existData') {
      this.existData = receiveddata[0];
      this.existData.pageData = 'makerChecker';
      this.existData.dataType = 'existData';
    }
    if (receiveddata[1]?.type == 'updateData') {
      this.updateData = receiveddata[1];
      this.updateData.pageData = 'makerChecker';
      this.updateData.dataType = 'updateData';
    }
    this.cd.detectChanges();
    });
  }

  hideModel(){
    this.hideModelData.emit(false);
  }

  approve(){
    const approveReq: any = {};
    approveReq.messageName =  'M.SSC.SCXMCFS.ATOM.I',
    approveReq.messageVersion =  'R00000',
    approveReq.messageMode =  '',
    approveReq['4001'] = 'Y';
    approveReq['4015'] = 'SSC.SMSCAS.ATOM';
    approveReq['4009'] = 'P';
    const mergedObject = {...approveReq, ...this.context[2]};
    this.restService
    .post(mergedObject).subscribe(res => {
      const responseData = this.restService.parse(res);
      this.makerCheckerModal = false;
      this.makerCheckerStatus = true;
      this.outpurResponse = responseData.data[5001];
	  this.cd.detectChanges();
    });
  }
  reject(){
    const rejectReq: any = {};
    rejectReq.messageName =  'M.SSC.SCXMCFS.ATOM.I',
    rejectReq.messageVersion =  'R00000',
    rejectReq.messageMode =  '',
    rejectReq['4001'] = 'N';
    rejectReq['4015'] = 'SSC.SMSCAS.ATOM';
    rejectReq['4009'] = 'P';
    const mergedObject = {...rejectReq, ...this.context[2]};
    this.restService
    .post(mergedObject).subscribe(res => {
     const responseData = this.restService.parse(res);
     this.makerCheckerModal = false;
     this.makerCheckerStatus = true;
     this.outpurResponse = responseData.data[5001];
	 this.cd.detectChanges();
    });
  }
}
