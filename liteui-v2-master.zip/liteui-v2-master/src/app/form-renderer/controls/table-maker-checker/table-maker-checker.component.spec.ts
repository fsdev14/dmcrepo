import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { SearchPipe } from 'src/app/search.pipe';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { TranslatePipe } from 'src/app/translate.pipe';
import { RouterTestingModule } from '@angular/router/testing';
import { Component, CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { RestService } from 'src/app/services/rest.service';
import { ConfigService } from 'src/app/services/config.service';
import { TableMakerCheckerComponent } from './table-maker-checker.component';
import { By } from '@angular/platform-browser';

describe('TableMakerCheckerComponent', () => {
  let component: TableMakerCheckerComponent;
  let fixture: ComponentFixture<TableMakerCheckerComponent>;
  let configService:ConfigService;
  let restService:RestService

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TableMakerCheckerComponent,SearchPipe,TranslatePipe],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA,FormvalidatorService],
      providers:[RestService,ConfigService]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TableMakerCheckerComponent);
    component = fixture.componentInstance;
    component.context=[
      {
      'adhocButtonLayer':{
          'id': 'button2501',
          'buttonName': 'Add Complete',
          'displayAsButton': true,
          'displayAsLink': false,
          'targetMessage': {
              'messageName': 'M.CMS.AMNAAS.AS.AD.ADD-ALL1',
              'messageVersion': 'R00000',
              'messageMode': 'ADD'
          },
          'keyFieldCodeMapping': [
              {
                  'parentMessageFieldCode': '4020',
                  'targetMessageFieldCode': '4020'
              },
              {
                  'parentMessageFieldCode': '4021',
                  'targetMessageFieldCode': '4021'
              }
          ],
          'fieldCodeMapping': [],
          'constants': {}
      },
      'fields':{
          'readonly': true,
          'hidden': false,
          'label': 'Last Maintenance Operator',
          'name': '0198',
          'sectionId': 'section16',
          'order': 251,
          'fieldClass': 'col-lg-4 col-md-6 col-xxl-2',
          'data': '',
          'view': 'nonkey',
          'schema': {
              'type': 'string',
              'title': 'Last Maintenance Operator',
              'format': 'uppercase',
              'maxLength': 3
          },
          'type': 'text'
      }},
      {
      'fields':{
      '4020':{
          'type': 'number',
          'readonly': false,
          'hidden': false,
          'label': ' Business Unit   ',
          'name': '4020',
          'isKeyField': true,
          'crossReference': 'CMSORG',
          'order': 2,
          'fieldClass': 'col-12',
          'data': '0',
          'schema': {
              'type': 'number',
              'required': true,
              'default': 0,
              'minimum': 0,
              'maximum': 999,
              'title': ' Business Unit   '
          }
      }
      }
    }
      ]
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('close button should call hide model method on click',()=>{
    let btn1=fixture.debugElement.query(By.css('#close'))
    const checkCall=spyOn(component,'hideModel')
    btn1.triggerEventHandler(null,'click')
    expect(checkCall).toHaveBeenCalled();
  })
  it('should have heading in case of makerchecker model have true value',()=>{
    let heading1=fixture.debugElement.query(By.css('#firstHeading'));
    expect(heading1).toBeTruthy();
  })

  it('should have page container in case of makercheckermodel have true value',()=>{
    let pageContainer=fixture.debugElement.query(By.css('#query'));
    expect(pageContainer).toBeTruthy();
  })

  it('should not have heading in case of makercheckermodel have false value',()=>{
    component.makerCheckerModal=false
    fixture.detectChanges();
    let heading1=fixture.debugElement.query(By.css('#firstHeading'));
    expect(heading1).not.toBeTruthy();
  })

  it('should not have page container in case of makercheckermodel have false value',()=>{
    component.makerCheckerModal=false
    fixture.detectChanges();
    let pageContainer=fixture.debugElement.query(By.css('#query'));
    expect(pageContainer).not.toBeTruthy();
  })

  it('should have second heading in case of makerchecker model have true value',()=>{
    let heading2=fixture.debugElement.query(By.css('#secondHeading'));
    expect(heading2).toBeTruthy();
  })

  it('should have second page container in case of makercheckermodel have true value',()=>{
    let pageContainer=fixture.debugElement.query(By.css('#update'));
    expect(pageContainer).toBeTruthy();
  })

  it('should not have second heading in case of makercheckermodel have false value',()=>{
    component.makerCheckerModal=false
    fixture.detectChanges();
    let heading2=fixture.debugElement.query(By.css('#secondHeading'));
    expect(heading2).not.toBeTruthy();
  })

  it('should not have second page container in case of makercheckermodel have false value',()=>{
    component.makerCheckerModal=false
    fixture.detectChanges();
    let pageContainer=fixture.debugElement.query(By.css('#update'));
    expect(pageContainer).not.toBeTruthy();
  })

  it('approve button should call approve  method on click in case of  makercheckermodel have true value ',()=>{
    let approve=fixture.debugElement.query(By.css('#approve'))
    const checkCall=spyOn(component,'approve')
    approve.triggerEventHandler(null,'click')
    expect(checkCall).toHaveBeenCalled();
  })

  it('reject button should call reject method on click  makercheckermodel have true value',()=>{
    let reject=fixture.debugElement.query(By.css('#reject'))
    const checkCall=spyOn(component,'reject')
    reject.triggerEventHandler(null,'click')
    expect(checkCall).toHaveBeenCalled();
  })

  it('should not have approve button in case of makercheckermodel have false value ',()=>{
    component.makerCheckerModal=false
    fixture.detectChanges();
    let approve=fixture.debugElement.query(By.css('#approve'))
    expect(approve).not.toBeTruthy();
  })

  it('should not have reject button in case of  makercheckermodel have false value',()=>{
    component.makerCheckerModal=false
    fixture.detectChanges();
    let reject=fixture.debugElement.query(By.css('#reject'))
    expect(reject).not.toBeTruthy();
  })

  it('should not have output response div in case of makercheckerstatus have false value',()=>{
    
    let output=fixture.debugElement.query(By.css('#output'))
    expect(output).not.toBeTruthy()
  })

  it('should not have ok button in case of makercheckerstatus have false value',()=>{
    let okButton=fixture.debugElement.query(By.css('#ok'))
    expect(okButton).not.toBeTruthy()
  })

  it('should  have output response div in case of makercheckerstatus have true value',()=>{
    component.makerCheckerStatus=true;
    fixture.detectChanges();
    let output=fixture.debugElement.query(By.css('#output'))
    expect(output).toBeTruthy()
  })

  it('should  have ok button in case of makercheckerstatus have true value',()=>{
    component.makerCheckerStatus=true;
    fixture.detectChanges();
    let okButton=fixture.debugElement.query(By.css('#ok'))
    expect(okButton).toBeTruthy()
  })

  it('ok button should call hidemodel method on click  makercheckerstatus have true value',()=>{
    component.makerCheckerStatus=true;
    fixture.detectChanges();
    let okButton=fixture.debugElement.query(By.css('#ok'))
    let checkCall=spyOn(component,'hideModel')
    okButton.triggerEventHandler(null,'click')
    expect(checkCall).toHaveBeenCalled();
  })








});
