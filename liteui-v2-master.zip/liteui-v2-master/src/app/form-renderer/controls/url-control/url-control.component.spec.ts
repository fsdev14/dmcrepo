import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { FormControl, FormGroup } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { By } from '@angular/platform-browser';
import { element } from 'protractor';
import { TranslatePipe } from 'src/app/translate.pipe';
import { AnyControlComponent } from '../any-control/any-control.component';

import { HttpService } from 'src/app/services/http.service';
import { ConfigService } from 'src/app/services/config.service';
import { UrlControlComponent } from './url-control.component';

describe('UrlControlComponent', () => {
  let component: UrlControlComponent;
  let fixture: ComponentFixture<UrlControlComponent>;
  let formValidatorService: FormvalidatorService;
  let httpService: HttpService;
  let router: Router;
  let configService: ConfigService;


  let properties = {
    'type': 'url',
    'hidden': false,
    'data': 'https://www.example.com',
    'view': 'fullPage-top',
    'helper': 'Testing helper',
    'name': '0484',
    'fieldClass': '',
    'readonly': false,
    'label': 'Testing Data',
    'schema': {
      'type': 'string',
      'format': 'uppercase',
      'data': 'testing',
      'title': 'Testing Data'
    }
  }

  let data =
    [{
      'type': 'url',
      'readonly': true,
      'hidden': false,
      'label': 'Business Unit',
      'name': '0484',
      'isKeyField': true,
      'crossReference': 'CMSORG',
      'order': 1,
      'fieldClass': 'col-lg-4 col-md-6 col-xxl-2 col-xxl-2',
      'data': '30',
      'view': 'key',
      'schema': {
        'type': 'number',
        'required': true,
        'default': 0,
        'minimum': 0,
        'maximum': 999,
        'title': 'Business Unit'
      }
    }
    ]

  let pageId: '1449523694';

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [UrlControlComponent, TranslatePipe],
      imports: [HttpClientTestingModule, RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, FormvalidatorService],
      providers: [ConfigService, FormvalidatorService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UrlControlComponent);
    component = fixture.componentInstance;
    formValidatorService = TestBed.inject(FormvalidatorService);
    const form = formValidatorService.buildFormGroup(pageId, data);
    component.updateProperties(properties, pageId);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have correct data value', () => {
    let data = component.data.toUpperCase();
    component.onChange();
    expect(component.data).toEqual(data);
  })

  it('should  have form', () => {
    let formDiv = fixture.debugElement.query(By.css('.form-group'))
    expect(formDiv).toBeTruthy();
  })

  it('should have correct label', () => {
    const newProperties = { ...properties, ...{ 'isKeyField': true } };
    component.updateProperties(newProperties, pageId);
    fixture.detectChanges();
    const ref: DebugElement = fixture.debugElement;
    //fixture.detectChanges();
    const helper = ref.query(By.css('#label'));
    const displayEle: HTMLElement = helper.nativeElement
    expect(displayEle.textContent).toBe('*');
  })



  it('should have input tag', () => {
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    const name = `#${component.id}`;
    component.updateProperties(properties, pageId);
    const ref: DebugElement = fixture.debugElement;
    const nameInput = ref.query(By.css(name));
    const displayEle: HTMLInputElement = nameInput.nativeElement
    fixture.detectChanges();
    expect(displayEle).toBeTruthy()
  })


  it('should have error message tag', () => {
    let errorMessage = fixture.debugElement.query(By.css('.errorMessage'))
    expect(errorMessage).toBeTruthy();
  })

  it('should render a hyperlink when readonly', () => {
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    const name = `#${component.id}`;
    properties.readonly = true;
    component.updateProperties(properties, pageId);
    const ref: DebugElement = fixture.debugElement;
    const nameInput = ref.query(By.css(name));
    const displayEle: HTMLAnchorElement = nameInput.nativeElement
    fixture.detectChanges();
    expect(displayEle).toBeTruthy()
  })

  it('should render a input in table without label', () => {
    spyOn(component, 'showAsLabel').and.returnValue(true);
    fixture.detectChanges();
    const name = `#${component.id}`;
    properties.readonly = false;
    component.updateProperties(properties, pageId);
    const ref: DebugElement = fixture.debugElement;
    const nameInput = ref.query(By.css(name));
    const displayEle: HTMLInputElement = nameInput.nativeElement
    fixture.detectChanges();
    expect(displayEle.labels).toBeFalsy()
  })

});
