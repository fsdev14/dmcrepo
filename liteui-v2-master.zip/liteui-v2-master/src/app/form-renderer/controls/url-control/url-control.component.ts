import { Component, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { last } from 'rxjs';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { RestService } from 'src/app/services/rest.service';
import { AnyControlComponent } from '../any-control/any-control.component';
import { HttpService } from 'src/app/services/http.service';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-url-control',
  templateUrl: './url-control.component.html',
  styleUrls: ['./url-control.component.css']
})
export class UrlControlComponent extends AnyControlComponent {
  resDataTitle: any;
  versionList: any;
  errMessage: any;
  errorLabel: boolean = false;
  getReportFile = {};
  constructor(private formValidatorService: FormvalidatorService, private restService: RestService, private httpService: HttpService, private router: Router, private https: HttpClient) {
    super(formValidatorService);
    this.type = 'url';
  }

  ngOnInit(): void {
    const lastRes = this.restService.getLastResponse();
    this.resDataTitle = lastRes.schema.linkName;
    if (this.resDataTitle === 'Report Locate  WSRL' && this.data !== undefined) {
      if (lastRes.data[5009]?.responseStatus === 'success') {
        this.versionList = lastRes.data[5009].fileList;
      } else if (lastRes.data[5009]?.responseStatus === 'Down') {
        this.errorLabel = true;
        this.errMessage = lastRes.data[5009].errors[0]?.error;
        console.log(this.errMessage);
      } else {
        this.errorLabel = true;
        this.errMessage = lastRes.data[5009].errors[0]?.message;
        console.log(this.errMessage);
      }
    }
  }

  pdfDownload(fileName) {
    const lastReq = this.restService.getLastRequest();
    this.getReportFile = lastReq.content;
    this.getReportFile['requestType'] = "getReportFile";
    this.getReportFile['reportFileName'] = fileName.split('.')[0];
    const lastres = this.restService.getLastResponse();
    this.getReportFile['H_context'] = lastres.data.H_context;
    this.getReportFile['H_token'] = lastres.data.H_token;
    this.restService.post(this.getReportFile)
      .subscribe(response => {
        const res = this.restService.parse(response);
        let report = res.data[5009];
        var blob = this.b64toBlob(report);
        let a = document.createElement('a');
        var url = URL.createObjectURL(blob);
        a.href = url;
        a.download = fileName;
        a.click();
        URL.revokeObjectURL(url);
        a.remove();
      });
  }

  onChange() {
    if (this.schema.format === 'uppercase') {
      this.data = this.data.toUpperCase();
    }
  }

  validate() {

  }

  public b64toBlob(b64Data) {
    let sliceSize = 512;
    var byteCharacters = atob(b64Data);
    var byteArrays = [];
    for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
      var slice = byteCharacters.slice(offset, offset + sliceSize);
      var byteNumbers = new Array(slice.length);
      for (var i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }
      var byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }

    var blob = new Blob(byteArrays);
    return blob;
  }
}