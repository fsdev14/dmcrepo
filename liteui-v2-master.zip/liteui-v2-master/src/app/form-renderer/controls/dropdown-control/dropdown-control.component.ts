import { RuleConversionService } from '../../../services/rule-conversion.service';
import { ConversionService } from 'src/app/services/conversion.service';
import { RestService } from './../../../services/rest.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { AnyControlComponent } from '../any-control/any-control.component';
import { FormlinkService } from 'src/app/services/formlink.service';
import { element } from 'protractor';

@Component({
  selector: 'app-dropdown-control',
  templateUrl: './dropdown-control.component.html',
  styleUrls: ['./dropdown-control.component.css']
})
export class DropdownControlComponent extends AnyControlComponent implements OnInit {
  public eventValue: any;
  constructor(private formValidatorService: FormvalidatorService, private router: Router, private route:ActivatedRoute,
    private formlinkService: FormlinkService, private restService: RestService, private conversionService: ConversionService, private ruleConversionService: RuleConversionService) {
      super(formValidatorService);
      this.type = 'select';

  }

  updateProperties(properties: any, pageId:any) {
    this.pageId = pageId;
    super.updateProperties(properties,pageId);

    if (this.isTableField) {
      this.controlClass = 'form-select form-select-sm';
    } else {
      this.controlClass = 'form-select';
    }
  }
  // eslint-disable-next-line @angular-eslint/no-empty-lifecycle-method
  ngOnInit(): void {
  }


  showVulnPopup(dropdownValue: any, dropdownLabel: any) {
    let isActive : boolean;
    let lastResponse = this.restService.getLastResponse();
    let splitToSections = lastResponse.options.splitToSections;
    if(splitToSections) {
      splitToSections.forEach(element => {
        if((element.sectionName.includes('03-Owner Care Need Information') && element.active == true) || (element.sectionName.includes('07-Co-owner Care Need Information') && element.active == true)) {
          isActive = true;
        }
      });
    }
    if (lastResponse.schema.linkName.includes('03-Owner Care Need Information') || lastResponse.schema.linkName.includes('07-Co-owner Care Need Information') || isActive == true) {
      this.formlinkService.openVulnPopup(dropdownValue, dropdownLabel);
    }
    else {
      return;
    }
  }

  selectChange(event) {
    this.eventValue = event;
    const dependentFields =  this.conversionService.dependencyField;
    let depenedent =  dependentFields.filter(element =>  element.includes(event.target.name));
    if(depenedent && depenedent.length){
      this.ruleConversionService.setdialogFlag(true, this.eventValue, this.pageId);
    }
  }
}
