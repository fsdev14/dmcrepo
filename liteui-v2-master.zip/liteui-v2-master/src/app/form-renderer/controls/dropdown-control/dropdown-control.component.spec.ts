import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { AnyControlComponent } from '../any-control/any-control.component';
import { Router, ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import {UntypedFormControl, UntypedFormGroup, Validators} from '@angular/forms';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { TranslatePipe } from 'src/app/translate.pipe';
import { By } from '@angular/platform-browser';
import { element } from 'protractor';
import { ConfigService } from 'src/app/services/config.service';

import { DropdownControlComponent } from './dropdown-control.component';

describe('DropdownControlComponent', () => {
  let component: DropdownControlComponent;
  let fixture: ComponentFixture<DropdownControlComponent>;
  let formvalidator:FormvalidatorService;
  let configService:ConfigService
  let properties={
    'type': 'select',
    'readonly': true,
    'hidden': false,
    'label': ' Alternate Customer Number Flag  ',
    'optionLabels': [
        ' ',
        'Send-To-Alt (A)',
        'Send-To-Both  (B)',
        'Rel-Letter (C)'
    ],
    'name': '0111',
    'removeDefaultNone': true,
    'order': 11,
    'fieldClass': 'col-lg-4 col-md-6 col-xxl-2 col-xxl-2',
    'data': '',
    'view': 'nonkey',
    'schema': {
        'type': 'string',
        'enum': [
            ' ',
            'A',
            'B',
            'C'
        ],
        'title': ' Alternate Customer Number Flag  '
    }
}
let pageId: '9109226169';
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ DropdownControlComponent,TranslatePipe],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA,FormvalidatorService],
      providers:[FormvalidatorService,ConfigService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DropdownControlComponent);
    component = fixture.componentInstance;
    let fieldGroup = {};
    fieldGroup['4001'] = new UntypedFormControl({ value: ''} );
    component.form = new UntypedFormGroup(fieldGroup);
    component.helper='xyz'
    component.isKeyField=true;
    component.data='abc'

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have correct control class value',()=>{
    component.updateProperties(properties,pageId);
    expect(component.controlClass).toEqual('form-select');
  })

  it('should  have form',()=>{
    let formDiv=fixture.debugElement.query(By.css('.form-group'))
    expect(formDiv).toBeTruthy();
  })

  it('should have anchor tag',()=>{
    let anchorTag=fixture.debugElement.query(By.css('#link'));
    expect(anchorTag).toBeTruthy();
  })

  it('should have correct heading',()=>{
    // creating reference for html element
    const ref: DebugElement = fixture.debugElement;
    const label = ref.query(By.css('#label'));
    const displayEle: HTMLElement = label.nativeElement
    fixture.detectChanges();
    expect(displayEle.textContent).toBe('* ');
  })

  it('anchor tag  should call openurl(name) method on click',()=>{
    let link=fixture.debugElement.query(By.css('#link'))
    const checkCall=spyOn(component,'openurl');
    link.triggerEventHandler('click',null);
    expect(checkCall).toHaveBeenCalled();
  })

  it('should have error message tag',()=>{
    let errorMessage=fixture.debugElement.query(By.css('.errorMessage'))
    expect(errorMessage).toBeTruthy();
  })

  it('should have input tag',()=>{
    const name = `#${properties.name}`;
    component.updateProperties(properties,pageId);
    const ref: DebugElement = fixture.debugElement;
    const selectInput = ref.query(By.css('.form-control'));
    const displayEle: HTMLElement = selectInput.nativeElement
    fixture.detectChanges();
    expect(displayEle).toBeTruthy()
  })

  it('eventValue should be changed after execution of selectChange',()=>{
    const event2={
    target:{
     name:'submit'
     }
   }
   component.selectChange(event2);
   expect(component.eventValue).toBe(event2);
 })

 it('should execute selectChange method on change in select',()=>{
   const select=fixture.nativeElement;
   const userselect:HTMLInputElement=select.querySelector('select');
   let callCheck=spyOn(component,'selectChange');
   userselect.dispatchEvent(new Event('change'));
   expect(callCheck).toHaveBeenCalled();
 })

});
