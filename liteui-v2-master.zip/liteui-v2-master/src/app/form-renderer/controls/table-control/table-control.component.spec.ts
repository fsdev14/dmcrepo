import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { TablePagePipe } from 'src/app/table-page.pipe';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { RestService } from 'src/app/services/rest.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { SearchPipe } from 'src/app/search.pipe';
import { TranslatePipe } from 'src/app/translate.pipe';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ConversionService } from 'src/app/services/conversion.service';
import { ConfigService } from 'src/app/services/config.service';
import { ExcelService } from 'src/app/services/excel.service';
import { TableControlComponent } from './table-control.component';
import { By } from '@angular/platform-browser';
import * as mockData from 'src/assets/mock/mockTableData.json';
import * as mockPageResponse from 'src/assets/mock/mockResponse.json';
import { FormGroup } from '@angular/forms';
class MockRestService extends RestService {

  data = {
    data: {
      '4728': '1',
      '4729': '7',
      '4730': '1',
      '4732': '10003',
      '4733': '23/09/2005',
      '5003': '30',
      '5004': '0001010100000000200',
      'H_processId': '',
      'H_processTaskId': '',
      'H_messageName': 'M.CMS.AMPS7AS.AS.QU.QUERY1',
      'H_hasTooltip': 'true',
      'H_currencyNod': '2',
      'H_clickedButtonConfig': '',
      'H_name': '00000ASHUBHAM',
      'H_percentageNod': '7',
      'H_clientId': '',
      'H_language': 'EN',
      'H_messageVersion': 'R00000',
      'H_correlId': '',
      'H_currencyCode': '826',
      'H_fileSet': '1',
      'H_status': 'P',
      'H_perItemNod': '3',
      'H_context': '00009851955755427',
      'object2': {
        'table2': [
          {
            '4789': '0',
            '4790': '0',
            '4791': '0',
          },
          {
            '4789': '0',
            '4790': '0',
            '4791': '0'
          },
          {
            '4789': '18',
            '4790': '0',
            '4791': '2'
          },
          {
            '4789': '0',
            '4790': '0',
            '4791': '0'
          },
          {
            '4789': '0',
            '4790': '0',
            '4791': '0'
          },
          {
            '4789': '0',
            '4790': '0',
            '4791': '0'
          },
          {
            '4789': '0',
            '4790': '0',
            '4791': '0'
          },
          {
            '4789': '0',
            '4790': '0',
            '4791': '0'
          },
          {
            '4789': '0',
            '4790': '0',
            '4791': '0'
          },
          {
            '4789': '0',
            '4790': '0',
            '4791': '0'
          },
          {
            '4789': '0',
            '4790': '0',
            '4791': '0'
          },
          {
            '4789': '0',
            '4790': '0',
            '4791': '0',
          }
        ]
      },
      'H_token': 'e5919f1d51534c76c34611806e1afe7db4f4378af07d678ecb137c6a50356df0'
    }
  }


  getLastResponse() {
    return this.data;
  }
}

describe('TableControlComponent', () => {
  let component: TableControlComponent;
  let fixture: ComponentFixture<TableControlComponent>;
  let configService: ConfigService;
  let conversionService: ConversionService;
  let formValidatorService: FormvalidatorService;
  let excelService: ExcelService;

  let mockPage = mockPageResponse;
  let mockResponse = mockPage.response;
  let pageId = mockResponse.pageId;

  let data = mockData; 
  let properties = data.table1;
  let dummyData =  [
    {
      'type': 'text',
      'hidden': true,
      'view': 'fullPage-top',
      'name': '4001',
      'fieldClass': 'col-4',
      'helper': '',
      'label': 'Field',
      'schema': {
        'type': 'string',
        'title': 'Field',
        'maximum': 998,
        'minimum': 0,
        'pattern': '',
        'maxLength': 19
      }
    }


  ]
   


  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [TableControlComponent, SearchPipe, TranslatePipe, TablePagePipe],
      imports: [HttpClientTestingModule, RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, FormvalidatorService, ConfigService, ConversionService],
      providers: [FormvalidatorService, ConfigService, ExcelService,
        {
          provide: RestService,
          useClass: MockRestService
        },
      ]
    })
      .compileComponents();

    configService = TestBed.inject(ConfigService);
    conversionService = TestBed.inject(ConversionService);
    formValidatorService = TestBed.inject(FormvalidatorService);
    fixture = TestBed.createComponent(TableControlComponent);
    component = fixture.componentInstance;
    formValidatorService.setOptions(pageId, mockResponse);
    const form = formValidatorService.buildFormGroup(pageId, dummyData); // we need this to create a FormGroup for the page. Once the FormGroup is created with that pageid, we can add other fields.
    component.updateProperties(properties, pageId);
    fixture.detectChanges();
  }));


  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have correct label', () => {
    expect(component.label).toEqual(properties.label);
  })

  it('should have correct label in case of empty label from properties', () => {
    const newProperties = { ...properties, ...{ label: 'Testing Data' } };
    component.updateProperties(newProperties, pageId);
    expect(component.label).toEqual('Testing Data')
  })

  it('should have correct field class', () => {
    expect(component.fieldClass).toEqual('col-12');
  })

  it('should have correct transpose flag value in case of false schema.transpose', () => {
    expect(component.transposeFlag).toEqual('');
  })


  it('should have correct transpose flag value in case of schema.transpose', () => {
    const newProperties = {
      ...properties, ...{
        'schema': {
          'transpose': true
        }
      }
    };
    component.updateProperties(newProperties, pageId);
    expect(component.transposeFlag).toEqual('transpose');
  })

  it('action link of data table  should not have any item', () => {
    expect(component.datatables.actionLinks[0]).toBeTruthy();
  })

  it('col count should correct', () => {
    expect(component.colCount).toBe(component.tableFields.length + 2);
  })

  it('should call buildtable rows in case of data length >0', () => {
    let callCheck = spyOn(component, 'buildCurrentPageRows');
    component.updateProperties(properties, pageId)
    expect(callCheck).toHaveBeenCalled();
  })

  it('should call buildtable rows in case of data 0 data length', () => {
    const newProperties = { ...properties, ...{ 'data': [] } };
    let callCheck = spyOn(component, 'buildCurrentPageRows');
    component.updateProperties(newProperties, pageId)
    expect(callCheck).not.toHaveBeenCalled();
  })

  it('current page number should be correct', () => {
    component.setPageTotal();
    expect(component.currentPage).toBe(1);
  })


  it('current page number should be correct in case of greater than total pages', () => {
    component.currentPage = 4
    component.setPageTotal();
    expect(component.currentPage).toBe(component.totalPages);
  })


  it('current page number should be correct in case of current page=0', () => {
    component.currentPage = 0
    component.setPageTotal();
    expect(component.currentPage).toBe(1);
  })

  it('current page should have correct value in case of 0 given to set page method', () => {
    component.setPage(0);
    expect(component.currentPage).toBe(1);
  })

  it('current page should have correct value in case of page size given to set page method', () => {
    component.setPage(20);
    expect(component.currentPage).toBe(2);
  })

  it('current page should have correct value in case of (-page size) given to set page method', () => {
    component.setPage(-20);
    expect(component.currentPage).toBe(1);
  })


  it('current page should have correct value in case of -1 given to set page method', () => {
    component.setPage(-1);
    expect(component.currentPage).toBe(component.totalPages);
  })

  it('current page should have correct value in case of current page greater than total page', () => {
    component.setPage(20);
    expect(component.currentPage).toBe(component.totalPages);
  })


  it('current page should have correct value in case of current page less than 1', () => {
    component.setPage(-20);
    expect(component.currentPage).toBe(1);
  })

  it('should return correct boolean value after execution of isButtonDisabled in case of next argument given', () => {
    expect(component.isButtonDisabled('last')).toBe(true);
  })

  it('should return correct boolean value after execution of isButtonDisabled in case of last argument given', () => {
    expect(component.isButtonDisabled('next')).toBe(true);
  })

  it('should return correct boolean value after execution of isButtonDisabled in case of prev argument given', () => {
    expect(component.isButtonDisabled('prev')).toBe(true);
  })

  it('should return correct boolean value after execution of isButtonDisabled in case of first argument given', () => {
    expect(component.isButtonDisabled('first')).toBe(true);
  })

  it('should return correct boolean value after execution of isButtonDisabled in case of argument given which is other than first,last,next,prev argument given', () => {
    expect(component.isButtonDisabled('test')).toBe(false);
  })

  it('should execute hextoASCII correctly', () => {
    expect(component.hexToASCII('')).toBe('');
    expect(component.hexToASCII(null)).toBe('');
  })

  it('should have correct heading', () => {
    // creating reference for html element
    const ref: DebugElement = fixture.debugElement;
    const heading = ref.query(By.css('#label'));
    const displayEle: HTMLElement = heading.nativeElement
    fixture.detectChanges();
    let testingLabel = ' ' + component.label + ' '
    expect(displayEle.textContent).toBe(testingLabel);
  })


  it('should have table div', () => {
    // creating reference for html element
    const ref: DebugElement = fixture.debugElement;
    const table = ref.query(By.css('.table-border'));
    const displayEle: HTMLElement = table.nativeElement
    fixture.detectChanges();
    expect(displayEle).toBeTruthy();
  })

  it('should have search input tag', () => {
    // creating reference for html element
    const ref: DebugElement = fixture.debugElement;
    const search = ref.query(By.css('#search'));
    const displayEle: HTMLElement = search.nativeElement
    fixture.detectChanges();
    expect(displayEle).toBeTruthy();
  })

  it('should have call getfilteredRows on ngModelChange by search input tag', () => {
    const ref: DebugElement = fixture.debugElement;
    const search = ref.query(By.css('#search'));
    const checkCall = spyOn(component, 'getFilteredRows');
    fixture.detectChanges();
    search.triggerEventHandler('ngModelChange', null);
    expect(checkCall).toHaveBeenCalled();
  })

  it('should have table-container tag', () => {
    const name = `#${component.id}`;
    const ref: DebugElement = fixture.debugElement;
    const container = ref.query(By.css(name));
    const displayEle: HTMLElement = container.nativeElement
    fixture.detectChanges();
    expect(displayEle).toBeTruthy()
  })

  it('should have form table element', () => {
    const name = `#${component.id}`;
    const name2 = name + '_table'
    const ref: DebugElement = fixture.debugElement;
    const formTable = ref.query(By.css(name2));
    const displayEle: HTMLElement = formTable.nativeElement
    fixture.detectChanges();
    expect(displayEle).toBeTruthy()
  })

  it('should create div for heading buttons and have actual name on it', () => {
    const testDirective = fixture.debugElement.queryAll(By.css('#collumnName'));
    expect(testDirective.length).toEqual(component.tableFields.length);
    component.tableFields.forEach((fields, index) => {
      expect(testDirective[index].nativeElement.innerHTML).toEqual(component.tableFields[index].label);
    })
  })

  it('should have correct row index', () => {
    const testDirective = fixture.debugElement.queryAll(By.css('#rowIndex'));
    expect(testDirective.length).toEqual(component.filteredRows.length);
    component.filteredRows.forEach((fields, index) => {
      let testIndex = index + 1;
      expect(testDirective[index].nativeElement.innerHTML).toEqual(testIndex.toString());
    })

  })


  it('should have app generic container', () => {
    const genericContainer = fixture.debugElement.queryAll(By.css('#app-generic'))
    expect(genericContainer).toBeTruthy();
  })

  it('app generic container should have actual data', () => {
    const testDirective = fixture.debugElement.queryAll(By.css('#app-generic'));
    //App generic container will have object for each data, so total array length  will be totla tableField*filteredrows
    expect(testDirective.length).toEqual(component.tableFields.length * component.filteredRows.length);
    let x = 0;
    for (let i = 0; i < component.filteredRows.length; i++) {
      let y = 0;
      for (let j = x; j < component.tableFields.length; j++) {
        //it will match object of each object array of app-generic to the data of filterd rows
        expect(testDirective[j].nativeElement.context).toEqual(component.filteredRows[i].fields[y]);
        x++;
        y++;
      }
    }
  })

  it('should not have "Nothing to show message in case of empty filtered rows"', () => {
    const newProperties = {}
    component.updateProperties(newProperties, pageId);
    const testDirective = fixture.debugElement.queryAll(By.css('#emptyFilterdRow'));
    expect(testDirective).toBeTruthy();
  })

  it('should not have NO descColumn in case  of empty filtered rows', () => {
    const newProperties = {}
    component.updateProperties(newProperties, pageId);
    const testDirective = fixture.debugElement.queryAll(By.css('#descColumn'));
    expect(testDirective).toBeTruthy();
  })


  it('should call scrollTable on clicking right scroll bar', () => {
    spyOn(component, 'canScrollFurther').and.returnValue(true);
    fixture.detectChanges();
    let nameInput = fixture.debugElement.query(By.css('#scrollRight'))
    const checkCall = spyOn(component, 'scrollTable');
    nameInput.triggerEventHandler('click', null);
    expect(checkCall).toHaveBeenCalled();
  })
  it('should call scrollTable on clicking left scroll bar', () => {
    spyOn(component, 'canScrollFurther').and.returnValue(true);
    fixture.detectChanges();
    let nameInput = fixture.debugElement.query(By.css('#scrollLeft'))
    const checkCall = spyOn(component, 'scrollTable');
    nameInput.triggerEventHandler('click', null);
    expect(checkCall).toHaveBeenCalled();
  })
  it('should have search param div', () => {
    component.searchParam = 'testing search data';
    fixture.detectChanges();
    const searchParam = fixture.debugElement.query(By.css('#searchParam'));
    expect(searchParam).toBeTruthy();
    let searchText = ' Showing' + ' ' + component.filteredRows.length + ' ' + 'of' + ' ' + component.data.length + ' ' + 'items. '
    expect(searchParam.nativeElement.innerHTML).toEqual(searchText);
  })

  it('should have first labeled button', () => {
    component.buildCurrentPageRows();
    component.setPageTotal(true);
    fixture.detectChanges();
    const first = fixture.debugElement.query(By.css('#first'));
    expect(first).toBeTruthy();
    const callCheck = spyOn(component, 'setPage');
    first.triggerEventHandler('click', null);
    expect(callCheck).toHaveBeenCalled();
  })

  it('should have previous labeled button', () => {
    component.buildCurrentPageRows();
    component.setPageTotal(true);
    fixture.detectChanges();
    const first = fixture.debugElement.query(By.css('#previous'));
    expect(first).toBeTruthy();
    const callCheck = spyOn(component, 'setPage');
    first.triggerEventHandler('click', null);
    expect(callCheck).toHaveBeenCalled();
  })

  it('should have next labeled button', () => {
    component.buildCurrentPageRows();
    component.setPageTotal(true);
    fixture.detectChanges();
    const first = fixture.debugElement.query(By.css('#next'));
    expect(first).toBeTruthy();
    const callCheck = spyOn(component, 'setPage');
    first.triggerEventHandler('click', null);
    expect(callCheck).toHaveBeenCalled();
  })

  it('should have last labeled button', () => {
    component.buildCurrentPageRows();
    component.setPageTotal(true);
    fixture.detectChanges();
    const first = fixture.debugElement.query(By.css('#last'));
    expect(first).toBeTruthy();
    const callCheck = spyOn(component, 'setPage');
    first.triggerEventHandler('click', null);
    expect(callCheck).toHaveBeenCalled();
  })

  it('should have input for total page', () => {
    component.buildCurrentPageRows();
    component.setPageTotal(true);
    fixture.detectChanges();
    const totalPage = fixture.debugElement.query(By.css('#totalPages'));
    expect(totalPage).toBeTruthy();
    const callCheck = spyOn(component, 'setPage');
    totalPage.triggerEventHandler('change', null);
    expect(callCheck).toHaveBeenCalled();
  })

  it('should have ng container', () => {
    component.showMakerChecker = true;
    component.mergeData = ['something'];
    fixture.detectChanges();
    console.log('table fields', component.tableFields)
    const tableMakerChecker = fixture.debugElement.query(By.css('#table-maker-checker'));
    expect(tableMakerChecker).toBeTruthy();
    const callCheck = spyOn(component, 'hideModal')
    tableMakerChecker.triggerEventHandler('hideModelData', null);
    expect(callCheck).toHaveBeenCalled();

  })

});
