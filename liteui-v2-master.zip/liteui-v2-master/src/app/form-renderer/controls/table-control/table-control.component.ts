import { Component, OnInit, Input, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { RestService } from 'src/app/services/rest.service';
import { SearchPipe } from 'src/app/search.pipe';
// import { debounceTime, distinctUntilChanged, filter, fromEvent, map, of, switchMap } from 'rxjs';
import { ConversionService } from 'src/app/services/conversion.service';
import { lastValueFrom, of } from 'rxjs';
import { SearchService } from 'src/app/services/search.service';
import { async } from '@angular/core/testing';
import { ExcelService } from 'src/app/services/excel.service';
import { AuthService } from 'src/app/auth/auth.service';
import { ErrorHandlingService } from 'src/app/services/errorHandling.service';


interface TableRowModel {
  index: number;
  fields: Array<any>;
  descColumn: string;
  buttons: Array<any>;
}

/**
 * @class TableRow
 */
export class TableRow implements TableRowModel {
  index: number;
  fields: any[] = [];
  descColumn: string;
  buttons: any[] = [];
  formValidatorSerivce: FormvalidatorService;
  pageId: string;
  /**
    *
   * @param index - index of the current TableRow
   * @param buttons - bottons added to row
   * @param descColumn - description column applicable to this TableRow
   * @param fields - row Fields
   * @param formValidator - formvalidator instance to create form fields
   */
  constructor(index, buttons, descColumn, fields, formValidator, pageId) {
    this.index = index;
    this.descColumn = descColumn;
    this.buttons = buttons;
    this.formValidatorSerivce = formValidator;
    this.mapButtons();
    this.pageId = pageId;
    this.mapRowFields(fields);
    // //console.log(`row built: ${index} `);
  }

  getFieldData(fieldCode: string): any {
    return this.fields[fieldCode].data;
  }
  mapButtons() {

  }
  /**
   *  Check if the TableRow contains a string
   * @param  searchParam - Search string to search in TableRow
   * @returns true if the string is present in either index, descColumn or any of the field Data.
   */
  containsString(searchParam: string): boolean {
    if (searchParam.length === 0) { return true; }

    if ((this.index + 1).toString().includes(searchParam)) { return true; }

    if (this.descColumn?.toLocaleLowerCase().includes(searchParam)) { return true; }

    return this.fields.map(field => field.data.toLowerCase()).join().indexOf(searchParam) > -1;
  }
  /**
   * Map context table fields into TableRow fields
   * @param fields - context table fields
   */
  private mapRowFields(fields: any): void {
    fields.forEach(item => {
      const rowField = JSON.parse(JSON.stringify(item));
      if(item.dependencies){
        if(`${item.name.split('_')[0]}_${this.index + 1}` == item.name){
         this.fields.push(rowField);
        }    
      }
      else{
       rowField.name = `${item.name}_${this.index + 1}`;
       rowField.data = item.data[this.index];
       this.fields.push(rowField);
      }  
      rowField.isTableField = true;
      this.formValidatorSerivce.addField(this.pageId, rowField);
    });
  }
}
@Component({
  selector: 'app-table-control',
  templateUrl: './table-control.component.html',
  styleUrls: ['./table-control.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TableControlComponent implements OnInit {

  constructor(private formValidatorService: FormvalidatorService, private restService: RestService,
              private conversionService: ConversionService,
              private searchService: SearchService,
              private excelService: ExcelService,
              private authService: AuthService,
              private errorHandlingService: ErrorHandlingService, 
              private cd: ChangeDetectorRef) { }
  label: string;
  name: string;
  id: string;
  type = 'table';
  data = [];
  readonly: false;
  hidden: false;
  order: number;
  view: string;
  pattern: string;
  schema: any;
  fieldClass: string;
  sectionId: string;
  searchParam = '';
  isKeyField: boolean;
  form: UntypedFormGroup;
  fields: Object = {};
  tableFields = [];
  filterTableFields = [];
  currentPage = 1;
  totalPages = 1;
  pageSize = 20;
  transposeFlag = '';
  descColumn: any;
  datatables: any;
  rowButtons: Array<any> = [];
  tableButtons: Array<any> = [];
  tableRows: Array<TableRow> = [];
  searchPipe = new SearchPipe();
  filtered = 0;
  filteredRows: Array<TableRow> = [];
  colCount: number;
  isLoading = false;
  showMakerChecker = false;
  makerApp: any;
  queryApi: any;
  updateApi: any;
  mergeData = [];
  joinData = [];
  @Input() pageId: any;
  tableContainer: HTMLElement;
  tbodyElement: HTMLElement;
  hideTable = false;
  pageOptions: any;
  clickedButton:any;
  importTable = [];
  columnTitle = [];
  showModalPopup = false;
  tableReadOnly = true;
  typeOneUser = false;
  pagesBuilt = Array<number>(); 
  searchResultIndices = Array<number>();
  fileMessage: string;
  fileType = false;
  tableEditable: boolean;

  ngOnInit(): void {
    this.tableEditable = false;
    this.form = this.formValidatorService.getFormGroup(this.pageId);
    this.pageOptions = this.formValidatorService.getOptions(this.pageId);
    for(let index in this.fields) {
      if(!this.fields[index]?.hidden && !this.fields[index].readonly) {
        this.tableEditable = true;
        break;
      }
    }
  
    this.typeOneUser = this.authService.typeOneUser;
    this.tableReadOnly = Object.values(this.fields).reduce((previousValue, currentValue) => { currentValue.readonly && previousValue }, this.tableReadOnly);
  }

  reInit(): void {
    this.rowButtons = [];
    this.tableButtons = [];
    this.tableRows = new Array<TableRow>(this.data.length);
    this.pagesBuilt = [];
  }

  updateProperties(properties: any, pageId: any) {
    this.reInit();
    this.pageId = pageId;
    this.isLoading = true;
    for (const ob of Object.keys(properties)) {
      this[ob] = properties[ob];
    }
    this.id = `f_${this.name}`;
    if (this.label === '') { this.label = this.schema.title; }
    if (this.hidden) {
      this.fieldClass = 'd-none';
    }
    if (this.schema.transpose) {
      this.transposeFlag = 'transpose';
    }
    let hiddenIndex = 0;
    this.tableFields = Object.keys(this.fields).map(e => {
      const f = this.fields[e]; 
      if (this.searchService.fieldName) {
        f.highlight = f?.label?.trim() === this.searchService.fieldName;
      }
      if( f.hidden ) {
        hiddenIndex++;
      }
      if(f.dependencies && f.data[0] == undefined){
        f.data = this.data[f.name.split('_')[1]-1][f.name.split('_')[0]];
        f.schema = this.schema.items.properties[f.name.split('_')[0]]
      }
      return f;
    });

    let tableFieldObject = {};
    for (let item in this.tableFields) {
      const objName = this.tableFields[item]['name'].split('_')[0];
      tableFieldObject[objName] = this.tableFields[item];
    }
    this.filterTableFields = [];
    for (let item in tableFieldObject) {
      this.filterTableFields.push(tableFieldObject[item]);
    }

    this.filterTableFields.sort((a,b) => a.order - b.order);
    
    if(hiddenIndex == this.tableFields.length){
      this.hideTable = true;
    }
    this.tableFields.sort((a, b) => a.order - b.order);
    this.descColumn = this.datatables.descColumn;
    const mcButtonObject = {
      label: 'Review',
      isMakerCheckerBtn: true,
      logMsg: {
        messageNameField: '5011',
        messageMode: 'QUEUE-RECORD',
        messageVersion: 'R00000',
        recordKeyField: '5012'
      },
      masterMsg: {
        messageNameField: '5011',
        messageMode: 'UPDATE',
        messageVersion: 'R00000',
        recordKeyField: '5013'
      },
      approveRejectMsg: {
        content: {
          messageName: 'M.SSC.SCXMCFS.ATOM.I',
          messageVersion: 'R00000',
          messageMode: ''
        },
        rowKeyMapping: [{
          source: '5001',
          target: '4005'
        }, {
          source: '5002',
          target: '4006'
        }, {
          source: '5003',
          target: '4007'
        }, {
          source: '5004',
          target: '4008'
        }, {
          source: '5005',
          target: '4010'
        }, {
          source: '5006',
          target: '4013'
        }, {
          source: '5007',
          target: '4014'
        }]
      }
    };
    this.makerApp = this.restService.getLastResponse();
    if (this.makerApp.data.H_messageName.includes('SCXRQFS')) {
      this.datatables.actionLinks.push(mcButtonObject);
    }
    this.datatables.actionLinks.forEach(item => {
      if (item.pageFlowFlag !== undefined) {
        this.tableButtons.push(item);
      } else {
        this.rowButtons.push(item);
      }
    });
    this.colCount = this.tableFields.length + 1;
    if (this.rowButtons.length > 0) {
      this.colCount = this.colCount + 1;
    }
    //if (this.data.length > 0) {
      this.buildCurrentPageRows();
    //}
    this.isLoading = false;


    // //console.log(`totalPages should be ready now.`);
    this.totalPages = Math.ceil((this.data.length / this.pageSize));

  }


  setPageTotal(filtered: boolean = false) {
    if (!this.filteredRows) { return; }
    this.totalPages = filtered ? Math.ceil(this.searchResultIndices.length / this.pageSize) : Math.ceil((this.data.length / this.pageSize));
    if (this.currentPage > this.totalPages) {
      this.currentPage = this.totalPages;
    }
    if (this.currentPage === 0) {
      this.currentPage = 1;
    }
  }

  getFilteredRows$() {
    return of(this.filteredRows);
  }
  getFilteredRows(changeValue: any): void {
    this.searchParam = changeValue?.toLocaleLowerCase();
    if (changeValue) {
      let startIndex = (this.currentPage - 1) * (this.pageSize);
      let rowIndex = startIndex;
      let endIndex = this.currentPage * (this.pageSize) - 1;
      if (endIndex >= this.data.length) {
        endIndex = this.data.length - 1;
      }
      
    this.searchResultIndices =  [];
     this.filteredRows = [];
     for (let index = 0; index < this.data.length; index++) {
       //console.log(Object.values(this.data[index]).join().toLocaleLowerCase());
       if ((index+1).toString().indexOf(this.searchParam) > -1
         || (this.descColumn.length > 0 && this.descColumn[index + 1].indexOf(this.searchParam) > -1)
         || Object.values(this.data[index]).join().toLocaleLowerCase().indexOf(this.searchParam) > -1) {
         this.searchResultIndices.push(index);
         if (this.tableRows[index] === undefined) {
           this.tableRows[index] = this.buildTableRowByIndex(index);
         }
         if (startIndex <= this.searchResultIndices.length - 1 && this.searchResultIndices.length -1 <= endIndex){
          this.filteredRows.push(this.tableRows[index]);
         }
       }
     }
      //console.log(this.searchResultIndices);
      //this.filteredRows = this.searchPipe.transform(this.tableRows, this.searchParam, this.currentPage, this.pageSize, this.data);
      this.setPageTotal(true);
    }else {
      this.setPage(0);
      this.setPageTotal(false);
    }
    
  }


  clickRowButton(button: any, index: number, rowFields: any) {
    const tableColData = {};
    if (button.isMakerCheckerBtn) {
      this.clickedButton = button;
      button.approveRejectMsg.rowKeyMapping.forEach(x => {
        rowFields.forEach(element => {
          if (element.name.includes(x.source)) {
            tableColData[x.target] = element.data;
          }
        });
      });
      const messageName = this.makerApp.data.object1.table1[index-1][5011];
      this.clickedButton.logMsg.messageName = messageName;
      this.clickedButton.masterMsg.messageName = messageName; 
      // eslint-disable-next-line camelcase
      this.clickedButton.logMsg.H_language = 'EN';
      // eslint-disable-next-line camelcase
      this.clickedButton.masterMsg.H_language = 'EN';
      // eslint-disable-next-line camelcase
      this.clickedButton.logMsg.H_recordKey = this.makerApp.data.object1.table1[index - 1][this.clickedButton.logMsg.recordKeyField];
      // eslint-disable-next-line camelcase
      this.clickedButton.masterMsg.H_recordKey = this.makerApp.data.object1.table1[index -1][this.clickedButton.masterMsg.recordKeyField];

      this.queryData(tableColData);
    }
    else {
      const request = { content: { messageName: '' }, linkName: '' };
      request.content = button.content;
      request.linkName = button.label;
      // report viewer
      const lastres = this.restService.lastResponse;
      if(lastres.schema.linkName === 'Report Locate  WSRL'){
        request.content['requestType'] = 'getReportVersions';
      }
      try {


        button.rowKeyMapping.forEach(item => {
          if (item.target === 'DYNAMIC') {
            const dynamicMapping = this.fields[item.source].data[index - 1];
            dynamicMapping.split(',').forEach((i) => {
              const k = i.replace(/\#/g, '').split('=');
              request.content[k[0]] = this.fields[k[1]]?.data[index - 1] || this.fields[k[1]]?.data || k[1];
            });
            return;
          }
          request.content[item.target] = (this.fields[item.source] === undefined) ? ''
            : this.formValidatorService.formattedValue(this.fields[item.source], this.form.get(`${item.source}_${index}`).value,index.toString());
        });
        button.tableKeyMapping.forEach(item => {
          request.content[item.target] = (this.pageOptions.fields[item.source] === undefined) ? ''
            : this.formValidatorService.formattedValue(this.pageOptions.fields[item.source],
              this.pageOptions.fields[item.source].data, item.source);
        });
        let messageName = request.content.messageName;
        if (messageName.indexOf('$$') >= 0) {
          const field = messageName.substring(messageName.indexOf('$$') + 2, messageName.lastIndexOf('$$'));
          messageName = messageName.replace('$$' + field + '$$', this.form.get(field + '_' + index).value);
        }
        request.content.messageName = messageName;

        this.restService.gotoPage(request);
      } catch (error) {
        this.errorHandlingService.errorHandler(error.stack,'UIERR0004');
        //console.log(error);
        this.pageOptions = this.formValidatorService.getOptions(this.pageId);
        this.pageOptions.fields.ERR1.data = 'Error occurred navigating through Table button. Please check with developer.';
      }
    }
  }
  async queryData(tableColData) {
    const data1 = await lastValueFrom( this.restService.post(this.clickedButton.logMsg));
    this.queryApi = this.conversionService.convert(this.restService.parse(data1));
    const data2 = await lastValueFrom(this.restService.post(this.clickedButton.masterMsg));
    this.mergeData = [];
    this.mergeData.push(this.queryApi);
    this.updateApi = this.conversionService.convert(this.restService.parse(data2));
    this.mergeData.push(this.updateApi);
    this.mergeData.push(tableColData);
    this.showMakerChecker = true;
    this.cd.detectChanges();
     }
  hideModal() {
    this.showMakerChecker = false;
  }
  clickPageFlowButton(button: any) {
    const request = { content: { H_pageFlowFlag: '' }, linkName: '' };
    request.content = button.content;
    request.linkName = button.label;

    button.tableKeyMapping.forEach(item => {
      // Fix to handle new table updates that are not in form yet.
      // This adds a limitation that editable fields cannot be mapped to pageflow buttons.
      const val = this.pageOptions.fields[item.source]?.data;
      if (val !== undefined) {
        request.content[item.target] = this.formValidatorService.formattedValue(this.pageOptions.fields[item.source],
          val);
      }
    });
    for (const item of Object.keys(this.form.controls)) {
      if (item.startsWith('H_') && item !== 'H_messageName') {
        request.content[item] = this.pageOptions.fields[item].data;
      }
    }
    request.content.H_pageFlowFlag = button.pageFlowFlag;
    this.restService.post(request.content).subscribe(
      response => {

        this.restService.parse(response);
        if (this.restService.getLastResponse().data === undefined) {
        } else {
          const newData = this.conversionService.convert(this.restService.getLastResponse());
          if(newData.fields.ERR1.label !== ''){
             this.formValidatorService.setOptions(this.pageId, newData);
          }
          this.reInit();
          this.pageOptions = newData;
          //this.formValidatorService.setOptions(this.pageId, newData );
          const path = newData.tableGridJsonPaths.filter(x => x.indexOf(this.name) > 0)[0]?.replace('$.', '')
            .replace('.', '.fields.').split('.');
          if (path !== undefined) {
            this.updateProperties(newData.fields[path[0]][path[1]][path[2]], this.pageId);
          } else {
            // some error occurred and the page no longer has a table.
          }
        }
        this.setPage(0);
      }
    );
    this.setPage(0);
    // this.restService.gotoPage(request);
  }

  setPage(pages: number) {
    this.isLoading = true;
    //console.log(`setPage ${pages}`, new Date());
    this.currentPage = Number(this.currentPage);
    switch (pages) {
      case 0:
        this.currentPage = 1;
        break;
      case this.pageSize:
        this.currentPage += 1;
        break;
      case -this.pageSize:
        this.currentPage -= 1;
        break;
      case -1:
        this.currentPage = this.totalPages;
        break;
    }
    if (this.currentPage > this.totalPages) {
      this.currentPage = this.totalPages;
    }
    if (this.currentPage < 1) {
      this.currentPage = 1;
    } 
    if(this.pageId) {
    let updatedTableFieldsData = this.formValidatorService.getFormDirtyValues(this.pageId);      
      for (let item in updatedTableFieldsData) {
        let objIndex:any = [item.split('_')[0], item.split('_')[1]];
        if(objIndex[1]) {
          this.tableRows[objIndex[1]-1]?.fields.forEach(row=>{
            if(row.name == item){
              row.data = updatedTableFieldsData[item]
            }
          })
        }        
      }
    }

    this.buildCurrentPageRows();
    this.isLoading = false;
    
    //console.log('set page done', new Date());
  }
  /**
   * Builds rows for the current table page. 
   * @returns 
   */
  buildCurrentPageRows() {
    
    let startIndex = (this.currentPage -1) * (this.pageSize);
    let rowIndex = startIndex;
    let endIndex = this.currentPage * (this.pageSize) - 1;
    if (endIndex >= this.data.length) {
      endIndex = this.data.length - 1;
    }
    if (this.searchParam.length > 0) {
      if (endIndex >= this.searchResultIndices.length) {
        endIndex = this.searchResultIndices.length - 1;
      }
      this.filteredRows = [];
      for (let index = startIndex; index<=endIndex; index++){
        
        this.tableRows[this.searchResultIndices[index]] && this.filteredRows.push(this.tableRows[this.searchResultIndices[index]]);
        
      }
      //console.log(this.searchParam);
      this.setPageTotal(true);
      return;
    }
    if (this.pagesBuilt.find( x => x === this.currentPage) ) {
      this.filteredRows = this.tableRows.slice(startIndex, endIndex + 1);
      this.isLoading = false;
      this.cd.detectChanges();
      return;
    }
    //console.log('building current page');
    while (rowIndex >= startIndex && rowIndex <= endIndex) {
      if (this.tableRows[rowIndex] === undefined) {
        this.tableRows[rowIndex] = this.buildTableRowByIndex(rowIndex);
      }
      rowIndex++;
    } ;
    this.pagesBuilt.push(this.currentPage);
    this.filteredRows = this.tableRows.slice(startIndex, endIndex + 1);
      
    //console.log('build done');

  }
  /**
   * Creates a new TableRow object with the supplied index
   * @param index 
   * @returns TableRow object with that index
   */
  buildTableRowByIndex(index: number ): TableRow {
    return new TableRow(index, this.rowButtons,
      this.datatables.descColumn?.length > 0 ? this.datatables.descColumn[index + 1] : null,
      this.tableFields, this.formValidatorService, this.pageId);

  }
  buildAllTableRows() {
    let index =0; 
    while (index < this.data.length) {
      if ( this.tableRows[index] === undefined) {
        this.tableRows[index] = this.buildTableRowByIndex (index);
      }
      index++;
    }
  }

  isButtonDisabled(button: string): boolean {
    switch (button) {
      case 'next':
      case 'last':
        return this.currentPage === this.totalPages;
      case 'prev':
      case 'first':
        return this.currentPage === 1;
    }
    return false;
  }
  isFetchButtonDisabled(button: any): boolean {
    let a: string[] | string;
    let disabled = false;
    switch (button.pageFlowFlag) {
      case 'F':
      case 'P':
        disabled = true;
        a = this.pageOptions.fields?.H_prevToken ?
          this.hexToASCII(this.pageOptions.fields?.H_prevToken?.data).split('')
          : '';
        // eslint: ignore
        for (let i = 0; i < a.length; i++) {
          if (a[i] !== '0') {
            disabled = false;
            break;
          }
        }
        return disabled;
      case 'N':
      case 'L':
        disabled = true;
        a = this.pageOptions.fields?.H_nextToken ?
          this.hexToASCII(this.pageOptions.fields?.H_nextToken?.data).split('')
          : '';
        // eslint: ignore
        for (let i = 0; i < a.length; i++) {
          if (a[i] !== '9') {
            disabled = false;
            break;
          }
        }
        return disabled;

      default:
        return disabled;
    }
  }

  hexToASCII(hexstring: string): string {
    if (hexstring === '' || hexstring === null) {
      return '';
    }
    return hexstring.match(/.{1,2}/g)
      .map((v) => v.substring(1))
      .join('');
  }

  /**
   * Trackby Functions
   */
  trackByfilteredRows(i, item) {
    return item.index;
  }
  trackByRowFields(i, item) {    
    return item.name;
  }

  openurl(event, name) {
    const format = this.formValidatorService.config.documentationFormat;
    if (format === 'default') {
      const message = this.form.value.H_messageName;
      const url = '#/help;message=' + message + ';name=' + name;
      this.formValidatorService.showDocs(url);
    } else {
      const message = this.formValidatorService.getOptions(this.pageId).pageName.replaceAll('/', '_');
      this.formValidatorService.showDocs(message);
    }
    event.preventDefault();
  }
  canScrollFurther(side: string): boolean {
    this.tableContainer = document.getElementById(this.id);
    const element = this.tableContainer;
    this.tbodyElement= document.getElementById(this.id + '_table');
    return side === 'left' ? element.scrollLeft > 0 || this.tbodyElement.scrollLeft > 0 : element.scrollLeft+element.clientWidth < this.tbodyElement.scrollWidth-this.tbodyElement.scrollLeft;
  
  }

  scrollTable(side: string) {
    let amount = +500;
    switch (side) {
      case 'left':
        amount = -500;
        break;
      case 'right':
        amount = +500;
        break;
    }
    if (this.transposeFlag) {
      this.tbodyElement.scrollBy({
        top: 0,
        left: amount,
        behavior: 'smooth'
      });
      return;
    }
    this.tableContainer.scrollBy({
      top: 0,
      left: amount,
      behavior: 'smooth'
    });
  }
  setWidth(item) {
    let thWidth = item.schema?.maxLength ? item.schema.maxLength * 10 : 10;
    if (item.type === 'number') {
      thWidth = item.schema.maximum?.toString().length * 10;
    }
	 if (item.type === 'currency' && !item.schema?.maxLength) { 
      thWidth = item.limit? item.limit*15 : 10;
    }
    if (item.type === 'date') {
      thWidth = 100;
    }
    if (item.type === 'select') {
      thWidth = 150;
    }
    return thWidth > 400 ? 400 + 'px' : thWidth + 'px';
  }

  exportAsXLSX():void {
    window.alert('Your request is being processed...\nTable will be available shortly.');
    this.buildAllTableRows();
    this.excelService.dataMapping(this.tableFields,'table_data');
  }
  
  onFileChange(evt: any) {
    const target: DataTransfer = <DataTransfer>(evt.target);
    if(target.files[0].type == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || target.files[0].type == 'text/csv') {  
      this.fileType = true;
      this.fileMessage = "";
      if (target.files.length !== 1) throw new Error('Cannot use multiple files');
      this.buildAllTableRows();
      const reader: FileReader = new FileReader();
      reader.onload = (e: any) => {
      
        const bstr: string = e.target.result;
        const info = <any[]>this.excelService.importFromFile(bstr);
        this.tableFields.forEach(index => {
        this.columnTitle.push(index.name);
        })
        
        const importedData = info.slice(1, info.length);
            
        this.importTable = importedData.map(arr => {
          const obj = {};
          for (let i = 0; i < this.columnTitle.length; i++) {
            const k = this.columnTitle[i];
            obj[k] = arr[i];
          }
          return <any[]>obj;
          
        });

      
      this.form.patchValue({table1: this.importTable});

      
        this.tableFields.forEach(j => {
          this.fields[j.name].data = [];
          for(let i=0; i<this.importTable.length; i++)
          {
            this.fields[j.name].data = this.fields[j.name].data.concat(this.importTable[i][j.name]);
          }
        });

  
      };
      reader.readAsBinaryString(target.files[0]);

    }
    else {
      this.fileType = false;
      this.fileMessage = "Please Select '.xlsx' or '.csv file'";
    }

  }

  triggerModalPopup() {
    this.showModalPopup = true;
  }

  closeModalPopup(){
    this.showModalPopup = false;
  }

  updateForm() {
    this.columnTitle = [];
    this.importTable = [];
    this.updateProperties(this.fields,this.pageId);
  }

}

