import { AfterViewInit, Component, ElementRef, OnChanges, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { Chart, registerables } from 'chart.js';

import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { AnyControlComponent } from '../any-control/any-control.component';

@Component({
  selector: 'app-chart-control',
  templateUrl: './chart-control.component.html',
  styleUrls: ['./chart-control.component.css']
})
export class ChartControlComponent extends AnyControlComponent implements OnInit, AfterViewInit {
  @ViewChild('aChart', { static: true }) htmlChart: ElementRef;
  properties: any;
  labelField = 'graphData1';
  datasets = [];
  colors = ['rgb(255,198,38)', 'rgb(43, 86, 129)', 'rgb(102,102,102)', 'rbg(155,155,155)',  'rgb(130,46,120)', 'rgb(102, 153, 204)' ];
  bgColors = ['rgb(255,198,38,0.2)',  'rgb(43, 86, 129,0.2)', 'rgb(102,102,102,0.2)', 'rbg(155,155,155,0.2)','rgb(130,46,120,0.2)', 'rgb(102, 153, 204, 0.2)'];

  stackedOptions = {
    scales: {
      x: {
        stacked: true
      },
      y: {
        stacked: true
      }
    }
  };
  dualAxisOptions = {
    scales: {

      'left-y-axis': {
        type: 'linear',
        position: 'left',


      },
      'right-y-axis': {
        type: 'linear',
        position: 'right',
      }

    }
  };
  chartOptions = {};
  chartType: any = 'bar';


  constructor(private formValidatorService: FormvalidatorService) { super(formValidatorService); this.type = 'grid'; }

  ngOnInit(): void {
    Chart.register(...registerables);
  }

  updateProperties(properties: any, pageId:any) {
    this.pageId = pageId;
    this.properties = properties;
    super.updateProperties(properties,pageId);
    console.log(this.properties);
    if (properties.schema.chartType === 'stacked' ) {
      this.chartType = 'bar';
      this.chartOptions = this.stackedOptions;
    } else {
      this.chartType = properties.schema.chartType;
    }

    if (properties.schema.chartType === 'dualAxis') {
      this.chartOptions = this.dualAxisOptions;
      this.chartType = 'bar';
    }
    
  }
  ngAfterViewInit() {
    // console.log('afterview init happened');
    if (this.properties) {
      // console.log('drawing chart');
      this.drawChart();
    }
  }
  drawChart(): void {
    
    const myChart = new Chart(this.htmlChart.nativeElement.getContext('2d'), {
      type: this.chartType,
      data: {
        labels: this.properties.fields[this.labelField].data,
        datasets: this.buildDataSets()
      },
      options: this.chartOptions
    });
  }

  buildDataSets(): any {
    this.datasets = [];
    let i = 0;
    const types = ['line', 'bar'];
    const yAxisId = ['right-y-axis', 'left-y-axis'];
    for (const field of Object.keys(this.properties.fields)) {
      const x = this.properties.fields[field];
      if (x.name !== this.labelField) {
        if (this.properties.schema.chartType === 'dualAxis') {
          this.datasets.push({
            label: x.label,
            data: this.processData(x),
            borderColor: this.colors[i] || 'rgb(108,108,158)',
            backgroundColor: this.bgColors[i] || 'rgb(108,108,158, 0.2)',
            tension: 0.1,
            borderWidth: 2,
            type: types[i % 2],
            yAxisID: yAxisId[i % 2]
          });
        } else  {
          this.datasets.push({
            label: x.label,
            data: this.processData(x),
            borderColor: this.colors[i] || 'rgb(108,108,158)',
            backgroundColor: this.bgColors[i] || 'rgb(108,108,158, 0.2)',
            tension: 0.1,
            borderWidth: 2,

          });
        }
        
        i++;
      }
    }

    return this.datasets;
  }

  processData(field: any): any {
    if (field.type === 'currency') {
       const newData = [];
       field.data.forEach(x => {
         newData.push(x.replace(field.prefix, '').replace(field.suffix, '')
         .replace(field.thousandSeparator, '').replace(field.centSeparator, '.'));
       });
      //  console.log(newData);
       return newData;
    }
    return field.data;
  }

}
