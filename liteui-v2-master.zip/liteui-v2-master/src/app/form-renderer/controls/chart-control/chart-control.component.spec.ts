import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { ConfigService } from 'src/app/services/config.service';
import { TranslatePipe } from 'src/app/translate.pipe';

import { ChartControlComponent } from './chart-control.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';

describe('ChartControlComponent', () => {
  let component: ChartControlComponent;
  let fixture: ComponentFixture<ChartControlComponent>;
  let formValidatorService:FormvalidatorService;
  let configService:ConfigService;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChartControlComponent,TranslatePipe ],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      providers:[FormvalidatorService,ConfigService]
      
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChartControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
