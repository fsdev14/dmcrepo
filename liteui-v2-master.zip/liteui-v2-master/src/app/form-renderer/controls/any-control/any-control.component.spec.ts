import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TranslatePipe } from 'src/app/translate.pipe';
import { By } from '@angular/platform-browser';
import { element } from 'protractor';
import { ConfigService } from 'src/app/services/config.service';
import { AnyControlComponent } from './any-control.component';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';

describe('AnyControlComponent', () => {
  let component: AnyControlComponent;
  let fixture: ComponentFixture<AnyControlComponent>;
  let formvalidator:FormvalidatorService;
  let configService:ConfigService

  let properties={
    'type': 'text',
    'hidden': true,
    'view': 'fullPage-top',
    'name': '4001',
    'fieldClass': 'col-4',
    'helper':'',
    'label': 'Field',
    'schema': {
        'type': 'string',
        'title': 'Field',
        'maximum':998,
        'minimum':0,
        'pattern':'',
        'maxLength':19
    }
}
let data = [
  {
    'type': 'text',
    'hidden': true,
    'view': 'fullPage-top',
    'name': '4001',
    'fieldClass': 'col-4',
    'helper': '',
    'label': 'Field',
    'schema': {
      'type': 'string',
      'title': 'Field',
      'maximum': 998,
      'minimum': 0,
      'pattern': '',
      'maxLength': 19
    }
}
  

  ]
let pageId: '4315921897'

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AnyControlComponent,TranslatePipe],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA,FormvalidatorService],
      providers:[FormvalidatorService,ConfigService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnyControlComponent);
    component = fixture.componentInstance;
    formvalidator=TestBed.inject(FormvalidatorService);
    const form = formvalidator.buildFormGroup(pageId, data );
    component.updateProperties(properties, pageId);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('label should have correct value',()=>{
    component.updateProperties(properties,pageId)
    expect(component.label).toEqual(properties.schema.title);
  })

  it('fieldclass should have correct value',()=>{
    component.updateProperties(properties,pageId)
    expect(component.fieldClass).toEqual('d-none')
  })

  it('contol class should have correct value',()=>{
    component.updateProperties(properties,pageId);
    expect(component.controlClass).toEqual('form-control');
  })

  it('tooltip should have correct value',()=>{
    component.updateProperties(properties,pageId);
    expect(component.tooltip).toEqual(component.data);
  })

  it('showaslabel should return correct vallue',()=>{
    component.showAsLabel();
    expect(component.showAsLabel()).toEqual(false);
  })

  it('should  have form',()=>{
    let formDiv=fixture.debugElement.query(By.css('.form-group'))
    expect(formDiv).toBeTruthy();
  })

  it('should have anchor tag',()=>{
    let anchorTag=fixture.debugElement.query(By.css('#link'));
    expect(anchorTag).toBeTruthy();
  })

  it('should have correct helper',()=>{
    // creating reference for html element
    const ref: DebugElement = fixture.debugElement;
    
    const properties= {
      'type': 'text',
      'hidden': true,
      'view': 'fullPage-top',
      'name': '4001',
      'fieldClass': 'col-4',
      'helper':'sample help',
      'label': 'Field',
      'schema': {
          'type': 'string',
          'title': '',
          'maximum':998,
          'minimum':0,
          'pattern':'',
          'maxLength':19
      }};
    component.updateProperties(properties, pageId);
    fixture.detectChanges();
    const helper = ref.query(By.css('#helper'));
    const displayEle: HTMLElement = helper.nativeElement
    
    expect(displayEle.textContent).toBe(component.helper);
  })

  it('should have correct heading',()=>{
    // creating reference for html element
    const ref: DebugElement = fixture.debugElement;
    const newProperties = { ...properties, ...{'isKeyField':true} };
    component.updateProperties(newProperties,pageId);
    fixture.detectChanges();
    const label = ref.query(By.css('#label'));
    const displayEle: HTMLElement = label.nativeElement
    
    expect(displayEle.textContent).toBe('*');
  })

  it('should have value for minimum',()=>{

    component.updateProperties(properties,pageId);
    expect(component.validators[0]).toBeTruthy();
  })

  it('should have value for maximum',()=>{
    component.updateProperties(properties,pageId);
    expect(component.validators[1]).toBeTruthy();
  })

  it('should have value for pattern',()=>{
    component.updateProperties(properties,pageId);
    expect(component.validators[2]).toBeTruthy();
  })

  it('should have value for maxlength',()=>{
    component.updateProperties(properties,pageId);
    expect(component.validators[3]).toBeTruthy();
  })

  it('should have input tag',()=>{
    const name = `#${component.id}`;
    component.updateProperties(properties,pageId);
    const ref: DebugElement = fixture.debugElement;
   
    //debugger;
    const label = ref.query(By.css(name));
    const displayEle: HTMLInputElement = label.nativeElement
    fixture.detectChanges();
    expect(displayEle).toBeTruthy()
  })



  it('anchor tag  should call openurl(name) method on click',()=>{
    let link=fixture.debugElement.query(By.css('#link'))
    const checkCall=spyOn(component,'openurl');
    link.triggerEventHandler('click',null);
    expect(checkCall).toHaveBeenCalled();
  })

   it('control class should be "form-control form-control-sm focus in case of table field and ischangefield true',()=>{
    const newProperties = { ...properties, ...{'isChangedField':{},'isTableField':{}} };
    component.updateProperties(newProperties,pageId);
    fixture.detectChanges();
    expect(component.controlClass).toBe('form-control form-control-sm focus');
  })

  it('control class should be "form-control focus in case of no table field and ischangefield true',()=>{
    const newProperties = { ...properties, ...{'isChangedField':true} };
    component.updateProperties(newProperties,pageId);
    fixture.detectChanges();
    expect(component.controlClass).toBe('form-control  focus');
  })
});
