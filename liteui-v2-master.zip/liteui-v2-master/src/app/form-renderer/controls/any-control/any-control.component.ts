import { Component, Input } from '@angular/core';
import { AbstractControl, AbstractControlDirective, ControlContainer, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { MaskingPipe } from 'src/app/masking.pipe';
import { ConfigService } from 'src/app/services/config.service';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DocumentationService } from 'src/app/services/documentation.service';

@Component({
  selector: 'app-any-control',
  templateUrl: './any-control.component.html',
  styleUrls: ['./any-control.component.css']
})
export class AnyControlComponent {
  label: string;
  name = 'H_context';
  id = 'H_context';
  type = 'any';
  data: string;
  readonly: false;
  hidden: false;
  order: number;
  view: string;
  pattern: string;
  schema: any;
  fieldClass: string;
  controlClass = 'form-control';
  classList: Array<string>;
  sectionId: string;
  optionLabels: Array<string>;
  defaultSchema: { 'type': 'string' };
  isKeyField: boolean;
  required: false;
  isTableField: false;
  isChangedField:false;
  helper: string;
  tooltip: string;
  crossReference: string;
  validators: any = [];
  errorMessage = '';
  mask = '';
  pageId:any;
  form: UntypedFormGroup;
  control: AbstractControlDirective | AbstractControl;
  hasError = false;
  highlight = false;

  maskingPipe: MaskingPipe;
  get isValid() { return this.form.controls[this.name].valid; }

  constructor(private formValidatorSerivce: FormvalidatorService) {
   
  }

  updateProperties(properties: any, pageId:any) {
    this.pageId = pageId;
    for (const ob of Object.keys(properties)) {
      this[ob] = properties[ob];
    }
    this.id = `f_${this.name}`;
    if (this.label === '') { this.label = this.schema.title; }
    if (this.hidden) {
      this.fieldClass = 'd-none';
    }
    this.required = this.schema?.required;
    
    if(this.hidden && this.isKeyField && this.required){
      this.schema.required = false;
    }
    else{
      if (this.required) {
        this.validators.push(Validators.required);
      }
  
      if (this.schema.minimum !== undefined) {
        this.validators.push(Validators.min(this.schema.minimum));
      }
  
      if (this.schema.maximum !== undefined) {
        this.validators.push(Validators.max(this.schema.maximum));
      }
  
      if (this.schema.pattern !== undefined) {
        this.validators.push(Validators.pattern(this.schema.pattern));
      }
      if (this.schema.maxLength !== undefined) {
        this.validators.push(Validators.maxLength(this.schema?.maxLength));
      }
    }


    if (this.isTableField) {
      this.controlClass = 'form-control form-control-sm';
    }

    if(this.isTableField && this.isChangedField){
      this.controlClass = 'form-control form-control-sm focus';
    }

    if(!this.isTableField && this.isChangedField){
      this.controlClass = 'form-control  focus';
    }
    
    this.form = this.formValidatorSerivce.getFormGroup(this.pageId);
    if(this.form){
      this.control = this.form.get(this.name);
      if (this.validators.length > 0) {
        this.control.setValidators(Validators.compose(this.validators));
      }
      this.control.setValue(properties.data); 
      this.form.updateValueAndValidity();
    }

    if(this.isTableField){
      this.tooltip = `${this.data} - ${this.helper}`;
    } else {
      this.tooltip = this.data;
    }
    
  }

  validate() {

  }

  
  showAsLabel(): boolean {
    if (this.isTableField && this.readonly) {
      return true;
    }
    return false;
  }
  onChange(value: string) {
    const ctrl = this.form.get(this.name) as UntypedFormControl;
    ctrl.setValue(this.maskingPipe.transform(value, this.name), { emitEvent: false, emitViewToModelChange: false });
    this.form.updateValueAndValidity();
  }


  openurl(event: MouseEvent) {
    const format = this.formValidatorSerivce.config.documentationFormat;
    if (format === 'default') {
      const message = this.form.value.H_messageName;
       let name = this.name;

       if(name.indexOf('_') > -1){
      
      name = name.split('_')[0];
      
       }
      const url = '#/help;message=' + message + ';name=' + name;
      this.formValidatorSerivce.showDocs(url);
    } else {
      const message = this.formValidatorSerivce.getOptions(this.pageId).pageName.replaceAll('/', '_');
      this.formValidatorSerivce.showDocs(message);
    }
    event.preventDefault();
   
  }



}
