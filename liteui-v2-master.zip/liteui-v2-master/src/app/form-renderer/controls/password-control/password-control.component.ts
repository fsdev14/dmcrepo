import { Component, OnInit, SimpleChanges} from '@angular/core';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { FormControl, FormGroup } from '@angular/forms';
import { AnyControlComponent } from '../any-control/any-control.component';
import { ConfigService } from 'src/app/services/config.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-password-control',
  templateUrl: './password-control.component.html',
  styleUrls: ['./password-control.component.css']
})
export class PasswordControlComponent extends AnyControlComponent {

  constructor(formValidatorService: FormvalidatorService) {
    super(formValidatorService);
    this.type= 'password';
  }

  ngOnInit(): void {

  }
  updateProperties(properties: any, pageId:any) {
    this.pageId = pageId;
     super.updateProperties(properties,pageId);
  } 


}




