import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormControl, FormGroup } from '@angular/forms';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { TranslatePipe } from 'src/app/translate.pipe';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { By } from '@angular/platform-browser';
import { element } from 'protractor';
import { ConfigService } from 'src/app/services/config.service';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';

import { PasswordControlComponent } from './password-control.component';

describe('PasswordControlComponent', () => {
  let component: PasswordControlComponent;
  let fixture: ComponentFixture<PasswordControlComponent>;
  let  formValidatorService:FormvalidatorService;
  let configService:ConfigService;

  let properties={
    'type': 'password',
    'hidden': true,
    'data':'Testing Data',
    'view': 'fullPage-top',
    'helper':'Testing helper',
    'name': '0484',
    'fieldClass': '',
    'label': '',
    'schema': {
        'type': 'string',
        'format':'uppercase',
        'data':'testing',
        'title': ''
    }
  }

  let data=
  [{
    'type': 'password',
    'readonly': true,
    'hidden': false,
    'label': 'Business Unit',
    'name': '0484',
    'isKeyField': true,
    'crossReference': 'CMSORG',
    'order': 1,
    'fieldClass': 'col-lg-4 col-md-6 col-xxl-2 col-xxl-2',
    'data': '30',
    'view': 'key',
    'schema': {
        'type': 'number',
        'required': true,
        'default': 0,
        'minimum': 0,
        'maximum': 999,
        'title': 'Business Unit'
    }
  }
]

  let pageId: '1449523694';

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ PasswordControlComponent ],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA,FormvalidatorService],
      providers:[ConfigService,FormvalidatorService]
    })
    .compileComponents();
  }));

   beforeEach(() => {
    fixture = TestBed.createComponent(PasswordControlComponent);
    component = fixture.componentInstance;
    formValidatorService=TestBed.inject(FormvalidatorService);
    const form = formValidatorService.buildFormGroup(pageId, data );
    component.updateProperties(properties, pageId);
    fixture.detectChanges();
  }); 

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should  have form',()=>{
    let formDiv=fixture.debugElement.query(By.css('.form-group'))
    expect(formDiv).toBeTruthy();
  })
  
  it('should have data element', () => {
    spyOn(component, 'showAsLabel').and.returnValue(true);
    fixture.detectChanges();
    let data = fixture.debugElement.query(By.css('#data'));
    expect(data).toBeTruthy();
  })

  it('should not have data element', () => {
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let data = fixture.debugElement.query(By.css('#data'));
    expect(data).toBe(null);
  })


  it('should have correct data', () => {
    spyOn(component, 'showAsLabel').and.returnValue(true);
    fixture.detectChanges();
    const ref: DebugElement = fixture.debugElement;
    const label = ref.query(By.css('#data'));
    const displayEle: HTMLElement = label.nativeElement
    let dataText=' '+component.data+' ';
    expect(displayEle.textContent).toBe(dataText);
  })

  it('should have correct heading',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    const newProperties = { ...properties, ...{'isKeyField':true} };
    component.updateProperties(newProperties,pageId);
    fixture.detectChanges();
    const ref: DebugElement = fixture.debugElement;
    //fixture.detectChanges();
    const helper = ref.query(By.css('#label'));
    const displayEle: HTMLElement = helper.nativeElement  
    expect(displayEle.textContent).toBe('*');
  })


  it('should have anchor tag',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let anchorTag=fixture.debugElement.query(By.css('#link'));
    expect(anchorTag).toBeTruthy();
  })

  it('anchor tag  should call openurl(name) method on click',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let link=fixture.debugElement.query(By.css('#link'))
    const checkCall=spyOn(component,'openurl');
    link.triggerEventHandler('click',null);
    expect(checkCall).toHaveBeenCalled();
  })

  it('should have error message tag',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let errorMessage=fixture.debugElement.query(By.css('.errorMessage'))
    expect(errorMessage).toBeTruthy();
  })

  it('should have input tag',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    const name = `#${properties.name}`;
    component.updateProperties(properties,pageId);
    const ref: DebugElement = fixture.debugElement;
    const nameInput = ref.query(By.css('.form-control'));
    const displayEle: HTMLElement = nameInput.nativeElement
    fixture.detectChanges();
    expect(displayEle).toBeTruthy()
  })


  it('should have correct helper',()=>{
    // creating reference for html element
    const ref: DebugElement = fixture.debugElement;
    const newProperties = { ...properties, ...{'helper':'sample help'} };
    component.updateProperties(newProperties,pageId);
    fixture.detectChanges();
    const helper = ref.query(By.css('#helper'));
    const displayEle: HTMLElement = helper.nativeElement   
    expect(displayEle.textContent).toBe(component.helper);
  })


  it('Input tag  should call onChange on ngModelChange',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let nameInput=fixture.debugElement.query(By.css('.form-control'))
    const checkCall=spyOn(component,'onChange');
    nameInput.triggerEventHandler('ngModelChange',null);
    expect(checkCall).toHaveBeenCalled();
  })

  it('should not  have  data when showAsLabel return false', () => {
    spyOn(component, 'showAsLabel').and.returnValue(false);
    component.data='xyz'
    fixture.detectChanges();
    const ref: DebugElement = fixture.debugElement;
    const label = ref.query(By.css('#data'));
    expect(label).not.toBeTruthy()
  })

  it('should not  have  heading when showAsLebel return true',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(true);
    fixture.detectChanges();
    const newProperties = { ...properties, ...{'isKeyField':true} };
    component.updateProperties(newProperties,pageId);
    fixture.detectChanges();
    const ref: DebugElement = fixture.debugElement;
    //fixture.detectChanges();
    const helper = ref.query(By.css('#label')); 
    expect(helper).not.toBeTruthy();
  })


});
