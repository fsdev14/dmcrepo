import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-generic-control',
  templateUrl: './generic-control.component.html',
  styleUrls: ['./generic-control.component.css']
})
export class GenericControlComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
