import { RuleConversionService } from '../../../services/rule-conversion.service';
import { ConversionService } from 'src/app/services/conversion.service';
import { Component, Input, OnInit } from '@angular/core';
import { UntypedFormControl, FormGroup } from '@angular/forms';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { AnyControlComponent } from '../any-control/any-control.component';

@Component({
  selector: 'app-number-control',
  templateUrl: './number-control.component.html',
  styleUrls: ['./number-control.component.css']
})
export class NumberControlComponent extends AnyControlComponent implements OnInit {
  public openDialog = false;
  public eventValue: any;
  constructor(private formValidatorService: FormvalidatorService, private conversionService: ConversionService,
    private ruleConversionService: RuleConversionService ) {
    super(formValidatorService);  this.type = 'number'; }

  ngOnInit(): void {
  }
  onChange(event: any) {
    if (event.target.value === '') {
      (this.control as UntypedFormControl).setValue(0);
    }
    (this.control as UntypedFormControl).setValue(BigInt(event.target.value).toString());
   // super.onChange(event);
   this.eventValue = event;
   const dependentFields =  this.conversionService.dependencyField;
   if(dependentFields.includes(event.target.name)){
     this.ruleConversionService.setdialogFlag(true, this.eventValue, this.pageId);
   }
  }

  numberOnly(event: KeyboardEvent): boolean {

    const specialKeys = ['Delete', 'Backspace', 'Shift', 'Control', 'Tab', 'ArrowLeft', 'ArrowRight'];
    const controlKeys = 'cvyzCVYZ';
    /* Special Keys are always allowed. And Ctrl+C Ctrl+V */
    if (specialKeys.indexOf(event.key) >= 0 || (controlKeys.indexOf(event.key) >= 0 && event.ctrlKey)
    ) {
      return true;
    }

    /* Only Number keys are allowed and +/- */
    const keys = '01234567890+-.';
    if (keys.indexOf(event.key) >= 0 ) {
      return true;
    }

    return false;

  }
}
