import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { FormControl, FormGroup, FormsModule, Validators } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TranslatePipe } from 'src/app/translate.pipe';
import { By } from '@angular/platform-browser';

import { NumberControlComponent } from './number-control.component';
import { ConfigService } from 'src/app/services/config.service';

describe('NumberControlComponent', () => {
  let component: NumberControlComponent;
  let fixture: ComponentFixture<NumberControlComponent>;
  let formValidatorSerivce:FormvalidatorService;
  let configService:ConfigService;

  let properties={
    'type': 'label',
    'hidden': true,
    'data':'Testing Data',
    'view': 'fullPage-top',
    'helper':'Testing helper',
    'name': '0484',
    'fieldClass': '',
    'label': '',
    'schema': {
        'type': 'string',
        'title': ''
    }
  }

  let data=
  [{
    'type': 'number',
    'readonly': true,
    'hidden': false,
    'label': 'Business Unit',
    'name': '0484',
    'isKeyField': true,
    'crossReference': 'CMSORG',
    'order': 1,
    'fieldClass': 'col-lg-4 col-md-6 col-xxl-2 col-xxl-2',
    'data': '30',
    'view': 'key',
    'schema': {
        'type': 'number',
        'required': true,
        'default': 0,
        'minimum': 0,
        'maximum': 999,
        'title': 'Business Unit'
    }
  }
]

  let pageId: '1449523694';

  const mockEvent: Event = <Event><any>{
    target: {
        value: 42      
    }
  };

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ NumberControlComponent,TranslatePipe ],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA,FormvalidatorService],
      providers:[FormvalidatorService,ConfigService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NumberControlComponent);
    component = fixture.componentInstance;
    formValidatorSerivce=TestBed.inject(FormvalidatorService);
    const form = formValidatorSerivce.buildFormGroup(pageId, data );
    component.updateProperties(properties, pageId);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should execute Onchange Event and have correct control value',()=>{
    component.onChange(mockEvent);
    expect(component.control.value).toBe('42');
  })

  it('should execute Onchange Event and have 0 control value',()=>{
    const mockEvent2: Event = <Event><any>{
      target: {
          value:'' 
      }
    };
    component.onChange(mockEvent2);
    expect(component.control.value).toBe('0');
  })

  it('numberonly method should return correctly',()=>{
    const keyEvent = new KeyboardEvent('keydown', { key: 'Backspace' });
    expect(component.numberOnly(keyEvent)).toBe(true);
  })

  it('numberonly method should return correctly on keys',()=>{
    const keyEvent = new KeyboardEvent('keydown', { key: '7' });
    expect(component.numberOnly(keyEvent)).toBe(true);
  })

  it('numberonly method should return correctly on no keyboard event',()=>{
    const keyEvent = new KeyboardEvent('keydown', { key: '#'});
    expect(component.numberOnly(keyEvent)).toBe(false);
  })

  it('should  have form',()=>{
    let formDiv=fixture.debugElement.query(By.css('.form-group'))
    expect(formDiv).toBeTruthy();
  })
  
  it('should have data element', () => {
    spyOn(component, 'showAsLabel').and.returnValue(true);
    fixture.detectChanges();
    let data = fixture.debugElement.query(By.css('#data'));
    expect(data).toBeTruthy();
  })

  it('should not have data element', () => {
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let data = fixture.debugElement.query(By.css('#data'));
    expect(data).toBe(null);
  })


  it('should have correct data', () => {
    spyOn(component, 'showAsLabel').and.returnValue(true);
    fixture.detectChanges();
    const ref: DebugElement = fixture.debugElement;
    const label = ref.query(By.css('#data'));
    const displayEle: HTMLElement = label.nativeElement
    let dataText=' '+component.data+' ';
    expect(displayEle.textContent).toBe(dataText);
  })

  it('should have correct heading',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    const newProperties = { ...properties, ...{'isKeyField':true} };
    component.updateProperties(newProperties,pageId);
    fixture.detectChanges();
    const ref: DebugElement = fixture.debugElement;
    //fixture.detectChanges();
    const helper = ref.query(By.css('#label'));
    const displayEle: HTMLElement = helper.nativeElement  
    expect(displayEle.textContent).toBe('*');
  })


  it('should have anchor tag',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let anchorTag=fixture.debugElement.query(By.css('#link'));
    expect(anchorTag).toBeTruthy();
  })

  it('anchor tag  should call openurl(name) method on click',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let link=fixture.debugElement.query(By.css('#link'))
    const checkCall=spyOn(component,'openurl');
    link.triggerEventHandler('click',null);
    expect(checkCall).toHaveBeenCalled();
  })

  it('should have error message tag',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let errorMessage=fixture.debugElement.query(By.css('.errorMessage'))
    expect(errorMessage).toBeTruthy();
  })

  it('should have input tag',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    const name = `#${properties.name}`;
    component.updateProperties(properties,pageId);
    const ref: DebugElement = fixture.debugElement;
    const nameInput = ref.query(By.css('.form-control'));
    const displayEle: HTMLElement = nameInput.nativeElement
    fixture.detectChanges();
    expect(displayEle).toBeTruthy()
  })

  it('Input tag  should call onChange method onfocus out',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let nameInput=fixture.debugElement.query(By.css('.form-control'))
    const checkCall=spyOn(component,'onChange');
    nameInput.triggerEventHandler('focusout',null);
    expect(checkCall).toHaveBeenCalled();
  })

  it('Input tag  should call onChange method keydown',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let nameInput=fixture.debugElement.query(By.css('.form-control'))
    const checkCall=spyOn(component,'numberOnly');
    nameInput.triggerEventHandler('keydown',null);
    expect(checkCall).toHaveBeenCalled();
  })

  it('should not  have  data when showAsLabel return false', () => {
    spyOn(component, 'showAsLabel').and.returnValue(false);
    component.data='xyz'
    fixture.detectChanges();
    const ref: DebugElement = fixture.debugElement;
    const label = ref.query(By.css('#data'));
    expect(label).not.toBeTruthy()
  })

  it('should not  have  heading when showAsLebel return true',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(true);
    fixture.detectChanges();
    const newProperties = { ...properties, ...{'isKeyField':true} };
    component.updateProperties(newProperties,pageId);
    fixture.detectChanges();
    const ref: DebugElement = fixture.debugElement;
    //fixture.detectChanges();
    const helper = ref.query(By.css('#label')); 
    expect(helper).not.toBeTruthy();
  })

  it('eventValue should be changed after execution of onChanges event',()=>{
    const mockEvent3: Event = <Event><any>{
      target: {
          value: 67890   
      }
    };
    component.onChange(mockEvent3);
   expect(component.eventValue).toBe(mockEvent3);
  });

});
