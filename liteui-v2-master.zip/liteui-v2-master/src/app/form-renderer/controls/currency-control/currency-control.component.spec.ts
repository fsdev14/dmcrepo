import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { AnyControlComponent } from '../any-control/any-control.component';
import { Router, ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { TranslatePipe } from 'src/app/translate.pipe';
import { By } from '@angular/platform-browser';
import { element } from 'protractor';
import { ConfigService } from 'src/app/services/config.service';
import { CurrencyControlComponent } from './currency-control.component';

describe('CurrencyControlComponent', () => {
  let component: CurrencyControlComponent;
  let fixture: ComponentFixture<CurrencyControlComponent>;
  let formValidatorService:FormvalidatorService;
  let configService:ConfigService
  let properties={
    'type': 'currency',
    'readonly': true,
    'hidden': false,
    'label': 'Previous Bal Subjected to OVLM',
    'name': '4601',
    'allowNegative': true,
    'centsLimit': 2,
    'centsSeparator': '.',
    'limit': 9,
    'prefix': '£',
    'suffix': '',
    'thousandsSeparator': ',',
    'order': 29,
    'fieldClass': 'col-lg-4 col-md-6 col-xxl-2 col-xxl-2',
    'data': '£0.00',
    'view': 'nonkey',
    'schema': {
        'type': 'string',
        'default': 0,
        'title': 'Previous Bal Subjected to OVLM'
    }
}
let pageId: '239984638';

let data=[
  {
    'type': 'number',
    'readonly': true,
    'hidden': false,
    'label': 'Product(Req only for ADD)',
    'name': '4003',
    'isKeyField': true,
    'crossReference': 'CMSLOGO',
    'order': 5,
    'fieldClass': 'col-lg-4 col-md-6 col-xxl-2 col-xxl-2',
    'data': '58',
    'view': 'key',
    'schema': {
        'type': 'number',
        'required': true,
        'default': 0,
        'minimum': 0,
        'maximum': 998,
        'title': 'Product(Req only for ADD)'
    }
},

{
    'type': 'number',
    'readonly': true,
    'hidden': false,
    'label': ' Business Unit(Req only for ADD)',
    'name': '4601',
    'isKeyField': true,
    'crossReference': 'CMSORG',
    'order': 1,
    'fieldClass': 'col-lg-4 col-md-6 col-xxl-2 col-xxl-2',
    'data': '40',
    'view': 'key',
    'schema': {
        'type': 'number',
        'required': true,
        'default': 0,
        'minimum': 0,
        'maximum': 999,
        'title': ' Business Unit(Req only for ADD)'
    }
}
]

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ CurrencyControlComponent,TranslatePipe,AnyControlComponent],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA,FormvalidatorService],
      providers:[FormvalidatorService,ConfigService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CurrencyControlComponent);
    component = fixture.componentInstance;
    formValidatorService=TestBed.inject(FormvalidatorService);
    const form = formValidatorService.buildFormGroup(pageId, data );
    component.updateProperties(properties, pageId); 
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('data should have correct value',()=>{
    //component.form = new FormGroup({
      //com: new FormControl('ashubham', Validators.required)
    //});
    //fixture.detectChanges();
   // component.updateProperties(properties,pageId);
    expect(component.data).toEqual(properties.data);
  })


  it('numberonly method should return correctly on key backspace',()=>{
    const keyEvent = new KeyboardEvent('keydown', { key: 'Backspace' });
    expect(component.numberOnly(keyEvent)).toBe(true);
  })

  it('numberonly method should return correctly on keys',()=>{
    const keyEvent = new KeyboardEvent('keydown', { key: '7' });
    expect(component.numberOnly(keyEvent)).toBe(true);
  })

  it('numberonly method should return correctly on no keyboard event',()=>{
    const keyEvent = new KeyboardEvent('keydown', { key: '#'});
    expect(component.numberOnly(keyEvent)).toBe(false);
  })

  it('should  have form',()=>{
    let formDiv=fixture.debugElement.query(By.css('.form-group'))
    expect(formDiv).toBeTruthy();
  })
  
  it('should have data element', () => {
    spyOn(component, 'showAsLabel').and.returnValue(true);
    fixture.detectChanges();
    let data = fixture.debugElement.query(By.css('#data'));
    expect(data).toBeTruthy();
  })

  it('should not have data element', () => {
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let data = fixture.debugElement.query(By.css('#data'));
    expect(data).toBe(null);
  })


  it('should have correct data', () => {
    spyOn(component, 'showAsLabel').and.returnValue(true);
    component.data='xyz'
    fixture.detectChanges();
    const ref: DebugElement = fixture.debugElement;
    const label = ref.query(By.css('#data'));
    const displayEle: HTMLElement = label.nativeElement
    let dataText=' '+component.data+' ';
    expect(displayEle.textContent).toBe(dataText);
  })

  it('should not  have  data when showAsLabel return false', () => {
    spyOn(component, 'showAsLabel').and.returnValue(false);
    component.data='xyz'
    fixture.detectChanges();
    const ref: DebugElement = fixture.debugElement;
    const label = ref.query(By.css('#data'));
    expect(label).not.toBeTruthy()
  })

  it('should not  have  heading when showAsLebel return true',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(true);
    fixture.detectChanges();
    const newProperties = { ...properties, ...{'isKeyField':true} };
    component.updateProperties(newProperties,pageId);
    fixture.detectChanges();
    const ref: DebugElement = fixture.debugElement;
    //fixture.detectChanges();
    const helper = ref.query(By.css('#label')); 
    expect(helper).not.toBeTruthy();
  })


  it('should have correct heading',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    const newProperties = { ...properties, ...{'isKeyField':true} };
    component.updateProperties(newProperties,pageId);
    fixture.detectChanges();
    const ref: DebugElement = fixture.debugElement;
    //fixture.detectChanges();
    const helper = ref.query(By.css('#label'));
    const displayEle: HTMLElement = helper.nativeElement  
    expect(displayEle.textContent).toBe('*');
  })


  it('should have anchor tag',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let anchorTag=fixture.debugElement.query(By.css('#link'));
    expect(anchorTag).toBeTruthy();
  })

  it('anchor tag  should call openurl(name) method on click',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let link=fixture.debugElement.query(By.css('#link'))
    const checkCall=spyOn(component,'openurl');
    link.triggerEventHandler('click',null);
    expect(checkCall).toHaveBeenCalled();
  })

  it('should have error message tag',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let errorMessage=fixture.debugElement.query(By.css('.errorMessage'))
    expect(errorMessage).toBeTruthy();
  })

  it('should have input tag',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    const name = `#${properties.name}`;
    component.updateProperties(properties,pageId);
    const ref: DebugElement = fixture.debugElement;
    const nameInput = ref.query(By.css('.form-control'));
    const displayEle: HTMLElement = nameInput.nativeElement
    fixture.detectChanges();
    expect(displayEle).toBeTruthy()
  })

  it('Input tag  should call focusHandler method onfocus out',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let nameInput=fixture.debugElement.query(By.css('.form-control'))
    const checkCall=spyOn(component,'focusHandler');
    nameInput.triggerEventHandler('focus',null);
    expect(checkCall).toHaveBeenCalled();
  })
  
  it('eventValue should be changed after execution of onChange',()=>{
    const event2={
    target:{
     name:'submit'
      }
    }
   component.onChange(event2);
   expect(component.eventValue).toBe(event2);
  })

  it('onChange method should be called on focusout',()=>{
    const focus=fixture.nativeElement;
    const input:HTMLInputElement=focus.querySelector('input[type=text]');
    let callCheck=spyOn(component,'onChange');
    input.dispatchEvent(new Event('focusout'));
    expect(callCheck).toHaveBeenCalled();
  })

});
