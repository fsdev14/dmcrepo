import { RuleConversionService } from './../../../services/rule-conversion.service';
import { ConversionService } from 'src/app/services/conversion.service';
import { Component } from '@angular/core';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { AnyControlComponent } from '../any-control/any-control.component';
import { Router, ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'app-currency-control',
  templateUrl: './currency-control.component.html',
  styleUrls: ['./currency-control.component.css']
})
export class CurrencyControlComponent extends AnyControlComponent  {
  centsLimit: any;
  centsSeparator: any = '.';
  thousandsSeparator: any = ',';
  prefix: string;
  Valueentererd: any;
  suffix: string;
  decValue: any;
  limit: number;
  inputValue = new Subject<string>();
  public openDialog = false;
  public eventValue: any;

  constructor(
    private formValidatorService: FormvalidatorService,
    private router: Router,
    private route: ActivatedRoute,
    private conversionService: ConversionService,
    private ruleConversionService: RuleConversionService
  ) {
    super(formValidatorService);
    this.type = 'currency';
  }

  

  updateProperties(properties, pageId:any) {
    this.pageId = pageId;
    super.updateProperties(properties,pageId);
    if (this.data === '') {
      this.data = '0';
    }
	
	if(this.suffix === undefined){
      const char = this.data.slice(-1);
      const specialChars = new RegExp(/$%€/); 
      if(char.match(specialChars)){
        this.suffix = char;
      }
      else{
        this.suffix = '';
      }
    } 

    this.data = this.getProcessedValue(this.data);
    this.form.controls[this.name].setValue(this.data);
  }
  numberOnly(event: KeyboardEvent): boolean {

    const specialKeys = ['Delete', 'Backspace', 'Shift', 'Control', 'Tab'];
    const controlKeys = 'cvyzCVYZ';

    /* Special Keys are always allowed. And Ctrl+C Ctrl+V */
    if (specialKeys.indexOf(event.key) >= 0 || (controlKeys.indexOf(event.key) >= 0 && event.ctrlKey)
    ) {
      return true;
    }

    const target: HTMLInputElement = event?.target as HTMLInputElement;
    const decValue = target?.value.replace(this.prefix, '').replace(this.suffix, '')
      .replace(new RegExp('\\' + this.thousandsSeparator, 'g'), '')
      .replace(this.centsSeparator, '').replace(new RegExp(/\+/g), '');

    /* Max Limit Reached, sorry */
    if (decValue?.length >= this.limit) {
      return false;
    }

    /* Only Number keys are allowed and +/- */
    const keys = '01234567890+-';
    if (keys.indexOf(event.key) >= 0 || specialKeys.indexOf(event.key) >= 0 ) {
      return true;
    }

    return false;

  }

  blurHandler(event: any) {
    // const start = event.target.selectionStart;
    this.inputValue.next(event.target.value);
    this.inputValue
      .pipe(debounceTime(400), distinctUntilChanged())
      .subscribe((value) => {
        this.eventValue = value;
        this.form.controls[this.name].setValue(this.getProcessedValue(this.eventValue));
      });
  }

  omit_special_char(event) {
    const isChar = /[^\w.]|[a-zA-Z_]/;
    if (event.key.length === 1 && isChar.test(event.key)) {
      const isFirstOperator = ['-', '+'].includes(event.key) && event.target.selectionStart === 0;
      if (!isFirstOperator) {
        event.preventDefault();
        return false;
      }
    }
  }

 focusHandler(event) {
    // const numbericValue = Number(event.target.value.replace(/[^0-9-]+/g, ''));
    // this.form.get(this.name).setValue(numbericValue);
  }

 getProcessedValue(data: string): string {
   return this.formValidatorService.getProcessedCurrencyValue(this, data);
 }

 onChange(event: any) {
  this.eventValue = event;   
  const dependentFields =  this.conversionService.dependencyField;
  if(dependentFields.includes(event.target.name)){
    this.ruleConversionService.setdialogFlag(true, this.eventValue, this.pageId);
  }
 }

}
