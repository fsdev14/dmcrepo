import { Component, OnInit } from '@angular/core';
import { LabelCodes } from 'src/assets/label-codes';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { AnyControlComponent } from '../any-control/any-control.component';
import { RestService } from './../../../services/rest.service';


@Component({
  selector: 'app-label-control',
  templateUrl: './label-control.component.html',
  styleUrls: ['./label-control.component.css']
})
export class LabelControlComponent extends AnyControlComponent implements OnInit {
  infoLabel: boolean;
  errorLabel: boolean;
  private labelCodes = new LabelCodes();
  constructor(private formValidatorService: FormvalidatorService, private restService: RestService) {
    super(formValidatorService);
    this.type = 'label';
    const resData = this.restService.getLastResponse();
    if (this.labelCodes.screens.includes(resData.data?.H_messageName)) {           //Label Replacement
      let businessCode = resData.data[4601];                                      //Org
      let product = resData.data[4003];                                           //Logo
      let fields = resData.options.fields;
      let allBusinessCodes: any[] = [];
      let allProductCodes: any[] = [];
      Object.keys(this.labelCodes.labelCode).forEach(org => {
        allBusinessCodes.push(org);
      });
      if (allBusinessCodes.includes(businessCode)) {
        Object.keys(this.labelCodes.labelCode[businessCode]).forEach(logo => {
          allProductCodes.push(logo)
        });
        if (allProductCodes.includes(product)) {
          Object.keys(fields).forEach(fieldCode => {
            let fieldLabel = fields[fieldCode].label;
            if (Object.keys(this.labelCodes.labelCode[businessCode][product]).includes(fieldLabel)) {
              fields[fieldCode].label = this.labelCodes.labelCode[businessCode][product][fieldLabel];
            }
          });
        }
      }
    }

    const labelCheck = resData.schema?.properties.ERR1.title || '';
    if (labelCheck.substring(8, 9) == 'I') {
      this.infoLabel = true;
    }
    else {
      this.errorLabel = true;
    }
  }

  ngOnInit(): void {

  }

}
