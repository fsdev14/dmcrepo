import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';

import { RestService } from './../../../services/rest.service';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import {FormControl, FormGroup} from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { By } from '@angular/platform-browser';
import { element } from 'protractor';
import { TranslatePipe } from 'src/app/translate.pipe';

import { LabelControlComponent } from './label-control.component';
import { of } from 'rxjs/internal/observable/of';
import { ConfigService } from 'src/app/services/config.service';
import { HttpService } from 'src/app/services/http.service';
import { Mock } from 'protractor/built/driverProviders';


class MockRestService extends RestService {

 data={
    'schema':{
      'type': 'object',
      'linkName': 'Amortization Details - ARMA09/10/16/ARQA - 02-Loan Earned / Unearned Amounts',
      'properties': {
          '4728': {
              'type': 'number',
              'required': true,
              'default': 1,
              'minimum': 1,
              'maximum': 999,
              'title': 'Record Number'
          },
          '4729': {
              'type': 'number',
              'required': true,
              'default': 0,
              'minimum': 0,
              'maximum': 99,
              'title': 'Record Type'
          },
          '4735': {
              'type': 'string',
              'default': 0,
              'title': 'Unearned Principal'
          },
          '4736': {
              'type': 'string',
              'default': 0,
              'title': 'Unearned Principal Reversal'
          },
          '4737': {
              'type': 'string',
              'default': 0,
              'title': 'Earned Principal'
          },
          'ERR1':{
            
              'type': 'string',
              'title': ''
          
          }
        }
      }
  }

  getLastResponse() {
      return this.data;
  }
}

describe('LabelControlComponent', () => {
  let component: LabelControlComponent;
  let fixture: ComponentFixture<LabelControlComponent>;
  let restService:RestService;
  let configService:ConfigService;
  let formValidatorService:FormvalidatorService;
  let httpService:HttpService;
  let router:Router;
  let service:MockRestService;

  let data={
    'schema':{
      'type': 'object',
      'linkName': 'Amortization Details - ARMA09/10/16/ARQA - 02-Loan Earned / Unearned Amounts',
      'properties': {
          '4728': {
              'type': 'number',
              'required': true,
              'default': 1,
              'minimum': 1,
              'maximum': 999,
              'title': 'Record Number'
          },
          '4729': {
              'type': 'number',
              'required': true,
              'default': 0,
              'minimum': 0,
              'maximum': 99,
              'title': 'Record Type'
          },
          '4735': {
              'type': 'string',
              'default': 0,
              'title': 'Unearned Principal'
          },
          '4736': {
              'type': 'string',
              'default': 0,
              'title': 'Unearned Principal Reversal'
          },
          '4737': {
              'type': 'string',
              'default': 0,
              'title': 'Earned Principal'
          },
          'ERR1':{
            
              'type': 'string',
              'title': ''
          
          }
        }
      }
  }
 

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ LabelControlComponent,TranslatePipe],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA,RestService],
      providers: [FormvalidatorService,ConfigService,
        {
            provide: RestService,
            useClass:MockRestService
        },
      ]
    })
    
    .compileComponents();
    
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LabelControlComponent);
    component = fixture.componentInstance;
    restService=TestBed.inject(RestService);
    
    
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
    
  });


  it('should error label have correct value',()=>{
    expect(component.errorLabel).toBe(true);
  })

  it('infolabel should have correct value',()=>{
    expect(component.infoLabel).toBe(undefined);
  })

  it('should have correct errorlabel',()=>{
    // creating reference for html element
    
    const ref: DebugElement = fixture.debugElement;
    const errorLabel = ref.query(By.css('#errorLabel'));
    const displayEle: HTMLElement = errorLabel.nativeElement
    fixture.detectChanges();
    expect(displayEle.textContent).toBe('');
  })
});
