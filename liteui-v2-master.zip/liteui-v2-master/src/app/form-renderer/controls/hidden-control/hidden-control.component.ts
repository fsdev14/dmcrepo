import { Component, OnInit } from '@angular/core';
import { ConfigService } from 'src/app/services/config.service';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { AnyControlComponent } from '../any-control/any-control.component';

@Component({
  selector: 'app-hidden-control',
  templateUrl: './hidden-control.component.html',
  styleUrls: ['./hidden-control.component.css']
})
export class HiddenControlComponent extends AnyControlComponent implements OnInit {

  constructor(private formValidatorService: FormvalidatorService) { super(formValidatorService);  this.type = 'hidden'; }

  ngOnInit(): void {
  }

}
