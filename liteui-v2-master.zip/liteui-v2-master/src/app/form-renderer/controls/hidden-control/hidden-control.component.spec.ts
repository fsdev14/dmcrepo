import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { FormControl, FormGroup, FormsModule, Validators } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { By } from '@angular/platform-browser';
import { ConfigService } from 'src/app/services/config.service';
import { HiddenControlComponent } from './hidden-control.component';

describe('HiddenControlComponent', () => {
  let component: HiddenControlComponent;
  let fixture: ComponentFixture<HiddenControlComponent>;
  let formvalidatorService:FormvalidatorService;
  let configService:ConfigService

  let properties={
    'type': 'hidden',
    'readonly': true,
    'hidden': false,
    'label': ' Application Date     ',
    'name': 'H_currencyNod',
    'order': 34,
    'fieldClass': 'col-lg-4 col-md-6 col-xxl-2 col-xxl-2',
    'data': '7',
    'view': 'nonkey',
    'schema': {
        'type': 'string',
        'format': 'date',
        'title': ' Application Date     '
    }
}

  let data = [
    {
      'type': 'hidden',
      'hidden': true,
      'name': 'H_currencyNod',
      'order': 1254,
      'fieldClass': 'd-none',
      'data': '7',
      'schema': {
          'type': 'string'
      }
  }
    
  
    ]

    let pageId='4157158136';

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ HiddenControlComponent ],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA,FormvalidatorService],
      providers:[FormvalidatorService,ConfigService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HiddenControlComponent);
    component = fixture.componentInstance;
    formvalidatorService=TestBed.inject(FormvalidatorService);
    const form = formvalidatorService.buildFormGroup(pageId, data );
    component.updateProperties(properties, pageId);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have input tag',()=>{
    const name = `#${component.id}`;
    component.updateProperties(properties,pageId);
    const ref: DebugElement = fixture.debugElement;
    const label = ref.query(By.css(name));
    const displayEle: HTMLElement = label.nativeElement
    fixture.detectChanges();
    expect(displayEle).toBeTruthy()
  })
});
