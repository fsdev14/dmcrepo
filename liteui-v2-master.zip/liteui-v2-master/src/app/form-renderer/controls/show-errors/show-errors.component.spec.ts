import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { UntypedFormControl, FormGroup, FormsModule, Validators } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TranslatePipe } from 'src/app/translate.pipe';
import { By } from '@angular/platform-browser';
import { AbstractControlDirective, AbstractControl } from '@angular/forms';
import { ShowErrorsComponent } from './show-errors.component';
import { TranslationService } from 'src/app/services/translation.service';
import { ConfigService } from 'src/app/services/config.service';



describe('ShowErrorsComponent', () => {
  let component: ShowErrorsComponent;
  let fixture: ComponentFixture<ShowErrorsComponent>;
  let translionService: TranslationService;
  let configService:ConfigService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowErrorsComponent,TranslatePipe],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[TranslationService,ConfigService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowErrorsComponent);
    component = fixture.componentInstance;
    component.control = new UntypedFormControl(' ', Validators.minLength(2));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show error div',()=>{
    spyOn(component, 'shouldShowErrors').and.returnValue(true);
    fixture.detectChanges();
    let errorMessage=fixture.debugElement.query(By.css('.errorMessage'))
    expect(errorMessage).toBeTruthy();
  })

  it('should show correct error',()=>{
    spyOn(component, 'shouldShowErrors').and.returnValue(true);
    let error=['This field is required']
    spyOn(component, 'listOfErrors').and.returnValue(error);
    fixture.detectChanges();
    let errorMessage=fixture.debugElement.queryAll(By.css('.errorMessage'));
    expect(errorMessage.length).toEqual(error.length);
     error.forEach((buttonsName,index)=>{
      expect(errorMessage[index].nativeElement.innerHTML).toEqual(error[index]);
     })
  })

  it('shouldnot have  showerror in case of shouldshow error return false',()=>{
    spyOn(component, 'shouldShowErrors').and.returnValue(false);
    let error=['This field is required']
    spyOn(component, 'listOfErrors').and.returnValue(error);
    fixture.detectChanges();
    let errorMessage=fixture.debugElement.queryAll(By.css('.errorMessage'));
    expect(errorMessage.length).not.toBeTruthy();
     
  })
});
