import { Component, Input } from '@angular/core';
import { AbstractControlDirective, AbstractControl } from '@angular/forms';

@Component({
  selector: 'app-show-errors',
  templateUrl: './show-errors.component.html',
  styleUrls: ['./show-errors.component.css']
})
export class ShowErrorsComponent {

  private static readonly errorMessages = {
    required: () => 'This field is required',
    min: (params) => 'The min value allowed is ' + params.min,
    max: (params) => 'The max value allowed is ' + params.max,
    minlength: (params) => 'The min number of characters is ' + params.requiredLength,
    maxlength: (params) => 'The max allowed number of characters is ' + params.requiredLength,
    pattern: (params) => 'Entered value does not match with Valid Values',
    years: (params) => params.message,
    uniqueName: (params) => params.message
  };

  @Input() control: AbstractControlDirective | AbstractControl;

  shouldShowErrors(): boolean {
    return this.control && this.control.errors !== null && !this.control.disabled && (this.control.dirty || this.control.touched) && this.control.status == 'INVALID';
  }

  listOfErrors(): string[] {
     return Object.keys(this.control.errors)
        .map(field => this.getMessage(field, this.control.errors[field]));
  }

  private getMessage(type: string, params: any) {
    return ShowErrorsComponent.errorMessages[type](params);
  }

}
