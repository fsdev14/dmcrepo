import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { MaskingService } from 'src/app/services/masking.service';
import { AnyControlComponent } from '../any-control/any-control.component';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TranslatePipe } from 'src/app/translate.pipe';
import { By } from '@angular/platform-browser';
import { element } from 'protractor';
import { ConfigService } from 'src/app/services/config.service';

import { TextControlComponent } from './text-control.component';

describe('TextControlComponent', () => {
  let component: TextControlComponent;
  let fixture: ComponentFixture<TextControlComponent>;
  let formValidatorService:FormvalidatorService;
  let configService:ConfigService
 let properties= {
    'type': 'label',
    'hidden': true,
    'view': 'fullPage-top',
    'name': 'ERR2',
    'fieldClass': '',
    'label': '',
    'schema': {
        'type': 'string',
        'title': ''
    }
}

let data=[{
  'type': 'object',
  'readonly': false,
  'hidden': false,
  'label': 'Account Association',
  'collapsible': false,
  'sectionId': 'section1',
  'order': 76,
  'fields': {
      'ERR2': {
          'type': 'table',
          'collapsible': false,
          'label': 'Account Association',
          'collapsed': true,
          'readonly': false,
          'showActionsColumn': false,
          'datatables': {
              'pageLength': 10,
              'paging': true,
              'lengthChange': false,
              'info': false,
              'searching': true,
              'ordering': false,
              'autoWidth': false,
              'transpose': false,
              'showSubmitButton': true,
              'language': {
                  'info': 'Record _START_ to _END_ of _TOTAL_'
              },
              'descColumn': [],
              'actionLinks': []
          },
          
          'name': 'ERR2',
          'fieldClass': 'col-12',
          'data': [
              {
                  '0205': '0',
                  '0206': '1233ASXXXX',
                  '0207': '0',
                  '0208': '00/00/0000',
                  '0209': '£0.00'
              },
              {
                  '0205': '0',
                  '0206': ' ',
                  '0207': '0',
                  '0208': '00/00/0000',
                  '0209': '£0.00'
              },
              {
                  '0205': '0',
                  '0206': ' ',
                  '0207': '0',
                  '0208': '00/00/0000',
                  '0209': '£0.00'
              }
          ],
          'schema': {
              'type': 'array',
              'useEditableTablePlugin': true,
              'transpose': false,
              'linkName': '',
              'items': {
                  'type': 'object',
                  'properties': {
                      '0205': {
                          'type': 'string',
                          'enum': [
                              '0',
                              '1',
                              '2',
                              '3',
                              '4',
                              '5',
                              '6',
                              '7',
                              '8',
                              '9'
                          ],
                          'title': 'Type of Association'
                      },
                      '0206': {
                          'type': 'string',
                          'title': 'Customer Number',
                          'format': 'uppercase',
                          'maxLength': 19
                      },
                      '0207': {
                          'type': 'string',
                          'enum': [
                              '0',
                              '1',
                              '2',
                              '3',
                              '4'
                          ],
                          'title': ' Relationship Type     '
                      },
                      '0208': {
                          'type': 'string',
                          'format': 'date',
                          'title': ' Date'
                      },
                      '0209': {
                          'type': 'string',
                          'default': 0,
                          'title': 'Amount'
                      }
                  }
              }
          }
      }
  },
 
}]


let pageId: '13017059254';
const mockEvent: Event = <Event><any>{
  target: {
      value: 421234567890    
  }
};

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ TextControlComponent,TranslatePipe],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA,FormvalidatorService],
      providers:[FormvalidatorService,ConfigService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TextControlComponent);
    component = fixture.componentInstance;
    formValidatorService=TestBed.inject(FormvalidatorService);
    const form = formValidatorService.buildFormGroup(pageId, data );
    component.updateProperties(properties, pageId);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should execute OnfocusOutEvent',()=>{
    const mockEvent2: Event = <Event><any>{
      target: {
          value: ' '   
      }
    };
    component.onFocusOut(mockEvent2);
    expect(component.control.value).toEqual(' '); 
  })


  
  it('should execute OnfocusOutEvent',()=>{
    const mockEvent3: Event = <Event><any>{
      target: {
          value: 'testing data'   
      }
    };
    
  
    component.onFocusOut(mockEvent3);
    expect(component.control.value).toEqual('testing data');  
  })

  it('should  have form',()=>{
    let formDiv=fixture.debugElement.query(By.css('.form-group'))
    expect(formDiv).toBeTruthy();
  })
  
  it('should have data element', () => {
    spyOn(component, 'showAsLabel').and.returnValue(true);
    fixture.detectChanges();
    let data = fixture.debugElement.query(By.css('#data'));
    expect(data).toBeTruthy();
  })

  it('should not have data element', () => {
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let data = fixture.debugElement.query(By.css('#data'));
    expect(data).toBe(null);
  })


  it('should have correct data', () => {
    spyOn(component, 'showAsLabel').and.returnValue(true);
    component.data='xyz'
    fixture.detectChanges();
    const ref: DebugElement = fixture.debugElement;
    const label = ref.query(By.css('#data'));
    const displayEle: HTMLElement = label.nativeElement
    let dataText=' '+component.data+' ';
    expect(displayEle.textContent).toBe(dataText);
  })

  it('should have correct heading',()=>{
   
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    const newProperties = { ...properties, ...{'isKeyField':true} };
    component.updateProperties(newProperties,pageId);
    fixture.detectChanges();
    const ref: DebugElement = fixture.debugElement;
    //fixture.detectChanges();
    const helper = ref.query(By.css('#label'));
    const displayEle: HTMLElement = helper.nativeElement  
    expect(displayEle.textContent).toBe('*');
  })


  it('should have anchor tag',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let anchorTag=fixture.debugElement.query(By.css('#link'));
    expect(anchorTag).toBeTruthy();
  })

  it('anchor tag  should call openurl(name) method on click',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let link=fixture.debugElement.query(By.css('#link'))
    const checkCall=spyOn(component,'openurl');
    link.triggerEventHandler('click',null);
    expect(checkCall).toHaveBeenCalled();
  })

  it('should have error message tag',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let errorMessage=fixture.debugElement.query(By.css('.errorMessage'))
    expect(errorMessage).toBeTruthy();
  })

  it('should have input tag',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    const name = `#${properties.name}`;
    component.updateProperties(properties,pageId);
    const ref: DebugElement = fixture.debugElement;
    const nameInput = ref.query(By.css('.form-control'));
    const displayEle: HTMLElement = nameInput.nativeElement
    fixture.detectChanges();
    expect(displayEle).toBeTruthy()
  })

  it('Input tag  should call onChange method onfocus out',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(false);
    fixture.detectChanges();
    let nameInput=fixture.debugElement.query(By.css('.form-control'))
    const checkCall=spyOn(component,'onFocus');
    nameInput.triggerEventHandler('focus',null);
    expect(checkCall).toHaveBeenCalled();
  })

  it('should have correct helper',()=>{
    // creating reference for html element
    const ref: DebugElement = fixture.debugElement;
    const newProperties = { ...properties, ...{'helper':'sample help'} };
    component.updateProperties(newProperties,pageId);
    fixture.detectChanges();
    const helper = ref.query(By.css('#helper'));
    const displayEle: HTMLElement = helper.nativeElement   
    expect(displayEle.textContent).toBe(component.helper);
  })

  it('should not  have  data when showAsLabel return false', () => {
    spyOn(component, 'showAsLabel').and.returnValue(false);
    component.data='xyz'
    fixture.detectChanges();
    const ref: DebugElement = fixture.debugElement;
    const label = ref.query(By.css('#data'));
    expect(label).not.toBeTruthy()
  })

  it('should not  have  heading when showAsLebel return true',()=>{
    spyOn(component, 'showAsLabel').and.returnValue(true);
    fixture.detectChanges();
    const newProperties = { ...properties, ...{'isKeyField':true} };
    component.updateProperties(newProperties,pageId);
    fixture.detectChanges();
    const ref: DebugElement = fixture.debugElement;
    //fixture.detectChanges();
    const helper = ref.query(By.css('#label')); 
    expect(helper).not.toBeTruthy();
  })

  it('eventValue should be changed after execution of onfocusout event',()=>{
    const mockEvent3: Event = <Event><any>{
      target: {
          value: 'testing data'   
      }
    };
    component.onFocusOut(mockEvent3);
   expect(component.eventValue).toBe(mockEvent3);
  });


});
