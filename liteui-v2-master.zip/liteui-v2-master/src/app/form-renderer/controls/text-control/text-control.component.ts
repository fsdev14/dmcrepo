import { RuleConversionService } from '../../../services/rule-conversion.service';
import { ConversionService } from 'src/app/services/conversion.service';
import { Component } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { MaskingService } from 'src/app/services/masking.service';
import { AnyControlComponent } from '../any-control/any-control.component';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-text-control',
  templateUrl: './text-control.component.html',
  styleUrls: ['./text-control.component.css']
})
export class TextControlComponent extends AnyControlComponent {
  public openDialog = false;
  public eventValue: any;
  inputValue = new Subject<string>();
  constructor(formValidatorService: FormvalidatorService,
    private maskingService: MaskingService,
    private conversionService: ConversionService,
    private ruleConversionService: RuleConversionService) {
    super(formValidatorService);
    this.type = 'text';
  }

  updateProperties(properties: any, pageId:any) {
    this.pageId = pageId;
    super.updateProperties(properties,pageId);
  }

  ngOnInit(): void {
  }

  onFocus(event) {
    const elt = event.target;
    const val = elt.value;
    if (val.trim() === '' || this.mask !== '') {
      elt.select();
    }
  }
  
  textUpperCase(event) {
    if (this.schema.format === 'uppercase') {
      this.inputValue.next(event.target.value);
      this.inputValue
        .pipe(debounceTime(400), distinctUntilChanged())
        .subscribe((value) => {
          (this.control as UntypedFormControl).setValue((this.control as UntypedFormControl).value.toUpperCase());
        });
    }
  }
  
  onFocusOut(event) {
    let newValue = ' ';
    if (event.target.value === '') {
      (this.control as UntypedFormControl).setValue(newValue);
    } else {
      newValue = event.target.value;
    }
    if (this.schema.format === 'uppercase') {
      (this.control as UntypedFormControl).setValue((this.control as UntypedFormControl).value.toUpperCase());
    } else {
      (this.control as UntypedFormControl).setValue(newValue);
    }
    if (this.mask !== '') {
      // case 1: User enters data and focus out 
      // case 2: User modifies existing data
      let newClearData = (this.control as UntypedFormControl).value;
      const newData = this.maskingService.applyMask(newClearData, this.mask);
      if (this.maskingService.unMaskedRepo[this.name] && newClearData === this.maskingService.unMaskedRepo[this.name].maskedData) {
      } else {
        this.maskingService.unMaskedRepo[this.name] = { maskedData: newClearData, data: newData };
      }
      if (newData.trim().length === 0 ) { // possibly new data is spaces, remove from masking repo
        delete this.maskingService.unMaskedRepo[this.name];
      }
      (this.control as UntypedFormControl).setValue(newData);
    }
    this.eventValue = event;
    const dependentFields =  this.conversionService.dependencyField;
    if(dependentFields.includes(event.target.name)){
      this.ruleConversionService.setdialogFlag(true, this.eventValue, this.pageId);
    }
  }

  validate() {

  }


}
