import { Component, OnInit } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { RestService } from 'src/app/services/rest.service';
import { SearchPipe } from 'src/app/search.pipe';
import { ConversionService } from 'src/app/services/conversion.service';
import { table } from 'console';
import { AnyControlComponent } from '../any-control/any-control.component';
import { ConfigService } from 'src/app/services/config.service';
import { ErrorHandlingService } from 'src/app/services/errorHandling.service';


interface TableRowModel {
  index: number;
  fields: Array<any>;
  descColumn: string;
  buttons: Array<any>;
}

/**
 * @class TableRow
 */
export class TableRow implements TableRowModel {
  index: number;
  fields: any[] = [];
  descColumn: string;
  buttons: any[] = [];
  formValidatorSerivce: FormvalidatorService;
  pageId:string;
/**
  *
 * @param index - index of the current TableRow
 * @param buttons - bottons added to row
 * @param descColumn - description column applicable to this TableRow
 * @param fields - row Fields
 * @param formValidator - formvalidator instance to create form fields
 */
  constructor(index, buttons, descColumn, fields, formValidator, pageId){
    this.index = index;
    this.descColumn = descColumn;
    this.buttons = buttons;
    this.formValidatorSerivce = formValidator;
    this.mapButtons();
    this.mapRowFields(fields);
    this.pageId = pageId;
    // console.log(`row built: ${index} `);
  }

  getFieldData(fieldCode: string): any{
    return this.fields[fieldCode].data;
  }
  mapButtons(){

  }
  /**
   *  Check if the TableRow contains a string
   * @param  searchParam - Search string to search in TableRow
   * @returns true if the string is present in either index, descColumn or any of the field Data.
   */
  containsString(searchParam: string): boolean{
    if (searchParam.length === 0) { return true; }

    if ((this.index + 1 ).toString().includes(searchParam)) { return true; }

    if (this.descColumn?.toLocaleLowerCase().includes(searchParam)) { return true; }

    if (this.fields.filter( field => field.data.toLocaleLowerCase().includes(searchParam)).length > 0 ) { return true; }

    return false;
  }
  /**
   * Map context table fields into TableRow fields
   * @param fields - context table fields
   */
  private mapRowFields(fields: any): void {
    fields.forEach(item => {
      const rowField = JSON.parse(JSON.stringify(item));
      rowField.name = `${item.name}_${this.index + 1}`;
      rowField.data = item.data[this.index];
      rowField.isTableField = true;
      this.fields.push(rowField);
      this.formValidatorSerivce.addField(this.pageId, rowField);
    });
  }
}

@Component({
  selector: 'app-table-control-maker',
  templateUrl: './table-control-maker.component.html',
  styleUrls: ['./table-control-maker.component.css']
})
export class TableControlMakerComponent implements OnInit {
  label: string;
  name: string;
  id: string;
  type = 'tableMaker';
  data = [];
  readonly: false;
  hidden: false;
  order: number;
  view: string;
  pattern: string;
  schema: any;
  fieldClass: string;
  sectionId: string;
  searchParam = '';
  isKeyField: boolean;
  form: UntypedFormGroup;
  fields: {};
  tableFields = [];
  currentPage = 1;
  totalPages = 1;
  pageSize = 20;
  transposeFlag: boolean;
  descColumn: any;
  datatables: any;
  rowButtons: Array<any> = [];
  tableButtons: Array<any> = [];
  tableRows: Array<TableRow> = [];
  searchPipe = new SearchPipe();
  filtered = 0;
  makerData: any = [];
  colCount: number;
  tableFieldName = [];
  makerChecker: any;
  appCodeId: any;
  foundCode: any;
  pageId: any;
  constructor(private conversionService: ConversionService,
              private fromValidatorService: FormvalidatorService,
              private restService: RestService,
              private configService: ConfigService,
              private errorHandlingService: ErrorHandlingService) { }

  ngOnInit(): void {
    this.form = this.fromValidatorService.getFormGroup(this.pageId);
    const lastRes = this.restService.getLastResponse();
    this.makerChecker = this.configService.config.makerChecker;
    const param1 = lastRes.data['0103'];
    const param2 = lastRes.data['0106'];
    this.configService.config.appCodes.forEach(element => {
     this.appCodeId = Number(element.id);
     this.appCodeId =  this.appCodeId.toString();
     if (param1 ===  this.appCodeId){
        this.foundCode = element;
        return;
      }
    });
    this.makerChecker.messageName = 'M.' + this.foundCode.appCode + '.' + this.foundCode.fileCode + param2 + 'AS.AS.MD.METADATA1';
    this.restService.post(this.makerChecker).subscribe(x => {
      try {
        this.makerData = this.restService.parse(x);
        this.makerData = this.conversionService.convert(this.makerData);
        this.updateProperties(this.makerData,this.pageId, true);
      } catch (error) {
        console.log(error);
        console.log('Retry?');
        //this.errorHandlingService.errorHandler(error.stack,'UIERR0005');
      }
    });
  }

  updateProperties(properties: any, pageId: any, isSecondCall?: boolean) {
    this.pageId = pageId;
    for (const ob of Object.keys(properties)) {
      this[ob] = properties[ob];
    }
    this.id = `f_${this.name}`;
    if (this.label === '') { this.label = this.schema.title; }
    if (this.hidden) {
      this.fieldClass = 'd-none';
    }
    let tableFieldsTemp: any  = Object.keys(this.fields).map(e => this.fields[e]);
    tableFieldsTemp = tableFieldsTemp.filter( x => (!x.name.startsWith('object') && !x.name.startsWith('ERR') && !x.name.startsWith('H_')));
    tableFieldsTemp.forEach(element => {
      element.name = element.name.split('_')[0];
     });
    if (isSecondCall){
       this.tableFields = tableFieldsTemp;
       this.tableFields.forEach( x => {
         x.dropdown =  this.getTableFieldName(x.name);
       });
     }
     else{
      this.tableFieldName = tableFieldsTemp;
     }
    this.colCount = this.tableFields.length + 1;
  }

  getTableFieldName(index: string): any{
      const tempVar = this.tableFieldName[0];
      const rowField = JSON.parse(JSON.stringify(tempVar));
      rowField.name = `${tempVar.name}_${Number(index) }`;
      rowField.data = tempVar.data[Number(index) - 1 ];
      rowField.isTableField = true;
      rowField.schema = tempVar.schema;
      rowField.optionLabels = tempVar.optionLabels;
      this.fields[rowField.name] = rowField;
      this.fromValidatorService.addField(this.pageId, rowField);
      return rowField;
}
  setPageTotal(filteredRows: any) {
    if (!filteredRows) { return; }
    this.totalPages = Math.ceil(filteredRows.length / this.pageSize);
    if ( this.currentPage > this.totalPages) {
      this.currentPage = this.totalPages;
    }
    if (this.currentPage === 0) {
      this.currentPage = 1;
    }
  }

  getFilteredRows(): Array<TableRow> {
    let filteredResult = this.tableFields;
    if (this.searchParam) {
      filteredResult =  this.tableFields.filter(tableField =>
        tableField.label.toLocaleLowerCase().includes(this.searchParam.toLocaleLowerCase()));
    }
    this.filtered = filteredResult.length;
    this.setPageTotal(filteredResult);
    return filteredResult;
  }

  clickRowButton(button: any, index: number, rowFields: any) {
    let pageOptions = this.fromValidatorService.getOptions(this.pageId);
    const request = { content: { messageName: '' }, linkName: '' };
    request.content = button.content;
    request.linkName = button.label;
    try {


      button.rowKeyMapping.forEach(item => {
        request.content[item.target] = (this.fields[item.source] === undefined) ? ''
        : this.fromValidatorService.formattedValue(this.fields[item.source], this.form.get(`${item.source}_${index}`).value);
      });
      button.tableKeyMapping.forEach(item => {
        request.content[item.target] = (pageOptions.fields[item.source] === undefined) ? ''
          : this.fromValidatorService.formattedValue(pageOptions.fields[item.source],
            pageOptions.fields[item.source].data, item.source);
      });
      let messageName = request.content.messageName;
      if (messageName.indexOf('$$') >= 0) {
        const field = messageName.substring(messageName.indexOf('$$') + 2, messageName.lastIndexOf('$$'));
        messageName = messageName.replace('$$' + field + '$$', this.form.get(field + '_' + index).value);
      }
      request.content.messageName = messageName;

      this.restService.gotoPage(request);
    } catch (error) {
      // console.log(error);
      this.errorHandlingService.errorHandler(error.stack,'UIERR0004');
      pageOptions = this.fromValidatorService.getOptions(this.pageId);
      pageOptions.fields.ERR1.data = 'Error occurred navigating through Table button. Please check with developer.';
    }

  }

  clickPageFlowButton(button: any) {
    const request = { content: { H_pageFlowFlag: '' }, linkName: '' };
    const pageOptions = this.fromValidatorService.getOptions(this.pageId);
    request.content = button.content;
    request.linkName = button.label;
    button.tableKeyMapping.forEach(item => {
      const val = this.form.get(item.source)?.value;
      if (val !== undefined) {
        request.content[item.target] = this.fromValidatorService.formattedValue(pageOptions.fields[item.source],
          val);
      }
    });
    for (const item of Object.keys(this.form.controls)) {
      if (item.startsWith('H_') && item !== 'H_messageName') {
        request.content[item] = this.form.get(item).value;
      }
    }
    request.content.H_pageFlowFlag = button.pageFlowFlag;
    this.restService.gotoPage(request);
  }

  setPage(pages: number) {
    this.currentPage = Number(this.currentPage);
    switch (pages) {
      case 0:
        this.currentPage = 1;
        break;
      case this.pageSize:
        this.currentPage += 1;
        break;
      case -this.pageSize:
        this.currentPage -= 1;
        break;
      case -1:
        this.currentPage = this.totalPages;
        break;
    }
    if (this.currentPage > this.totalPages) {
      this.currentPage = this.totalPages;
    }
    if (this.currentPage < 1) {
      this.currentPage = 1;
    }
  }
  isButtonDisabled(button: string): boolean {
    switch (button) {
      case 'next':
      case 'last':
        return this.currentPage === this.totalPages;
      case 'prev':
      case 'first':
        return this.currentPage === 1;
    }
    return false;
  }
  isFetchButtonDisabled(button: any): boolean {
    const pageOptions = this.fromValidatorService.getOptions(this.pageId);
    let a = [];
    let disabled = false;
    switch (button.pageFlowFlag) {
      case 'F':
      case 'P':
        disabled = true;
        a = this.hexToASCII(pageOptions.fields.H_prevToken.data).split('');
        // tslint: ignore
        for (let i = 0; i < a.length; i++) {
          if (a[i] !== '0') {
            disabled = false;
            break;
          }
        }
        return disabled;
      case 'N':
      case 'L':
        disabled = true;
        a = this.hexToASCII(pageOptions.fields.H_nextToken.data).split('');
        // tslint: ignore
        for (let i = 0; i < a.length; i++) {
          if (a[i] !== '9') {
            disabled = false;
            break;
          }
        }
        return disabled;

      default:
        return disabled;
    }
  }

  hexToASCII(hexstring: string): string {
    return hexstring.match(/.{1,2}/g)
      .map((v) => v.substring(1))
      .join('');
  }

}
