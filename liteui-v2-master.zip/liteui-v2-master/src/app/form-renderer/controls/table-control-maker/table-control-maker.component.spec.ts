import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RestService } from 'src/app/services/rest.service';
import { FormGroup } from '@angular/forms';
import { TablePagePipe } from 'src/app/table-page.pipe';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { SearchPipe } from 'src/app/search.pipe';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { TranslatePipe } from 'src/app/translate.pipe';
import { RouterTestingModule } from "@angular/router/testing";
import { Component, CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ConversionService } from 'src/app/services/conversion.service';
import { table } from 'console';
import { AnyControlComponent } from '../any-control/any-control.component';
import { ConfigService } from 'src/app/services/config.service';
import { MaskingService } from 'src/app/services/masking.service';

import { TableControlMakerComponent } from './table-control-maker.component';
import { By } from '@angular/platform-browser';


class MockRestService extends RestService {

    data={
      data:{
        "0103": "5",
        "0104": "20",
        "0105": "",
        "0106": "AB",
      "H_processId": "",
      "H_processTaskId": "",
      "H_messageName": "M.CMS.AMPS7AS.AS.QU.QUERY1",
      "H_hasTooltip": "true",
      "H_currencyNod": "2",
      "H_clickedButtonConfig": "",
      "H_name": "00000ASHUBHAM",
      "H_percentageNod": "7",
      "H_clientId": "",
      "H_language": "EN",
      "H_messageVersion": "R00000",
      "H_correlId": "",
      "H_currencyCode": "826",
      "H_fileSet": "2",
      "H_status": "P",
      "H_perItemNod": "3",
      "H_context": "00009851955755427",
      "object2": {
          "table2": [
            {
              "0110": "0",
              "0130": " ",
              
          },
          {
              "0110": "N",
              "0130": " ",
              
          }
             
          ]

      },
      
      "H_token": "e5919f1d51534c76c34611806e1afe7db4f4378af07d678ecb137c6a50356df0"
  },
    
    links:[
      {
          "linkId": "button1000",
          "linkName": "01-Field Codes",
          "content": {
              "messageName": "M.SSC.SMMSAS.AS.QU.QUERY1",
              "messageVersion": "R00000",
              "0103": "5",
              "0104": "20",
              "0105": "",
              "0106": "AB"
          },
          "active": true
      },
      {
          "linkId": "button1001",
          "linkName": "99-Status & Activity Information",
          "content": {
              "messageName": "M.SSC.SMMSAS.AS.QU.QUERY2",
              "messageVersion": "R00000",
              "0103": "5",
              "0104": "20",
              "0105": "",
              "0106": "AB"
          },
          "active": false
      }
  ],
  schema:{
    "type": "object",
    "linkName": "Field Security - 01-Field Codes",
    "properties": {
      
       
        "H_currencyCode": {
            "type": "string"
        },
        "H_fileSet": {
            "type": "string"
        },
        "H_status": {
            "type": "string"
        },
        "H_perItemNod": {
            "type": "string"
        },
        "H_context": {
            "type": "string"
        },
        "0103": {
            "type": "number",
            "required": true,
            "default": 0,
            "minimum": 0,
            "maximum": 99,
            "title": "Application Code"
        },
        "0104": {
            "type": "number",
            "required": true,
            "default": 0,
            "minimum": 0,
            "maximum": 999,
            "title": "Business Unit"
        },
        "0105": {
            "type": "string",
            "title": "User Code",
            "required": true,
            "format": "uppercase",
            "maxLength": 1
        },
        "0106": {
            "type": "string",
            "title": "File Code",
            "required": true,
            "format": "uppercase",
            "maxLength": 2
        },
        "object2": {
            "type": "object",
            "properties": {
                "table2": {
                    "type": "array",
                    "useEditableTablePlugin": true,
                    "transpose": false,
                    "linkName": "",
                    "items": {
                        "type": "object",
                        "properties": {
                            "0110": {
                                "type": "string",
                                "enum": [
                                    "0",
                                    "1",
                                    "4",
                                    "5",
                                    "6",
                                    "8",
                                    "9",
                                    "A",
                                    "B",
                                    "C",
                                    "E",
                                    " "
                                ],
                                "title": "Permission"
                            },
                            "0130": {
                                "type": "string",
                                "enum": [
                                    "Y",
                                    "N",
                                    "B",
                                    "M"
                                ],
                                "title": "Audit Code"
                            }
                        }
                    }
                }
            }
        }
    }
},
ableGridJsonPaths: [],
view:{
  "parent": "bootstrap-edit",
  "layout": {
      "template": "./partials/threeColumnLayout.html",
      "bindings": {
          "ERR1": "fullPage-top",
          "ERR2": "fullPage-top",
          "ERR3": "fullPage-top",
      }
  }
},
options:{
 "adhocButtonLayer":[
  {
      "id": "button2",
      "buttonName": "Maintain",
      "displayAsButton": true,
      "displayAsLink": false,
      "targetMessage": {
          "messageName": "M.SSC.SMMSAS.AS.UP.UPDATE1",
          "messageVersion": "R00000"
      },
      "keyFieldCodeMapping": [
          {
              "parentMessageFieldCode": "0103",
              "targetMessageFieldCode": "0103"
          },
          {
              "parentMessageFieldCode": "0104",
              "targetMessageFieldCode": "0104"
          },
          {
              "parentMessageFieldCode": "0105",
              "targetMessageFieldCode": "0105"
          },
          {
              "parentMessageFieldCode": "0106",
              "targetMessageFieldCode": "0106"
          }
      ],
      "fieldCodeMapping": [],
      "constants": {}
  },
  {
      "id": "button3",
      "buttonName": "Next Group",
      "displayAsButton": true,
      "displayAsLink": false,
      "targetMessage": {
          "messageName": "M.SSC.SMMSAS.AS.QU.QUERY2",
          "messageVersion": "R00000"
      },
      "keyFieldCodeMapping": [
          {
              "parentMessageFieldCode": "0103",
              "targetMessageFieldCode": "0103"
          },
          {
              "parentMessageFieldCode": "0104",
              "targetMessageFieldCode": "0104"
          },
          {
              "parentMessageFieldCode": "0105",
              "targetMessageFieldCode": "0105"
          },
          {
              "parentMessageFieldCode": "0106",
              "targetMessageFieldCode": "0106"
          }
      ],
      "fieldCodeMapping": [],
      "constants": {}
  },
  {
      "id": "button2001",
      "buttonName": "Exit",
      "displayAsButton": true,
      "displayAsLink": false,
      "targetMessage": {
          "messageName": "M.SSC.SMMSAS.AS.GE.GET-LIST",
          "messageVersion": "R00000"
      },
      "keyFieldCodeMapping": [],
      "fieldCodeMapping": [],
      "constants": {}
  }
],
"fields": {
  "0110": {
      "type": "number",
      "readonly": true,
      "hidden": false,
      "label": "Permission",
      "name": "0110",
      "order": 2004,
      "removeDefaultNone": true,
      "optionLabels":["All access (0)","No Maint Access (4)"],
      "fieldClass": "col-lg-4 col-md-6 col-xxl-2 col-xxl-2",
      "data": ["0","N","0"],
      "schema": {
          "type": "Select",
          "default": 0,
          "enum":['0','1','4','5'],
          "title": "Permission"
      }
  },
  "0130": {
    "type": "number",
    "readonly": true,
    "hidden": false,
    "label": "Audit Code",
    "name": "0130",
    "order": 2005,
    "removeDefaultNone": true,
    "optionLabels":["Report Field Changes (Y)","Do Not Report Field Changes (N)"],
    "fieldClass": "col-lg-4 col-md-6 col-xxl-2 col-xxl-2",
    "data": ["0","N","0"],
    "schema": {
        "type": "Select",
        "default": 0,
        "enum":['Y','N','B','M'],
        "title": "Audit Code"
    }
}
},
"form":{
  "attributes": {
      "action": "",
      "method": "post"
  },
  "buttons": {
      "button2": {
          "value": "Maintain"
      },
      "button3": {
          "value": "Next Group"
      },
      "button2001": {
          "value": "Exit"
      }
  }
},

"tableGridJsonPaths":[
  "$.object2.table2"
],
"renderForm": "true"

}



}
  
  
   
     getLastResponse() {
         return this.data;
     }

     post(content: any): Observable<any> {
      const data = Observable.create( observer => 
        observer.complete()
      )
  
      return data;
  
  }
   
}

describe('TableControlMakerComponent', () => {
  let component: TableControlMakerComponent;
  let fixture: ComponentFixture<TableControlMakerComponent>;
  let configService:ConfigService;
  let conversionService:ConversionService;
  let formValidatorService:FormvalidatorService;
  let maskingService:MaskingService;


  let properties={
    "type": "tableMaker",
    "collapsible": false,
    "label": "Field Codes",
    "totalPages":3,
    "collapsed": true,
    "readonly": true,
    "showActionsColumn": false,
    "datatables": {
        "pageLength": 3,
        "paging": true,
        "lengthChange": false,
        "info": false,
        "searching": true,
        "ordering": false,
        "autoWidth": false,
        "transpose": false,
        "showSubmitButton": true,
        "language": {
            "info": "Record _START_ to _END_ of _TOTAL_"
        },
        "descColumn": [],
        "actionLinks": []
         
    },
    "fields": {
        "0110": {
            "type": "number",
            "readonly": true,
            "hidden": false,
            "label": "Permission",
            "name": "0110",
            "order": 2004,
            "removeDefaultNone": true,
            "optionLabels":["All access (0)","No Maint Access (4)"],
            "fieldClass": "col-lg-4 col-md-6 col-xxl-2 col-xxl-2",
            "data": ["0","N","0"],
            "schema": {
                "type": "Select",
                "default": 0,
                "enum":['0','1','4','5'],
                "title": "Permission"
            }
        },
        "0130": {
          "type": "number",
          "readonly": true,
          "hidden": false,
          "label": "Audit Code",
          "name": "0130",
          "order": 2005,
          "removeDefaultNone": true,
          "optionLabels":["Report Field Changes (Y)","Do Not Report Field Changes (N)"],
          "fieldClass": "col-lg-4 col-md-6 col-xxl-2 col-xxl-2",
          "data": ["0","N","0"],
          "schema": {
              "type": "Select",
              "default": 0,
              "enum":['Y','N','B','M'],
              "title": "Audit Code"
          }
      }
     
       
    },
    "name": "table2",
    "fieldClass": "col-12",
    "data": [
      {
          "0110": "0",
          "0130": " ",
          
      },
      {
          "0110": "N",
          "0130": " ",
          
      }
  ],
    "schema": {
        "type": "array",
        "useEditableTablePlugin": true,
        "transpose": false,
        "linkName": "",
        "format":"",
        "title":"Testing Data",
        "items": {
            "type": "object",
            "properties": {
                "0110": {
                    "type": "string",
                    "enum":['0','1','4','5'],
                    "title": "Permission"
                },
                "0130": {
                  "type": "string",
                  "enum":['Y','N','B','M'],
                  "title": "Audit Code"
              },
              }
            }
          }
        }

        let data=[
          {
            "type": "label",
            "hidden": true,
            "view": "fullPage-top",
            "name": "ERR1",
            "fieldClass": "",
            "label": "",
            "schema": {
                "type": "string",
                "title": ""
            }
        },
        {
          "type": "label",
          "hidden": true,
          "view": "fullPage-top",
          "name": "ERR2",
          "fieldClass": "",
          "label": "",
          "schema": {
              "type": "string",
              "title": ""
          }
      },
      {
        "type": "label",
        "hidden": true,
        "view": "fullPage-top",
        "name": "ERR4",
        "fieldClass": "",
        "label": "",
        "schema": {
            "type": "string",
            "title": ""
        }
    }

        ]

        let pageId: "221140572";

        let filteredRows=[1,2,3,4,5,6,7,8,9,0,'A','B','C','D','E',44,88,99,12,10,87]
       

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TableControlMakerComponent,SearchPipe,TranslatePipe,TablePagePipe],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA,FormvalidatorService,ConfigService,ConversionService],
      providers: [FormvalidatorService,ConfigService,MaskingService,
        {
            provide: RestService,
            useClass:MockRestService
        },
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TableControlMakerComponent);
    component = fixture.componentInstance;
    configService=TestBed.inject(ConfigService);
    conversionService=TestBed.inject(ConversionService);
    formValidatorService=TestBed.inject(FormvalidatorService)
    configService.config={
      'remoteUrl': '',
      'loginRequest': '',
      'showSearch': null,
      'menuMessage': '',
      'searchRequest': '',
      'displayDashboard':null,
      'dashboardTitle': '',
      'loginPageTitle':'',
      'documentTitle':'',
      'defaultDateFormat':'',
      'enableRSA':true,
      'profileMessage':'',
      'makerChecker':{
        "H_language": "EN",
        "messageMode": "METADATA",
        "messageName": "M.CMS.AMBSAS.AS.MD.METADATA1",
        "messageVersion": "R00000",
        "selectValue": "0110"
      },
      'appCodes':[
        {
          
            "id": "01",
            "appCode": "SSC",
            "fileCode": "SM"
        
        },
        {
          "id": "02",
          "appCode": "VMX",
          "fileCode": "VM"
      },
      {
        "id": "04",
        "appCode": "ITS",
        "fileCode": "IT"
    }
      ],
      'selectedTheme':null,
      'themeOptions': [],
      'defaultMask':'',
      'enableMask':true,
      'maskByXref': null,
      'maskXrefRepository':[],
      'maskRepository': [],
      'formChangesLimit':null,
      'languages':[],
      'timeOutDuration': null,
      'fileSetChange': '',
      'documentationFormat': '',
      'documentationRepository': '',
      'ssoLogin':null
    }
    component.foundCode={
      "appCode":"CMS"
    }
    formValidatorService=TestBed.inject(FormvalidatorService);
    const form = formValidatorService.buildFormGroup(pageId, data );
    component.updateProperties(properties, pageId);
    component.tableFields=[1,2,3,4,5,6,7,8,9,12,14,16,18,19,10,'a','b','c','d','e',21,22]
    
  
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have correct label',()=>{
    expect(component.label).toEqual('Field Codes')
  })

  it('should have correct label in case of empty label from properties',()=>{
    const newProperties = { ...properties, ...{label:''}};
    component.updateProperties(newProperties,pageId);
    expect(component.label).toEqual(component.schema.title)
  })

  it('should have correct field class',()=>{
    expect(component.fieldClass).toEqual("col-12");
  })

  it('current page should have correct value in case of 0 given to set page method',()=>{
    component.setPage(0);
    expect(component.currentPage).toBe(1);
  })

  it('current page should have correct value in case of (-page size) given to set page method',()=>{
    component.setPage(-20);
    expect(component.currentPage).toBe(1);
  })

  it('current page should have correct value in case of current page less than 1',()=>{
    component.setPage(-20);
    expect(component.currentPage).toBe(1);
  })

  it('should return correct boolean value after execution of isButtonDisabled in case of next argument given',()=>{
    expect(component.isButtonDisabled('last')).toBe(false);
  })

  it('should return correct boolean value after execution of isButtonDisabled in case of last argument given',()=>{
    expect(component.isButtonDisabled('next')).toBe(false);
  })

  it('should return correct boolean value after execution of isButtonDisabled in case of prev argument given',()=>{
    expect(component.isButtonDisabled('prev')).toBe(true);
  })

  it('should return correct boolean value after execution of isButtonDisabled in case of first argument given',()=>{
    expect(component.isButtonDisabled('first')).toBe(true);
  })

  it('should return correct boolean value after execution of isButtonDisabled in case of argument given which is other than first,last,next,prev argument given',()=>{
    expect(component.isButtonDisabled('test')).toBe(false);
  })

  //to test the label which is in h5 tag
  it('should have correct heading',()=>{
    // creating reference for html element
    const ref: DebugElement = fixture.debugElement;
    const heading = ref.query(By.css('#label'));
    const displayEle: HTMLElement = heading.nativeElement
    fixture.detectChanges();
    let testingLabel=' '+component.label+' '
    expect(displayEle.textContent).toBe(testingLabel);
  })

  // to test the search place holder
  it('should have search input tag',()=>{
    // creating reference for html element
    const ref: DebugElement = fixture.debugElement;
    const search = ref.query(By.css('#search'));
    const displayEle: HTMLElement = search.nativeElement
    fixture.detectChanges();
    expect(displayEle).toBeTruthy();
  })

  //to test if search place holder display the searchparam data
  it('should have call getfilteredRows on ngModelChange by search input tag',()=>{
    const ref: DebugElement = fixture.debugElement;
    const search = ref.query(By.css('#search'));
    fixture.detectChanges();
    expect(search.nativeElement.innerHTML).toBe(component.searchParam);
  })
  //to test the div tag for transposeflag
  it('should have transpose flag div',()=>{
    // creating reference for html element
    const ref: DebugElement = fixture.debugElement;
    const transpose = ref.query(By.css('#transpose'));
    const displayEle: HTMLElement = transpose.nativeElement
    fixture.detectChanges();
    expect(displayEle).toBeTruthy();
  })

  //to test the correct name in first collumn
  it('should have correct heading in collumn 1',()=>{
    const ref: DebugElement = fixture.debugElement;
    const col1 = ref.query(By.css('#col1'));
    const displayEle: HTMLElement = col1.nativeElement
    fixture.detectChanges();
    expect(displayEle.textContent).toBe('Field Name');
  })

 //to test the correct name in second collumn
 it('should have correct heading in collumn 2',()=>{
  const ref: DebugElement = fixture.debugElement;
  const col2 = ref.query(By.css('#col2'));
  const displayEle: HTMLElement = col2.nativeElement
  fixture.detectChanges();
  console.log('table field', component.tableFields)
  expect(displayEle.textContent).toBe('Permission');
})



it("should have first labeled button",()=>{
  const first=fixture.debugElement.query(By.css('#first'));
  expect(first).toBeTruthy();
  const callCheck=spyOn(component,'setPage');
  first.triggerEventHandler('click',null);
  expect(callCheck).toHaveBeenCalled();
})

it("should have previous labeled button",()=>{
  const first=fixture.debugElement.query(By.css('#previous'));
  expect(first).toBeTruthy();
  const callCheck=spyOn(component,'setPage');
  first.triggerEventHandler('click',null);
  expect(callCheck).toHaveBeenCalled();
})

it("should have input for total page",()=>{
  const totalPage=fixture.debugElement.query(By.css('#totalPages'));
  expect(totalPage).toBeTruthy();
  const callCheck=spyOn(component,'setPage');
  totalPage.triggerEventHandler('change',null);
  expect(callCheck).toHaveBeenCalled(); 
})




});
