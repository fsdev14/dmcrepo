import { Component, OnInit } from '@angular/core';
import { UntypedFormControl, FormGroup } from '@angular/forms';
import { ConfigService } from 'src/app/services/config.service';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { AnyControlComponent } from '../any-control/any-control.component';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-date-control',
  templateUrl: './date-control.component.html',
  styleUrls: ['./date-control.component.css']
})
export class DateControlComponent extends AnyControlComponent implements OnInit {
  convertedDate: any = new Date();
  constructor(private formValidatorService: FormvalidatorService, private configService: ConfigService,
              private router: Router, private route: ActivatedRoute) {
    super(formValidatorService);
    this.type = 'date';
  }

  ngOnInit(): void {
  }

  updateProperties(properties: any, pageId:any) {
    this.pageId = pageId;
    super.updateProperties(properties,pageId);
    /** Date already contains -s its already in yyyy-mm-dd format */
    if (this.data.indexOf('-') >= 0) {
      this.convertedDate = this.data;
      (this.control as UntypedFormControl).setValue(this.convertedDate);
      return;
    }
    let parts = [];
    if (this.data.indexOf('-') >= 0) {
      this.convertedDate = this.data;
      (this.control as UntypedFormControl).setValue(this.convertedDate);
      return;
    }
    switch (this.configService.config.defaultDateFormat) {
      case 'DD/MM/YYYY':
        parts = this.data.split('/');
        this.convertedDate = `${parts[2]}-${parts[1]}-${parts[0]}`;
        break;
      case 'MM/DD/YYYY':
      default:
        parts = this.data.split('/');
        this.convertedDate = `${parts[2]}-${parts[0]}-${parts[1]}`;
        break;

    }
    (this.control as UntypedFormControl).setValue(this.convertedDate);
  }
}
