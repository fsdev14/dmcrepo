import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { FormControl, FormGroup, FormsModule, Validators } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ConfigService } from 'src/app/services/config.service';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { TranslatePipe } from 'src/app/translate.pipe';
import { By } from '@angular/platform-browser';
import { element } from 'protractor';
import { AnyControlComponent } from '../any-control/any-control.component';
import { DateControlComponent } from './date-control.component';

describe('DateControlComponent', () => {
  let component: DateControlComponent;
  let fixture: ComponentFixture<DateControlComponent>;
  let configService:ConfigService;
  let formvalidatorService:FormvalidatorService
  let properties={
    'type': 'date',
    'readonly': true,
    'hidden': false,
    'label': ' Application Date     ',
    'name': '0347',
    'order': 34,
    'fieldClass': 'col-lg-4 col-md-6 col-xxl-2 col-xxl-2',
    'data': '00-00-0000',
    'view': 'nonkey',
    'schema': {
        'type': 'string',
        'format': 'date',
        'title': ' Application Date     '
    }
}


let data = [
  {
    'type': 'date',
    'readonly': true,
    'hidden': false,
    'label': 'Skip pmt end date',
    'name': '0347',
    'order': 76,
    'fieldClass': 'col-lg-4 col-md-6 col-xxl-2 col-xxl-2',
    'data': '00/00/0000',
    'view': 'nonkey',
    'schema': {
        'type': 'string',
        'format': 'date',
        'title': 'Skip pmt end date'
    }
}
  

  ]
let pageId: '29715202158';

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ DateControlComponent,TranslatePipe],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA,ConfigService,FormvalidatorService],
      providers:[FormvalidatorService,ConfigService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DateControlComponent);
    component = fixture.componentInstance;
    configService=TestBed.inject(ConfigService);
    formvalidatorService=TestBed.inject(FormvalidatorService);
    configService.config={
      'remoteUrl': '',
      'loginRequest': '',
      'showSearch': null,
      'menuMessage': '',
      'searchRequest': '',
      'displayDashboard':null,
      'dashboardTitle': '',
      'loginPageTitle':'',
      'documentTitle':'',
      'defaultDateFormat':'DD/MM/YYYY',
      'enableRSA':true,
      'profileMessage':'',
      'makerChecker':'',
      'appCodes':'',
      'selectedTheme':null,
      'themeOptions': [],
      'defaultMask':'',
      'enableMask':true,
      'maskByXref': null,
      'maskXrefRepository':[],
      'maskRepository': [],
      'formChangesLimit':null,
      'languages':[],
      'timeOutDuration': null,
      'fileSetChange': '',
      'documentationFormat': '',
      'documentationRepository': '',
      'ssoLogin':null
    }

   // component.control = new FormControl();
   // let fieldGroup = {};
    //fieldGroup['4001'] = new FormControl({ value: ''} );
    //component.helper='xyz'
    //component.isKeyField=true;
    //component.data='abc'
   
    const form = formvalidatorService.buildFormGroup(pageId, data );
    component.updateProperties(properties, pageId);

    //component.form = new FormGroup(fieldGroup);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have correct date value',()=>{
    component.updateProperties(properties,pageId);
    expect(component.convertedDate).toEqual(component.data);
  })

  it('should have date with correct formate',()=>{
    let properties2={
      'type': 'date',
    'readonly': true,
    'hidden': false,
    'label': ' Application Date     ',
    'name': '0116',
    'order': 34,
    'fieldClass': 'col-lg-4 col-md-6 col-xxl-2 col-xxl-2',
    'data': '00/00/0000',
    'view': 'nonkey',
    'schema': {
        'type': 'string',
        'format': 'date',
        'title': ' Application Date     '
    }
    }

    component.updateProperties(properties,pageId);
    expect(component.convertedDate).toEqual('00-00-0000');
  })

  it('should  have form',()=>{
    let formDiv=fixture.debugElement.query(By.css('.form-group'))
    expect(formDiv).toBeTruthy();
  })

  it('should have anchor tag',()=>{
    let anchorTag=fixture.debugElement.query(By.css('#link'));
    expect(anchorTag).toBeTruthy();
  })


  it('should have correct heading',()=>{
    // creating reference for html element
    const ref: DebugElement = fixture.debugElement;
    const newProperties = { ...properties, ...{'isKeyField':true} };
    component.updateProperties(newProperties,pageId);
    fixture.detectChanges();
    const label = ref.query(By.css('#label'));
    const displayEle: HTMLElement = label.nativeElement
    expect(displayEle.textContent).toBe('*');
  })


  it('should have input tag',()=>{
    const name = `#${properties.name}`;
    //component.updateProperties(properties,pageId);
    
    const ref: DebugElement = fixture.debugElement;
    fixture.detectChanges();
    const label = ref.query(By.css('.form-control'));
    const displayEle: HTMLElement = label.nativeElement
   // fixture.detectChanges();
    expect(displayEle).toBeTruthy()
  })


  it('anchor tag  should call openurl(name) method on click',()=>{
    let link=fixture.debugElement.query(By.css('#link'))
    const checkCall=spyOn(component,'openurl');
    link.triggerEventHandler('click',null);
    expect(checkCall).toHaveBeenCalled();
  })

  it('should have error message tag',()=>{
    let errorMessage=fixture.debugElement.query(By.css('.errorMessage'))
    expect(errorMessage).toBeTruthy();
  })


});
