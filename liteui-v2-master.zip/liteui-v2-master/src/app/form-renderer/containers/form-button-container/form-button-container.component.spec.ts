import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { UntypedFormControl, FormsModule } from '@angular/forms';
import { UntypedFormGroup } from '@angular/forms';
import { Component, DebugElement, Input, NgModule, NO_ERRORS_SCHEMA, OnChanges, OnDestroy, OnInit, SimpleChange, SimpleChanges } from '@angular/core';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { By } from '@angular/platform-browser';
import { RestService } from 'src/app/services/rest.service';
import { ConfigService } from 'src/app/services/config.service';
import { TranslatePipe } from 'src/app/translate.pipe';


import { FormButtonContainerComponent } from './form-button-container.component';



describe('FormButtonContainerComponent', () => {
  let component: FormButtonContainerComponent;
  let fixture: ComponentFixture<FormButtonContainerComponent>;
  let restService:RestService;
  let configService:ConfigService
 
  //let options=new component.options(); 
  
  

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
        declarations: [ FormButtonContainerComponent,TranslatePipe],
        imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([]),FormsModule],
        schemas: [NO_ERRORS_SCHEMA],
        providers:[RestService,ConfigService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormButtonContainerComponent);
    component = fixture.componentInstance;   
    let fieldGroup = {};
    fieldGroup['4001'] = new UntypedFormControl({ value: ''} );

    component.formGroup = new UntypedFormGroup(fieldGroup);
    component.options={
      'attributes': {
          'action': '',
          'method': 'post'
      },
      'buttons': {
          'submit': {
              'value': 'List'
          },
          'button14': {
              'value': 'Query'
          },
          'button15': {
              'value': 'Update'
          },
          'button118': {
              'value': 'Add'
          }
      }
  }

  component.options.form= {
    'submit': {
        'value': 'List'
    },
    'button14': {
        'value': 'Query'
    },
    'button15': {
        'value': 'Update'
    },
    'button118': {
        'value': 'Add'
    }
}

component.options.form.buttons= {
  'button14': {
  'value': 'Query'
},
'button15': {
  'value': 'Update'
},
'button118': {
  'value': 'Add'
}
}
         
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  it('should create div for buttons and have actual name on it',()=>{
    const testDirective=fixture.debugElement.query(By.css('#btnList'));
    expect(testDirective).toBeTruthy();
    const testDirective2=fixture.debugElement.queryAll(By.css('button.btn'))
    expect(testDirective2.length).toEqual(component.buttons.length);
     component.buttons.forEach((buttonsName,index)=>{
      expect(testDirective2[index].attributes.value).toEqual(component.buttons[index].value);
     })
  })
});
