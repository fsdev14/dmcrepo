import { Component, Input, OnChanges, OnDestroy, OnInit, SimpleChange, SimpleChanges } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { RestService } from 'src/app/services/rest.service';

@Component({
  selector: 'app-form-button-container',
  templateUrl: './form-button-container.component.html',
  styleUrls: ['./form-button-container.component.css']
})
export class FormButtonContainerComponent implements OnInit, OnChanges, OnDestroy{
  @Input() options: any;
  @Input() formGroup: UntypedFormGroup;
  buttons: any;
  constructor(private restService: RestService, private router: Router) { }
  

  formData: any = {};
  ngOnInit(): void {
    this.buttons = Object.keys(this.options.form.buttons).map(e => this.options.form.buttons[e]);
  }
  ngOnChanges(changes: SimpleChanges): void {
    this.ngOnInit();
  }

  ngOnDestroy(): void {
    this.options = null;
  }

  submitForm(button: any) {
    return;
  }
}
