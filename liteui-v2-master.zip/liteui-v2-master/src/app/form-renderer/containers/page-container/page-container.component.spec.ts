import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { ConfigService } from 'src/app/services/config.service';
import { ConversionService } from 'src/app/services/conversion.service';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { RestService } from 'src/app/services/rest.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, SimpleChanges } from '@angular/core';
import { TranslatePipe } from 'src/app/translate.pipe';
import { By } from '@angular/platform-browser';
import { HttpService } from 'src/app/services/http.service';
import { PageContainerComponent } from './page-container.component';
import { Content } from '@angular/compiler/src/render3/r3_ast';


describe('PageContainerComponent', () => {
  let component: PageContainerComponent;
  let fixture: ComponentFixture<PageContainerComponent>;
  let configService: ConfigService;
  let conversionService: ConversionService;
  let formvalidatorService: FormvalidatorService;
  let restService: RestService;
  let httpService: HttpService;

  let data = {
    'fields':
    {
      'H_messageName': {
        'type': 'hidden',
        'hidden': true,
        'name': 'H_messageName',
        'order': 1252,
        'fieldClass': 'd-none',
        'data': 'M.CMS.AMBSAS.AS.GE.GET-LIST',
        'schema': {
          'type': 'string'
        }
      }

    }

  };


  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [PageContainerComponent, TranslatePipe],
      imports: [HttpClientTestingModule, RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [ConfigService, ConversionService, FormvalidatorService, RestService, HttpService]

    })
      .compileComponents();

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageContainerComponent);
    component = fixture.componentInstance;
    configService = TestBed.inject(ConfigService)
    conversionService = TestBed.inject(ConversionService);
    formvalidatorService = TestBed.inject(FormvalidatorService);
    restService = TestBed.inject(RestService)
    httpService = TestBed.inject(HttpService);

    component.content = {
      'pageId': '12345',

      'inputMessageName': '',
      'messageName': '',

      'fields': {
        'H_messageName': {
          'type': 'hidden',
          'hidden': true,
          'name': 'H_messageName',
          'order': 1252,
          'fieldClass': 'd-none',
          'data': 'M.CMS.AMBSAS.AS.GE.GET-LIST',
          'schema': {
            'type': 'string'
          }
        }

      },

      'splitToSections': [{
        'sectionId': 'test'

      }],
      'links': [
        {
          'linkId': 'button1000',
          'linkName': '01-Account Base Segment',
          'content': {
            '4003': '1',
            '4601': '30',
            '4602': '0001010100000000200',
            '9904': '0',
            'messageName': 'M.CMS.AMBSAS.AS.QU.QUERY1',
            'messageVersion': 'R00000'
          }
        },

        {
          'linkId': 'button1001',
          'linkName': '02-Credit Scores&Associated Parties',
          'content': {
            '4003': '1',
            '4601': '30',
            '4602': '0001010100000000200',
            '9904': '0',
            'messageName': 'M.CMS.AMBSAS.AS.QU.QUERY2',
            'messageVersion': 'R00000'
          }
        }

      ],
      'pageName': 'Account Details - ARMB/ARQB/ARAB - 01-Account Base Segment'
    }


    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should give proper value to messagename', () => {
    component.update(data);
    expect(component.messageName).toEqual('M.CMS.AMBSAS.AS.GE.GET-LIST')
  })

  it('should have blank message in mode2 after execution of update method', () => {
    component.update(data);
    expect(component.mode2).toEqual('')

  })

  it('should have correct mode2 value in case of Query or update in page name of argument of update method', () => {
    const data2 = { ...data, ...{ 'pageName': 'QUERY' } };
    component.update(data2);
    expect(component.mode2).toEqual('')
  })

  it('should give page id a proper value', () => {
    component.content = {
      'pageId': '1861332125'
    }
    component.ngOnInit();
    expect(component.pageId).toEqual(component.content.pageId);
  })



  it('should execute update method properly in case of undefined argument', () => {
    component.content = undefined;
    expect(component.update(component.content)).toBe(undefined);
  })

  it('should execute ngOninit properly ', () => {
    component.ngOnInit();
    expect(component.pageId).toBe(component.content.pageId);
  })

  it('should have toggle section button', () => {
    let toggle = fixture.debugElement.query(By.css('#toggleSection'))
    expect(toggle).toBeTruthy();
  })

  it('should call toggleSectionAndlinks function', () => {

    let toggle = fixture.debugElement.query(By.css('#toggleSection'))
    const checkCall = spyOn(component, 'toggleSectionsAndLinks');
    toggle.triggerEventHandler('click', null);
    expect(checkCall).toHaveBeenCalled();
  })

  it('should have help icon', () => {
    let help = fixture.debugElement.query(By.css('#help'))
    expect(help).toBeTruthy();
  })

  it('should call showHelpPage method on click help icon', () => {
    let help = fixture.debugElement.query(By.css('#help'))
    const checkCall = spyOn(component, 'showHelpPage');
    help.triggerEventHandler('click', null);
    expect(checkCall).toHaveBeenCalled();
  })

  it('should have Add to favourite icon when required', () => {

    spyOn(component, 'profileWorking').and.returnValue(true);
    spyOn(component, 'isFavourite').and.returnValue(false);
    //tick();
    fixture.detectChanges();
    let addFavourite = fixture.debugElement.query(By.css('#favourites'));
    expect(addFavourite).toBeTruthy();


  })

  it('should have remove to favourite icon when required', () => {

    spyOn(component, 'profileWorking').and.returnValue(true);
    spyOn(component, 'isFavourite').and.returnValue(true);
    fixture.detectChanges();
    let removeFavourite = fixture.debugElement.query(By.css('#remove'));
    expect(removeFavourite).toBeTruthy();

  })

  it('should have sibling conatainer', () => {
    let sibling = fixture.debugElement.query(By.css('#sibling'))
    expect(sibling).toBeTruthy();
  })

  it('should have listable conatainer', () => {

    component.content = {
      'table': {

      }
    }
    fixture.detectChanges();
    let listable = fixture.debugElement.query(By.css('#listable'))
    expect(listable).toBeTruthy();
  })



  it('should have crossReferenceRequired = true when only keyfields are present', () => {

    const content = {
      'pageId': '12345',

      'inputMessageName': '',
      'messageName': '',

      'fields': {
        'H_messageName': {
          'type': 'hidden',
          'hidden': true,
          'name': 'H_messageName',
          'order': 1252,
          'fieldClass': 'd-none',
          'data': 'M.CMS.AMBSAS.AS.GE.GET-LIST',
          'schema': {
            'type': 'string'
          }
        }, '4001': {
          'isKeyField': true,
          'name': '4001',
          'schema': {
            'type': 'string'
          }
        }

      },
      'pageName': 'Account Details - ARMB/ARQB/ARAB - 01-Account Base Segment'
    }
    component.content = content;
    component.update(content);
    expect(component.crossReferenceRequired).toBe(true);
    fixture.detectChanges();
    let crossReference = fixture.debugElement.query(By.css('#crossreference'))
    expect(crossReference).toBeTruthy();

  })

  it('should call clearCrossReference method on click crossreference icon', () => {
    const content = {
      'pageId': '12345',

      'inputMessageName': '',
      'messageName': '',

      'fields': {
        'H_messageName': {
          'type': 'hidden',
          'hidden': true,
          'name': 'H_messageName',
          'order': 1252,
          'fieldClass': 'd-none',
          'data': 'M.CMS.AMBSAS.AS.GE.GET-LIST',
          'schema': {
            'type': 'string'
          }
        }, '4001': {
          'isKeyField': true,
          'name': '4001',
          'schema': {
            'type': 'string'
          }
        }

      },
      'pageName': 'Account Details - ARMB/ARQB/ARAB - 01-Account Base Segment'
    }
    component.content = content;
    component.update(content);
    fixture.detectChanges();
    let crossreference = fixture.debugElement.query(By.css('#crossreference'))
    const checkCall = spyOn(component, 'clearCrossReference');
    crossreference.triggerEventHandler('click', new MouseEvent('click'));
    expect(checkCall).toHaveBeenCalled();
  })
  it('should have crossReferenceRequired = false when any non-key field is present', () => {
    component.content = {
      'pageId': '12345',

      'inputMessageName': '',
      'messageName': '',

      'fields': {
        'H_messageName': {
          'type': 'hidden',
          'hidden': true,
          'name': 'H_messageName',
          'order': 1252,
          'fieldClass': 'd-none',
          'data': 'M.CMS.AMBSAS.AS.GE.GET-LIST',
          'schema': {
            'type': 'string'
          }
        }, '4001': {
          'name': '4001',
          'schema': {
            'type': 'string'
          }
        }

      },
      'pageName': 'Account Details - ARMB/ARQB/ARAB - 01-Account Base Segment'
    }
    component.update(component.content);
    fixture.detectChanges();
    let crossReference = fixture.debugElement.query(By.css('#crossreference'))
    expect(component.crossReferenceRequired).toBe(false);
    expect(crossReference).not.toBeTruthy();


  })

  it('should have crossReferenceRequired = true value when messagename includes .I', () => {

    component.content = {
      'pageId': '12345',

      'inputMessageName': 'TESTING.I',
      'messageName': '',

      'fields': {
        'H_messageName': {
          'type': 'hidden',
          'hidden': true,
          'name': 'H_messageName',
          'order': 1252,
          'fieldClass': 'd-none',
          'data': 'TESTING.I',
          'schema': {
            'type': 'string'
          }
        }, '4001': {
          'name': '4001',
          'schema': {
            'type': 'string'
          }
        }

      },
      'pageName': 'Account Details - ARMB/ARQB/ARAB - 01-Account Base Segment'
    }
    component.update(component.content);
    fixture.detectChanges();
    let crossReference = fixture.debugElement.query(By.css('#crossreference'))
    expect(component.crossReferenceRequired).toBe(true);
    expect(crossReference).toBeTruthy();


  })


  it('should have crossReferenceRequired false value when messagename dont includes .I and when content.field  have any numeric field name which dont have isKeyField field', () => {
    component.content = {
      'pageId': '12345',

      'inputMessageName': '',
      'messageName': '',

      'fields': {
        'H_messageName': {
          'type': 'hidden',
          'hidden': true,
          'name': 'H_messageName',
          'order': 1252,
          'fieldClass': 'd-none',
          'data': 'M.CMS.AMBSAS.AS.GE.GET-LIST',
          'schema': {
            'type': 'string'
          }
        }, '4001': {
          'isKeyField': true,
          'name': '4001',
          'schema': {
            'type': 'string'
          }
        }

      },
      'pageName': 'Account Details - ARMB/ARQB/ARAB - 01-Account Base Segment'
    };
    fixture.detectChanges();
    let crossReference = fixture.debugElement.query(By.css('#crossreference'))
    expect(component.crossReferenceRequired).toBe(false);
    expect(crossReference).not.toBeTruthy();
  })

});
