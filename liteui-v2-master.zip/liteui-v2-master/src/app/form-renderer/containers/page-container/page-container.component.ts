import { ProfileService } from 'src/app/services/profile.service';
import { Component, Input, OnInit, OnChanges, OnDestroy, SimpleChanges } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router, RouterEvent } from '@angular/router';
import { RestService } from 'src/app/services/rest.service';
import { MaskingService } from 'src/app/services/masking.service';
import { ConfigService } from 'src/app/services/config.service';
import { ConversionService } from 'src/app/services/conversion.service';
import { NodemapService } from 'src/app/services/nodemap.service';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { debug } from 'console';


@Component({
  selector: 'app-page-container',
  templateUrl: './page-container.component.html',
  styleUrls: ['./page-container.component.scss']
})
export class PageContainerComponent implements OnInit, OnChanges, OnDestroy {

  @Input() content: any;
  @Input() options: any;
  clicked: Array<Node>[];
  activeSection = '';
  mode: any;
  mode1: any;
  mode2 = ' - ';
  messageName = '';
  pageId = '';
  brdcrumb:any;
  filterData: any = [];
  changeGridPath: any;
  errorTableFieds: any = [];
  crossReferenceRequired=false;
  sectiontoggle = true;
  constructor(private profileService: ProfileService,
              private restService: RestService,
              private nodemapService: NodemapService,
              private maskingService: MaskingService,
              private configService: ConfigService,
              private formValidatorService: FormvalidatorService) {
  }

  ngOnInit(): void {
    if(!this.content){
      return;
    }
    this.pageId = this.content.pageId;
    if(this.content.pageData == 'makerChecker'){
      this.formValidatorService.setOptions(this.pageId, this.content);
    }
  }
  addFavourites() {
    this.profileService.addFavourites(this.messageName);
  }
  isFavourite() {
    return this.profileService.isFavourite(this.messageName);
  }
  removeFavourites() {
    this.profileService.deleteFavourites(this.messageName);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.content.currentValue === undefined) return;
    if(changes.content.currentValue?.pageData === 'makerChecker'){
      this.ngOnInit();
      this.update(this.formValidatorService.getOptions(this.pageId));
     }else{
    this.pageId = crypto.getRandomValues(new Uint8Array(4)).join('').toString();
    this.content = changes.content.currentValue;
    this.content.pageId = this.pageId;
    this.formValidatorService.setOptions(this.pageId, this.content);
    this.update(this.content);
     }
   }
  update(content) {

    if (content === undefined) {
      return;
    }

   this.messageName = content.inputMessageName || content.fields.H_messageName?.data;
  


    if (this.messageName === undefined) {
      const newContent = this.content;
      newContent.fields = { ...this.content.fields, ...content.fields };
      this.content = newContent;
      this.messageName = this.content.inputMessageName || this.content.fields.H_messageName?.data;
    } else {

      this.content = content;
    }

    this.mode = this.messageName?.split('\.');
    this.mode1 = this.mode[this.mode.length - 1];
    this.mode2 = this.mode1.slice(0, this.mode1.length - 1);

    if ( this.mode2 === 'QUERY' || this.mode2 === 'UPDATE') {
      if (this.content.pageName.indexOf(this.mode2) >= 0) {
        this.mode2 = '';
      }
    } else {
      this.mode2 = '';
    }
    if ( this.mode2.length > 0) {this.mode2 = ' - ' + this.mode2; }
    this.clicked = this.nodemapService.nodeMap[this.messageName]?.parent;
    this.activeSection = this.content.splitToSections ? this.content.splitToSections[0].sectionId : '';

    if (this.messageName.includes('.I')) {
      this.crossReferenceRequired = true;
    }
    else {
      for (const x of Object.keys(content.fields)) {
        if (isNaN(Number(x))){
          continue;
        }
        if (content.fields[x].isKeyField) {
          this.crossReferenceRequired = true; 
        } else {
          this.crossReferenceRequired = false; 
          break;
        }
      }
    }


    this.updateFieldsError();
    document.getElementById('formPage')?.scrollTo(0, 0);
    this.ngOnInit();
  }
  setActiveSection(section) {
    if (section !== undefined) {
      this.activeSection = section;
    }
  }
  getContent() {
    this.content = this.formValidatorService.getOptions(this.pageId);
    return this.content;
  }

  updateFieldsError() {
   Object.keys(this.content.fields).forEach(key => {
      const x = this.content.fields[key];
      if (x.name.startsWith('ERR')) {
        const msg = x.schema.title;
        if (msg === undefined || msg === '') { return; }
        const err = msg.substring(4, 8);
        const errorField = Object.keys(this.content.fields).filter(x => x.match(err));
        if(this.content.tableGridJsonPaths.length > 0) {
          this.content.tableGridJsonPaths.forEach(el => {
            this.changeGridPath = el.replaceAll('$.', '').replaceAll('.', '.fields.').split('.');
            //this.filterData = this.content.fields;
            this.changeGridPath.forEach(element => {
              this.filterData.push(this.content.fields[element]);
            })
            this.filterData = this.filterData.filter(item => item);
          })
          this.filterData.forEach(data=>{
            let table = 'table'+ data.name.split('object')[1];
            Object.keys(data.fields[table].fields).forEach(e =>  {
              if(e.match(err)) {
                this.errorTableFieds.push(data.name);
              }});
          });
        }
        if (errorField) {
          errorField.forEach(x => {
            this.content.fields[x].hasError = true;
            this.content.splitToSections?.forEach(section => {
              if (section.sectionId === this.content.fields[x].sectionId) {
                section.hasError = true;
              }
            });
          });
         }
         if(this.errorTableFieds) {
          this.errorTableFieds.forEach(tableField => {  
            let table = 'table'+ tableField.split('object')[1];          
            this.content.splitToSections?.forEach(section => {
              if (section.sectionId === this.content.fields[tableField].sectionId) {
                section.hasError = true;
              }
            });
            this.content.fields[tableField].fields[table].fields[err].hasError = true;            
          })
         }
      }
    });
  }
  clearCrossReference() {
    this.configService.resetCrossReferenceRepo();
    this.maskingService.resetMaskingRepo();
    this.restService.gotoPage({
      linkName: 'Something',
      content: {
        messageName: this.messageName,
        messageVersion: 'R00000'
      }
    });
  }
  showHelpPage(event: MouseEvent) {
    const format = this.formValidatorService.config.documentationFormat;
    if (format === 'default') {
      const message = this.formValidatorService.getFormGroup(this.pageId).value.H_messageName;
      const url = '#/help;message=' + message;
      this.formValidatorService.showDocs(url);
    } else {
      const message = this.formValidatorService.getOptions(this.pageId).pageName.replaceAll('/', '_');
      this.formValidatorService.showDocs(message);
    }
    event.preventDefault();
  }
  profileWorking() {
    return this.profileService.serviceStatus;
  }
  toggleSectionsAndLinks(){
    this.sectiontoggle = !this.sectiontoggle;
  }
  ngOnDestroy() {
    
  }
}
