import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TranslatePipe } from 'src/app/translate.pipe';
import { SectionLinkContainerComponent } from './section-link-container.component';
import { By } from '@angular/platform-browser';
import { ConfigService } from 'src/app/services/config.service';
import { TranslationService } from 'src/app/services/translation.service';
import { element } from 'protractor';

describe('SectionLinkContainerComponent', () => {
  let component: SectionLinkContainerComponent;
  let fixture: ComponentFixture<SectionLinkContainerComponent>;
  let translationService:TranslationService;
  let configService:ConfigService;
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ SectionLinkContainerComponent,TranslatePipe],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[TranslationService,ConfigService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SectionLinkContainerComponent);
    component = fixture.componentInstance;
    component.sections=
    [
        {
            'sectionId': 'section1001',
            'sectionName': '01-Account Details'
        },
        {
            'sectionId': 'section1002',
            'sectionName': '02-Relationship Details'
        }
    ]
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have correct heading',()=>{
    // creating reference for html element
    const ref: DebugElement = fixture.debugElement;
    const heading = ref.query(By.css('#heading'));
    const displayEle: HTMLElement = heading.nativeElement
    fixture.detectChanges();
    expect(displayEle.textContent).toBe('Sections');
  })

  it('should have correct section name',()=>{
    const sectionName1=fixture.debugElement.queryAll(By.css('#section'))
    expect(sectionName1.length).toEqual(component.sections.length);
    expect(sectionName1).toBeTruthy();
    component.sections.forEach((sectionName,index)=>{
    expect(sectionName1[index].properties.innerHTML).toEqual(component.sections[index].sectionName);
     })
  })

  it('section name should call setActive nethod on click',()=>{
    let section=fixture.debugElement.query(By.css('#section'))
    const checkCall=spyOn(component,'setActive');
    section.triggerEventHandler('click',null);
    expect(checkCall).toHaveBeenCalled();
  })


});
