import { Component, EventEmitter, Input, OnInit, Output, OnChanges, SimpleChanges, SimpleChange } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-section-link-container',
  templateUrl: './section-link-container.component.html',
  styleUrls: ['./section-link-container.component.css']
})
export class SectionLinkContainerComponent implements OnInit {
  @Input() sections: any = [];
  @Output() activeSection = new EventEmitter();
  links: any;
    
  constructor( private route: ActivatedRoute ) { }

  ngOnInit(): void {
    this.setActive(this.sections[0]);
  }
  ngOnChanges(changes: SimpleChanges): void {
    const linksChange: SimpleChange = changes.links;
    linksChange && linksChange.currentValue && this.links.forEach(link => {link.active = link.content.messageName === this.route.snapshot.params.name })
  }
  setActive(section) {
	this.sections.forEach(x => {x.active = section.sectionId === x.sectionId ; });
    this.activeSection.emit(section.sectionId);
  }

}
