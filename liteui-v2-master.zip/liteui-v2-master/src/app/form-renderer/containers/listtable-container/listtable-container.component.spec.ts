import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { Config, ConfigService } from 'src/app/services/config.service';
import { ConversionService } from 'src/app/services/conversion.service';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { RestService } from 'src/app/services/rest.service';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslatePipe } from 'src/app/translate.pipe';
import { By } from '@angular/platform-browser';
import { MaskingPipe } from 'src/app/masking.pipe';
import { ExcelService } from 'src/app/services/excel.service';
import { HttpService } from 'src/app/services/http.service';


import { ListtableContainerComponent } from './listtable-container.component';
import { isNgTemplate } from '@angular/compiler';
import { Observable } from 'rxjs/internal/Observable';


class MockRestService extends RestService {
  post(content: any): Observable<any> {
    const data = Observable.create( observer => 
      observer.complete()
    )

    return data;

}
}

describe('ListtableContainerComponent', () => {
  let component: ListtableContainerComponent;
  let fixture: ComponentFixture<ListtableContainerComponent>;
  let configService:ConfigService;
  let conversionService:ConversionService;
  let formvalidatorService:FormvalidatorService;
  let restService:RestService;
  let httpService:HttpService;
  let excelService:ExcelService
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListtableContainerComponent,TranslatePipe,MaskingPipe],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[ConfigService,ExcelService,ConversionService,FormvalidatorService,RestService,HttpService, {
        provide: RestService,
        useClass:MockRestService
    }]

    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListtableContainerComponent);
    component = fixture.componentInstance;
    configService=TestBed.inject(ConfigService)
    conversionService=TestBed.inject(ConversionService);
    formvalidatorService=TestBed.inject(FormvalidatorService);
    restService=TestBed.inject(RestService)
    httpService=TestBed.inject(HttpService);
    configService.config={
      'remoteUrl': 'https://d4dvwb001.1dc.com/devddmc',
      'loginRequest': '',
      'showSearch': null,
      'menuMessage': '',
      'searchRequest': '',
      'displayDashboard':null,
      'dashboardTitle': '',
      'loginPageTitle':'',
      'documentTitle':'',
      'defaultDateFormat':'',
      'enableRSA':true,
      'profileMessage':'',
      'makerChecker':'',
      'appCodes':'',
      'selectedTheme':null,
      'themeOptions': [],
      'defaultMask':'',
      'enableMask':false,
      'maskByXref': null,
      'maskXrefRepository':[],
      'maskRepository': [],
      'formChangesLimit':null,
      'languages':[],
      'timeOutDuration': null,
      'fileSetChange': '',
      'fileSetChange': '',
      'documentationFormat': '',
      'documentationRepository': '',
      'ssoLogin':null
    }


    component.content={

      'fields':{
        '4003':{
        'type': 'number',
        'readonly': false,
        'hidden': false,
        'label': 'Product(Req only for ADD)',
        'name': '4003',
        'isKeyField': true,
        'crossReference': 'CMSLOGO',
        'order': 3,
        'fieldClass': 'col-12',
        'data': '000',
        'schema': {
            'type': 'number',
            'required': true,
            'default': 0,
            'minimum': 0,
            'maximum': 998,
            'title': 'Product(Req only for ADD)'
        }
      },
      '4601':{
        'type': 'number',
    'readonly': false,
    'hidden': false,
    'label': ' Business Unit(Req only for ADD)',
    'name': '4601',
    'isKeyField': true,
    'crossReference': 'CMSORG',
    'order': 1,
    'fieldClass': 'col-12',
    'data': '000',
    'schema': {
        'type': 'number',
        'required': true,
        'default': 0,
        'minimum': 0,
        'maximum': 999,
        'title': ' Business Unit(Req only for ADD)'
    }
      },
      '4602':{
        
          'readonly': false,
          'hidden': false,
          'label': ' Account Number  ',
          'crossReference': 'CMSACCT',
          'name': '4602',
          'isKeyField': true,
          'order': 2,
          'fieldClass': 'col-12',
          'data': '                   ',
          'schema': {
              'type': 'string',
              'title': ' Account Number  ',
              'required': true,
              'format': 'uppercase',
              'maxLength': 19
          },
          'type': 'text'
      
      },

      '9904':{
        'type': 'number',
        'readonly': false,
        'hidden': false,
        'label': 'Billing Acct Ind(Req only for ADD)',
        'name': '9904',
        'isKeyField': true,
        'order': 4,
        'fieldClass': 'col-12',
        'data': '0',
        'schema': {
            'type': 'number',
            'required': true,
            'default': 0,
            'minimum': 0,
            'maximum': 3,
            'title': 'Billing Acct Ind(Req only for ADD)'
        }
    },
      'H_prevToken':{
        'type': 'hidden',
        'hidden': true,
        'name': 'H_prevToken',
        'order': 1251,
        'fieldClass': 'd-none',
        'data': 'f0f3f0f0f0f0f1f0f1f0f1f0f0f0f0f0f0f0f0f2f0f040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040',
        'schema': {
            'type': 'string'
        }
      },
      'H_nextToken':{
        'type': 'hidden',
        'hidden': true,
        'name': 'H_nextToken',
        'order': 1257,
        'fieldClass': 'd-none',
        'data': 'f0f3f0f0f0f0f1f0f1f0f1f0f0f0f0f0f0f0f1f0f9f040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040',
        'schema': {
        'type': 'string'
    }
      },
      'H_itemsPerPage':{
        'type': 'hidden',
        'hidden': true,
        'name': 'H_itemsPerPage',
        'order': 1267,
        'fieldClass': 'd-none',
        'data': '20',
        'schema': {
            'type': 'string'
        }
      }
      },

      'table':{

      
      'header':
    [
      {
        'fieldCode': '4601',
        'editable': false,
        'optionLabels': {},
        'label': ' Business Unit(Req only for ADD)'
    },
    {
        'fieldCode': '4602',
        'editable': false,
        'optionLabels': {},
        'label': ' Account Number  '
    },
    {
        'fieldCode': '4003',
        'editable': false,
        'optionLabels': {},
        'label': 'Product(Req only for ADD)'
    },
    {
        'fieldCode': '9904',
        'editable': false,
        'optionLabels': {},
        'label': 'Billing Acct Ind(Req only for ADD)'
    }
    ],
    'actionitems':[
          
    {
      'mode': 'QUERY',
      'label': 'Inquiry',
      'tableKeyMapping': [
          {
              'source': '4601',
              'target': '4601'
          },
          {
              'source': '4602',
              'target': '4602'
          },
          {
              'source': '4003',
              'target': '4003'
          },
          {
              'source': '9904',
              'target': '9904'
          }
      ],
      'content': {
          'messageName': 'M.CMS.AMBSAS.AS.QU.QUERY1',
          'language': 'EN',
          'messageVersion': 'R00000'
      }
  },
  {
      'mode': 'UPDATE',
      'label': 'Maintenance',
      'tableKeyMapping': [
          {
              'source': '4601',
              'target': '4601'
          },
          {
              'source': '4602',
              'target': '4602'
          },
          {
              'source': '4003',
              'target': '4003'
          },
          {
              'source': '9904',
              'target': '9904'
          }
      ],
      'content': {
          'messageName': 'M.CMS.AMBSAS.AS.UP.UPDATE1',
          'language': 'EN',
          'messageVersion': 'R00000'
      }
  }
    ],
    'tabledata':[
      {
        '4003': '1',
        '4601': '30',
        '4602': '0001010100000000200',
        '9904': '0',
        '0111': '',
        '0301': '003',
        '0302': '',
        '0109': 'A',
        '0125': '',
        '0127': ''
      }

    ],

    'actionButtons':[
      {
      'messageName': 'M.CMS.AMBSAS.AS.AD.ADD-ALL1',
      'messageMode': 'ADD',
      'language': 'EN',
      'messageVersion': 'R00000',
      'actionName': 'Add Record'
    }
  ]
  
  }
}

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have correct action buttons',()=>{
    const actionButtons=fixture.debugElement.queryAll(By.css('#actionBtn'))
    expect(actionButtons.length).toEqual(component.content.table.actionButtons.length);
    component.content.table.actionButtons.forEach((buttonsName,index)=>{
      expect(actionButtons[index].attributes.value).toEqual(component.content.table.actionButtons[index].value);
     })
  

  })


  it('should have correct table header',()=>{
    let headerLabel=[];
    for(let i=0;i<component.content.table.header.length;i++){
      if(!component.content.fields[component.content.table.header[i]]?.hidden){
        headerLabel.push(component.content.table.header[i].header);

      }
    }

    const titleLabel=fixture.debugElement.queryAll(By.css('#headerBtn'))
    expect(titleLabel.length).toEqual(headerLabel.length);

    headerLabel.forEach((buttonsName,index)=>{
      expect(titleLabel[index].attributes.value).toEqual(headerLabel[index]);
     }) 
  })

  it('should have action items',()=>{
    const actionItems=fixture.debugElement.queryAll(By.css('#actionItems'))
    const inquiry=fixture.debugElement.queryAll(By.css('#inquiry'))
    const maintain=fixture.debugElement.queryAll(By.css('#maintenance'))
    const copy=fixture.debugElement.queryAll(By.css('#copy'))
    const del=fixture.debugElement.queryAll(By.css('#delete'))


    actionItems.forEach((items,index)=>{
          if(actionItems[index].attributes.value==='Inquiry' || actionItems[index].attributes.value==='Maintenance'){
          expect(inquiry).toBeTruthy();
          expect(maintain).toBeTruthy()
          
        }
        else{
          expect(copy).toBeTruthy();
          expect(del).toBeTruthy()

        }
    })

  })


  it('should have correct exit button',()=>{
      const exit=fixture.debugElement.queryAll(By.css('#exit'))
      expect(exit).toBeTruthy();
  })

  it('should have previous button',()=>{
    const prev=fixture.debugElement.queryAll(By.css('#previous'))
    expect(prev).toBeTruthy();
  })

  it('should have next buttons',()=>{
    const next=fixture.debugElement.queryAll(By.css('#next'))
    expect(next).toBeTruthy();

  })

  it('Action button should call gotoAdd method',()=>{
    let actionButtons = fixture.debugElement.query(By.css('#actionBtn'));
    
    const fnc=spyOn(component,'gotoAddPage');
    actionButtons.triggerEventHandler('click', null);   
    expect(fnc).toHaveBeenCalled();
    
  })

  it('table header should call open url',()=>{
    let header=fixture.debugElement.query(By.css('#headerBtn'))
    const checkCall=spyOn(component,'openurl');
    header.triggerEventHandler('click',null);
    expect(checkCall).toHaveBeenCalled();
  })

  it('Previous button should call page flow',()=>{
    let previous=fixture.debugElement.query(By.css('#previous'))
    const checkCall=spyOn(component,'pageFlow');
    previous.triggerEventHandler('click',null);
    expect(checkCall).toHaveBeenCalled();
  })

  it('Next button should call page flow',()=>{
    let next=fixture.debugElement.query(By.css('#next'))
    const checkCall=spyOn(component,'pageFlow');
    next.triggerEventHandler('click',null);
    expect(checkCall).toHaveBeenCalled();
  })
  
  it('First radio button should call page flow',()=>{
    let radio1=fixture.debugElement.query(By.css('#option1'))
    const checkCall=spyOn(component,'pageFlow');
    radio1.triggerEventHandler('click',null);
    expect(checkCall).toHaveBeenCalled();
  })

  it('Second radio button should call page flow',()=>{
    let radio2=fixture.debugElement.query(By.css('#option2'))
    const checkCall=spyOn(component,'pageFlow');
    radio2.triggerEventHandler('click',null);
    expect(checkCall).toHaveBeenCalled();
  })


  it('containerActive should have true value after execution of page flow with itemperPage==20',()=>{
    component.pageFlow('N',20);
    expect(component.containerActive).toEqual(true);
  })

  it('containerActive should have false value after execution of page flow with itemperPage==50',()=>{
    component.pageFlow('N',50);
    expect(component.containerActive).toEqual(false);
  })

  it('itemno should have correct value after execution of page flow with itemperPage>0',()=>{
    component.pageFlow('N',20);
    expect(component.itemno).toEqual(20);
    expect(component.content.fields.H_itemsPerPage.data).toBe(component.itemno)
  })

  it('component.content.field.H_itemPerPage.data should have correct value after execution of page flow with itemperPage>0',()=>{
    component.pageFlow('N',20);
    expect(component.content.fields.H_itemsPerPage.data).toBe(component.itemno)
  })


});
