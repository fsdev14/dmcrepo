import { Component, Input, OnChanges, OnInit, SimpleChanges, EventEmitter, Output } from '@angular/core';
import { FormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/auth/auth.service';
import { Config, ConfigService } from 'src/app/services/config.service';
import { ConversionService } from 'src/app/services/conversion.service';
import { ExcelService } from 'src/app/services/excel.service';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { RestService } from 'src/app/services/rest.service';

@Component({
  selector: 'app-listtable-container',
  templateUrl: './listtable-container.component.html',
  styleUrls: ['./listtable-container.component.css']
})
export class ListtableContainerComponent implements OnInit, OnChanges {
  @Input() content: any;
  @Output() response: EventEmitter<any> = new EventEmitter<any>();
  config: Config;
  optionLabelFields: any = {};
  errorFields = [];
  fields = [];
  itemno: number;
  containerActive = true;
  lastNextToken = ' ';
  lastPrevToken = ' ';
  tableContainer: HTMLElement;
  tbodyElement: HTMLElement;
  form: UntypedFormGroup;
  typeOneUser = false;

  constructor(private configService: ConfigService,
              private conversionService: ConversionService,
              private restService: RestService,
              private formValidatorService: FormvalidatorService,
              private excelService: ExcelService,
			        private router: Router,
              private authService: AuthService) {
      this.config = this.configService.config;
    }
  ngOnChanges(changes: SimpleChanges): void {
    this.ngOnInit();
  }
  ngOnInit(): void {
    this.typeOneUser = this.authService.typeOneUser;
    this.optionLabelFields = {};
    for (const obj of this.content.table.header) {
        this.optionLabelFields[obj.fieldCode] = obj.optionLabels;
    }
    const allFields: any = Object.keys(this.content.fields).map(e => this.content.fields[e]);
    this.fields = allFields.filter( x => (!x.isKeyField && !x.name.startsWith('ERR')) );
    this.errorFields = allFields.filter(x => x.name.startsWith('ERR') );
  }
  getKeys(o: any) {
    return Object.keys(o);
  }

  gotoAddPage(item: any) {
    const request = { content: {}, groupName: ''};
    request.content = item;
    this.restService.gotoPage(request);
  }
  gotoPage(node, row) {
    const request = {content: {}};
    const linkName = 'linkName';
    request.content = node.content;
    for (const mapping of node.tableKeyMapping) {
      request.content[mapping.target] = row[mapping.source];
    }
    request[linkName] = this.content.pageName;
    this.restService.gotoPage(request);

  }
  showDataOrLabel(item, field) {
    const data = item[field];
    return this.optionLabelFields[field][data] || data;
  }
    ExitFlow(){
     this.restService.resetTableView();
     this.restService.navigateToPage(this.content.messageName);
   }

 pageFlow(direction, itemsPerPage) {
   if (itemsPerPage == 50){
    this.containerActive = false;
   }
   else if (itemsPerPage == 20){
    this.containerActive = true;
   }

   if (itemsPerPage > 0 && this.content.fields.H_itemsPerPage.data !== itemsPerPage) {
     // meaning we changed the itemsperPage value only. need to reset the prevToken and nextToken
    this.content.fields.H_nextToken.data = this.lastNextToken;
    this.content.fields.H_prevToken.data = this.lastPrevToken;
   }

   const request = {};
   const linkName = 'linkName';
   const pageFlowFlag = 'pageFlowFlag';
   if (itemsPerPage > 0) {
      this.itemno = itemsPerPage;
    }
   if (this.itemno > 0) {
      this.content.fields.H_itemsPerPage.data = this.itemno;
    }
   for (const field of Object.keys(this.content.fields)) {

      if (field.startsWith('ERR')) { continue; }
      request[field] = this.formValidatorService.formattedValue(this.content.fields[field], this.content.fields[field].data, '');
    }
	if(this.restService.lastResponse.table.pageFlowFlag == 'P' && (itemsPerPage == 20 || itemsPerPage == 50)){
      request[pageFlowFlag] = 'P';
    }
    else{
      request[pageFlowFlag] = direction;
    }
   this.lastNextToken = this.content.fields.H_nextToken.data;
   this.lastPrevToken = this.content.fields.H_prevToken.data;
   this.restService.post(request)
      .subscribe(response => {
        this.content = this.conversionService.convert(this.restService.parse(response));
      });
  }

  flowDisabled(flow: string): boolean {
    let a = [];
    let disabled = false;
    switch (flow) {
      case 'P':
        disabled = true;
        a = this.hexToASCII(this.content.fields.H_prevToken.data).split('');
        // tslint: ignore
        for (let i = 0; i < a.length; i++) {
          if (a[i] !== '0') {
            disabled = false;
            break;
          }
        }
        return disabled;
      case 'N':
        disabled = true;
        a = this.hexToASCII(this.content.fields.H_nextToken.data).split('');
        // tslint: ignore
        for (let i = 0; i < a.length; i++) {
          if (a[i] !== '9') {
            disabled = false;
            break;
          }
        }
        return disabled;
      default:
          return true;
    }
    return false;
  }

  hexToASCII(hexstring: string): string {
    return hexstring.match(/.{1,2}/g)
      .map((v) => v.substring(1))
      .join('');
  }


  openurl(event) {
    const format = this.formValidatorService.config.documentationFormat;
    if (format === 'default') {
      const message = this.form.value.H_messageName;
      const name = event;
      const url = '#/help;message=' + message + ';name=' + name;
      this.formValidatorService.showDocs(url);
    } else {
      const message = this.formValidatorService.getOptions(this.content.pageId).pageName.replaceAll('/', '_');
      this.formValidatorService.showDocs(message);
    }
  }

  exportAsXLSX():void {
    window.alert('Your request is being processed...\nTable will be available shortly.');
    this.excelService.dataMappingListtable(this.content.table.tabledata, this.content.table.header, 'table_data');
  }

canScrollFurther(side: string): boolean {
    this.tableContainer = document.getElementById('container');
    const element = this.tableContainer;
    this.tbodyElement= document.getElementById('tbody');
    if(side=='left'){
      return  element.scrollLeft > 0 || this.tbodyElement.scrollLeft > 0
    }
    else{
      return element.scrollLeft+element.clientWidth < this.tbodyElement.scrollWidth-this.tbodyElement.scrollLeft;
    }
  }


  scrollTable(side: string) {
    let amount = +500;
    switch (side) {
      case 'left':
        amount = -500;
        break;
      case 'right':
        amount = +500;
        break;
    }
  
    this.tableContainer.scrollBy({
      top: 0,
      left: amount,
      behavior: 'smooth'
    });
  }



}
