import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormControl, FormsModule, Validators } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { Component, DebugElement, Input, NgModule, NO_ERRORS_SCHEMA, OnChanges, OnDestroy, OnInit, SimpleChange, SimpleChanges } from '@angular/core';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { By } from '@angular/platform-browser';
import { TranslatePipe } from 'src/app/translate.pipe';
import { Config, ConfigService } from 'src/app/services/config.service';
import { ConversionService } from 'src/app/services/conversion.service';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { MaskingService } from 'src/app/services/masking.service';
import { RestService } from 'src/app/services/rest.service';
import { SearchService } from 'src/app/services/search.service';
import { FormContainerComponent } from './form-container.component';

describe('FormContainerComponent', () => {
  let component: FormContainerComponent;
  let fixture: ComponentFixture<FormContainerComponent>;
  let configService:ConfigService;
  let conversionService:ConversionService;
  let formvalidatorService:FormvalidatorService;
  let maskingService:MaskingService;
  let restService:RestService;
  let searchService:SearchService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ FormContainerComponent,TranslatePipe ],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([]),FormsModule],
      schemas: [NO_ERRORS_SCHEMA,CUSTOM_ELEMENTS_SCHEMA],
      providers:[ConfigService,ConversionService,FormvalidatorService,MaskingService,RestService,SearchService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormContainerComponent);
    component = fixture.componentInstance;
    configService=TestBed.inject(ConfigService);
    conversionService=TestBed.inject(ConversionService);
    formvalidatorService=TestBed.inject(FormvalidatorService);
    maskingService=TestBed.inject(MaskingService);
    restService=TestBed.inject(RestService);
    searchService=TestBed.inject(SearchService);

    component.errorFields=[
      {
        'type': 'label',
        'hidden': true,
        'view': 'fullPage-top',
        'name': 'ERR1',
        'fieldClass': '',
        'label': '',
        'schema': {
            'type': 'string',
            'title': ''
        }
    }
    ]

    component.keyFields=[
      {
        'readonly': true,
        'hidden': false,
        'label': 'Primary Key Field',
        'name': '5001',
        'isKeyField': true,
        'sectionId': 'section1001',
        'order': 1,
        'fieldClass': 'col-lg-8 col-md-12 col-xxl-4 col-xxl-4 col-xxl-4',
        'data': 'TEST*',
        'view': 'key',
        'schema': {
            'type': 'string',
            'title': 'Primary Key Field',
            'required': true,
            'format': 'uppercase',
            'maxLength': 60
        },
        'type': 'text'
    }
    ]


    component.options=
    
    {
      'pageId':'123456',
      'fields':{

        '4003': {
            'type': 'number',
            'readonly': false,
            'hidden': false,
            'label': 'Product(Req only for ADD)',
            'name': '4003',
            'isKeyField': true,
            'crossReference': 'CMSLOGO',
            'order': 3,
            'fieldClass': 'col-12',
            'data': '0',
            'schema': {
                'type': 'number',
                'required': true,
                'default': 0,
                'minimum': 0,
                'maximum': 998,
                'title': 'Product(Req only for ADD)'
            }
        },
        '4601': {
            'type': 'number',
            'readonly': false,
            'hidden': false,
            'label': ' Business Unit(Req only for ADD)',
            'name': '4601',
            'isKeyField': true,
            'crossReference': 'CMSORG',
            'order': 1,
            'fieldClass': 'col-12',
            'data': '0',
            'schema': {
                'type': 'number',
                'required': true,
                'default': 0,
                'minimum': 0,
                'maximum': 999,
                'title': ' Business Unit(Req only for ADD)'
            }
        },
        '4602': {
            'readonly': false,
            'hidden': false,
            'label': ' Account Number  ',
            'crossReference': 'CMSACCT',
            'name': '4602',
            'isKeyField': true,
            'order': 2,
            'fieldClass': 'col-12',
            'data': ' ',
            'schema': {
                'type': 'string',
                'title': ' Account Number  ',
                'required': true,
                'format': 'uppercase',
                'maxLength': 19
            },
            'type': 'text'
        },
        '9904': {
            'type': 'number',
            'readonly': false,
            'hidden': false,
            'label': 'Billing Acct Ind(Req only for ADD)',
            'name': '9904',
            'isKeyField': true,
            'order': 4,
            'fieldClass': 'col-12',
            'data': '0',
            'schema': {
                'type': 'number',
                'required': true,
                'default': 0,
                'minimum': 0,
                'maximum': 3,
                'title': 'Billing Acct Ind(Req only for ADD)'
            }
        },
        'ERR1': {
            'type': 'label',
            'hidden': true,
            'name': 'ERR1',
            'fieldClass': '',
            'label': '',
            'schema': {
                'type': 'string',
                'title': ''
            }
        }
    }
  }
  component.fields=[
    {
      'readonly': true,
      'hidden': true,
      'name': '5999',
      'sectionId': 'section1001',
      'order': 2,
      'fieldClass': 'd-none',
      'data': '',
      'view': 'fullPage-bottom',
      'schema': {
          'type': 'string',
          'format': 'uppercase',
          'maxLength': 422
      },
      'type': 'text'
  },
  {
    'readonly': true,
    'hidden': false,
    'label': 'Last Name',
    'name': '5055',
    'sectionId': 'section1001',
    'order': 3,
    'fieldClass': 'col-lg-8 col-md-12 col-xxl-4 col-xxl-4 col-xxl-4',
    'data': '',
    'view': 'nonkey',
    'schema': {
        'type': 'string',
        'title': 'Last Name',
        'format': 'uppercase',
        'maxLength': 40
    },
    'type': 'text'
}
  ]
  component.showPopup=true;
  
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  
  it('should have error fields',()=>{
    let error=fixture.debugElement.queryAll(By.css('#errorFields'))
    let error2=fixture.debugElement.queryAll(By.css('#error'))
    expect(error2.length).toBe(component.errorFields.length)
    expect(error).toBeTruthy();
  })


  it('should have keyFields ',()=>{
    let keyFields=fixture.debugElement.queryAll(By.css('#keyFields'))
    let keyFields2=fixture.debugElement.queryAll(By.css('#keyfields'))
    expect(keyFields2.length).toBe(component.keyFields.length)
    
    expect(keyFields).toBeTruthy();
  })

  it('should have Fields ',()=>{
    let fields=fixture.debugElement.queryAll(By.css('#fields'))
    
    expect(fields.length).toBe(component.fields.length)
    
    expect(fields).toBeTruthy();
  })

  it('should have buttonBars ',()=>{
    let buttonBar=fixture.debugElement.queryAll(By.css('#button-bar'))
    let buttonContainer=fixture.debugElement.queryAll(By.css('#buttonContainer'))
    expect(buttonContainer).toBeTruthy();
    expect(buttonBar).toBeTruthy();
  })

  it('should have show msg pop up when showPop up true',()=>{
    
    let popMsg=fixture.debugElement.query(By.css('#showMsg'))
    expect(popMsg).toBeTruthy();
  })

  it('should have close pop up button',()=>{
    
    let popMsg=fixture.debugElement.query(By.css('#popup'))
    expect(popMsg).toBeTruthy();
    let checkCall=spyOn(component,'closePopup')
    popMsg.triggerEventHandler(null,'click');
    expect(checkCall).toHaveBeenCalled();
  })

});
