import { Component, EventEmitter, OnInit, Input, OnDestroy, OnChanges, Output, SimpleChanges } from '@angular/core';
import { FormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Config, ConfigService } from 'src/app/services/config.service';
import { ConversionService } from 'src/app/services/conversion.service';
import { ErrorHandlingService } from 'src/app/services/errorHandling.service';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { MaskingService } from 'src/app/services/masking.service';
import { RestService } from 'src/app/services/rest.service';
import { SearchService } from 'src/app/services/search.service';

@Component({
  selector: 'app-form-container',
  templateUrl: './form-container.component.html',
  styleUrls: ['./form-container.component.css']
})
export class FormContainerComponent implements OnInit, OnChanges, OnDestroy {
  @Input() options: any;
  @Input() activeSection = '';
  @Input() buttonOptions:any;
  @Output() response: EventEmitter<any> = new EventEmitter<any>();
  form: UntypedFormGroup;
  fields = [];
  keyFields = [];
  errorFields = [];
  fieldGroup = {};
  formData = {};
  showPopup = false;
  key = {};
  allFields = [];
  showbutton = true;
  config: Config;
  constructor(private configService: ConfigService,
              private conversionService: ConversionService,
              private formValidatorService: FormvalidatorService,
              private maskingService: MaskingService,
              private restService: RestService,
              private searchService: SearchService,
              private router: Router,
              private errorHandlingService: ErrorHandlingService) {
    this.config = this.configService.config;
  }

  ngOnInit() {
    // this.formValidatorService.setOptions(this.options);
    this.allFields = Object.keys(this.options.fields).map(e => {
      const f = this.options.fields[e];
      if (this.searchService.fieldName) {
        f.highlight = f?.label?.trim() === this.searchService.fieldName;
      }
      return f;
    });
    this.errorFields = this.allFields.filter(x => x.name.startsWith('ERR') || x.name.startsWith('H_statusMessage'));
    this.keyFields.sort((a, b) => a.order - b.order);
    this.fields.sort((a, b) => a.order - b.order);

    this.form = this.formValidatorService.buildFormGroup(this.options.pageId,this.allFields);
    this.formRender();

    const changedProperties = [];
    this.form.valueChanges.subscribe(data => {
      Object.keys(this.form.controls).forEach((name) => {
        const currentControl = this.form.controls[name];
        if (currentControl.dirty) {
          if (changedProperties.indexOf(name) >= 0) {
            return;
          } else {
            changedProperties.push(name);
          }
        }
        if (changedProperties.length >= this.configService.config.formChangesLimit) {
          this.showPopup = true;
        }
      });
    });


  }
  closePopup() {
    this.showPopup = false;
  }

  ngOnChanges(changes: SimpleChanges) {

    if (changes.options && changes.options.currentValue !== changes.options.previousValue) {
      this.options = changes.options.currentValue;
      if(!this.options.pageId){
        return;
      }
      this.ngOnInit();
    } else {
      this.formRender();

    }
    //  this.form.updateValueAndValidity();
  }
  masking(context: any, value: string): string {
    if (context.mask === undefined || context.mask === '') {
      return value;
    }
    const newValue = this.maskingService.applyMask(value, context.mask);
    if (newValue.trim().length > 0) {
      this.maskingService.unMaskedRepo[context.name] = { maskedData: value, data: newValue };
    }
    return newValue;
  }
  formRender() {
    this.fields = this.allFields.filter(x => {
      try {
        x.data = this.form.get(x.name)?.value;
      } catch (e) {
        // Not a form field like object, etc. ignore.
        
      }
      
      const result = !x.isKeyField && !x.name.startsWith('ERR') && x.name != 'H_statusMessage';
      if (this.options.splitToSections) {

        return result && x.sectionId === this.activeSection;
      }
      return result;
    });

    this.keyFields = this.allFields.filter(x => {

      /**
       * The crossReference rules:
       * 1. Fields that have crossReference labels will need to be stored.
       * 2. Key fields that are editable and have initial values can only get values FROM xref
       * 3. Key fields that are not editable cannot have xref values, but can only update xref values
       */

      if (x.crossReference === undefined) { return x.isKeyField; }

      // here we only have key fields that have xref

      if (x.readonly) {

        // this is readonly - no update to key data, update crossReference only if has non-init data;
        if (x.data !== undefined && x.data !== 0 && x.data.trim() !== '' && x.data !== '0') {

          if (x.mask !== undefined && x.mask !== '') {
            // this was supposed to be in the masked repository . if its not there, dont update it.
            if (this.maskingService.getUnmaskedValue(x.name, x.data) !== x.data) {
              this.configService.crossReferenceRepo[x.crossReference] = {};
              this.configService.crossReferenceRepo[x.crossReference].data = this.maskingService.getUnmaskedValue(x.name, x.data);
              this.configService.crossReferenceRepo[x.crossReference].maskedData = x.data;
            }
          } else {
            this.configService.crossReferenceRepo[x.crossReference] = {};
            this.configService.crossReferenceRepo[x.crossReference].data = x.data;
          }
        }
        // if not ignore; and return

        return x.isKeyField;

      }
      if (!x.isKeyField) {
        return false;
      }

      // here we have only editable key fields - update FROM crossReference only if it IS init data;
      if (x.data !== undefined && x.data !== 0 && x.data.trim() !== '' && x.data !== '0') {
        return x.isKeyField;
      }
      const xrefValue = this.configService.crossReferenceRepo[x.crossReference]?.data;
      
      // xrefValue MUST always be valid non-init value; it shouldn't have anyhting else;
      if (xrefValue !== undefined) {

        x.data = this.masking(x, this.configService.crossReferenceRepo[x.crossReference]?.data);
        if (x.mask !== undefined && x.mask !== '') {
          x.data = this.configService.crossReferenceRepo[x.crossReference].maskedData;
          if (x.data === undefined) { // this was supposed be masked, but no maskedData, no worries, mask it now.
            x.data = this.masking(x, this.configService.crossReferenceRepo[x.crossReference]?.data);
          }
        }

        x.controlClass = 'form-control text-info';
      }

      return x.isKeyField;
    });

    this.keyFields.sort((a, b) => a.order - b.order);
    this.fields.sort((a, b) => a.order - b.order);
  }


  setData(data: any) {
    this.options = data;
  }

  onSubmit(event) {
    const button = event.submitter.name;
    this.formData = this.formValidatorService.getFormRawValues(this.options);
    const clickedButtonConfig = this.options.adhocButtonLayer?.filter(x => x.buttonName === button);
    if (clickedButtonConfig === undefined || clickedButtonConfig.length === 0) {
      
      if (button !== "Submit") {
        Object.keys(this.options.form.buttons).forEach(key => {
          if (this.options.form.buttons[key].value === button) {
            const buttonid = key;
            Object.keys(this.restService.postRenderBtn).forEach(element => {
              if (element === buttonid) {
                this.restService.postRenderBtn[element] = Object.fromEntries(Object.entries(this.restService.postRenderBtn[element]).filter(([_, v]) => v != null));
                delete this.restService.postRenderBtn[element].buttonid;
                this.formData = this.restService.postRenderBtn[element];
                return;
              }
            });
          }
        });
      }
      this.formValidatorService.formSubmit(this.formData,this.restService);
    } else {
      this.buildRequestAndSubmit(clickedButtonConfig[0]);
    }

  }
  buildRequestAndSubmit(buttonConfig: any) {
    this.formData = this.formValidatorService.getAllFormRawValues(this.options);
    const formData = { ...buttonConfig.constants };
    formData.H_messageName = buttonConfig.targetMessage.messageName;
    formData.H_messageVersion = buttonConfig.targetMessage.messageVersion;
    if (buttonConfig.targetMessage.messageMode !== null && buttonConfig.targetMessage.messageMode !== undefined) {
      formData.H_messageMode = buttonConfig.targetMessage.messageMode;
    }
    let messageName = formData.H_messageName;
    if (messageName.indexOf('$$') >= 0) {
      const field = messageName.substring(messageName.indexOf('$$') + 2, messageName.lastIndexOf('$$'));
      messageName = messageName.replace('$$' + field + '$$', this.formData[field]);
    }
    formData.H_messageName = messageName;
    Object.keys(this.formData).forEach((item) => {
      for (const mapping of buttonConfig.keyFieldCodeMapping) {
        formData[mapping.targetMessageFieldCode] = this.formData[mapping.parentMessageFieldCode] !== undefined
          ? this.formData[mapping.parentMessageFieldCode] : '';

        if (item.startsWith('H')) { return; }
        const idx = item.indexOf('_');
        if (idx >= 0) {
          const sub = item.substring(idx);
          const prefix = item.substring(0, idx);
          if (prefix === mapping.parentMessageFieldCode) {
            if (this.formData[item] !== undefined) {
              formData[mapping.targetMessageFieldCode + sub] = this.formData[item];
            }
            break;
          }
        }
      }
      for (const mapping of buttonConfig.fieldCodeMapping) {
        formData[mapping.targetMessageFieldCode] = this.formData[mapping.parentMessageFieldCode];
      }

    });
    this.maskingService.unMaskedRepo = {};
    this.restService.post(formData).subscribe(
      response => {
        let resp: any;
        try {
          resp = this.conversionService.convert(this.restService.parse(response));
          const responseMessageName = resp.inputMessageName || resp.pageName;
          const formSuccess = resp.fields?.H_status?.data && resp.fields?.H_status?.data === 'P';
          if (formSuccess) { // reset previous form data if form was successful.
            this.formValidatorService.setPreviousFormData({});
          }
          if (responseMessageName === undefined) {
            const newContent = this.options;
            newContent.fields = { ...this.options.fields, ...resp.fields };
            this.options = newContent;
            // console.log(this.options);
          }
        } catch (error) {
          this.options.fields.ERR1.data = error;
          console.log(error);
          this.errorHandlingService.errorHandler(error.stack,'UIERR0003');
        } finally {
          this.ngOnInit();
        }


        this.router.navigate(['/home/page', formData.H_messageName]);
      }
    );

  }
  ngOnDestroy() {
    this.options = null;
  }



}
