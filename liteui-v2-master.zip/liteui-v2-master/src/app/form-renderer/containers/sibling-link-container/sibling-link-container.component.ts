import { FormlinkService } from './../../../services/formlink.service';
import { Component, Input, OnChanges, SimpleChanges, SimpleChange } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-sibling-link-container',
  templateUrl: './sibling-link-container.component.html',
  styleUrls: ['./sibling-link-container.component.css']
})
export class SiblingLinkContainerComponent implements OnChanges {
  @Input() content: any;
  constructor( private route: ActivatedRoute, private formlinkService: FormlinkService ) { }

  ngOnChanges(changes: SimpleChanges): void {
    const contentChange: SimpleChange = changes.content;
    contentChange && contentChange.currentValue && this.content.links.forEach(link => {link.active = link.content.messageName === this.route.snapshot.params.name })
  }
  gotoPage(item, dataType){
    this.formlinkService.gotoPageNext(item, dataType);
  }
}