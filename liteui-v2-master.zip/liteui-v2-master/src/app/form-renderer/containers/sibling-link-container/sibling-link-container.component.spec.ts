import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TranslatePipe } from 'src/app/translate.pipe';
import { By } from '@angular/platform-browser';
import { element } from 'protractor';
import { RestService } from 'src/app/services/rest.service';
import { ConfigService } from 'src/app/services/config.service';
import { SiblingLinkContainerComponent } from './sibling-link-container.component';

describe('SiblingLinkContainerComponent', () => {
  let component: SiblingLinkContainerComponent;
  let fixture: ComponentFixture<SiblingLinkContainerComponent>;
  let restService:RestService;
  let configService:ConfigService

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ SiblingLinkContainerComponent,TranslatePipe],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[RestService,ConfigService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiblingLinkContainerComponent);
    component = fixture.componentInstance;
    component.content ={}
    component.content.links=[
      {
        'linkId': 'button1000',
        'linkName': '01-Account Base Segment',
        'content': {
            '4003': '1',
            '4601': '30',
            '4602': '0001010100000000230',
            '9904': '0',
            'messageName': 'M.CMS.AMBSAS.AS.QU.QUERY1',
            'messageVersion': 'R00000'
        }
    },
    
    
    {
      'linkId': 'button1004',
      'linkName': '05-IRT Account Override Data',
      'content': {
          '4003': '1',
          '4601': '30',
          '4602': '0001010100000000230',
          '9904': '0',
          'messageName': 'M.CMS.AMBSAS.AS.QU.QUERY5',
          'messageVersion': 'R00000'
      }
  },
    
    {
        'linkId': 'button1002',
        'linkName': '03-PCT Defaults',
        'content': {
            '4003': '1',
            '4601': '30',
            '4602': '0001010100000000230',
            '9904': '0',
            'messageName': 'M.CMS.AMBSAS.AS.QU.QUERY3',
            'messageVersion': 'R00000'
        }
    }
    
    
    ]
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have correct heading',()=>{
    // creating reference for html element
    const ref: DebugElement = fixture.debugElement;
    const heading = ref.query(By.css('#heading'));
    const displayEle: HTMLElement = heading.nativeElement
    fixture.detectChanges();
    expect(displayEle.textContent).toBe('Pages');
  })

  it('should have correct linkname name',()=>{
    const links1=fixture.debugElement.queryAll(By.css('#sibling'))
    expect(links1.length).toEqual(component.content.links.length);
    expect(links1).toBeTruthy();
    component.content.links.forEach((links,index)=>{
    expect(links1[index].properties.innerHTML).toEqual(component.content.links[index].linkName);
     })
  })

  it('linkname should call goToPage on click',()=>{
    const links1=fixture.debugElement.query(By.css('#sibling'))
    const checkCall=spyOn(component,'gotoPage');
    links1.triggerEventHandler(null,'click');
    expect(checkCall).toHaveBeenCalled();

  })

  
  it('linkname name should call gotopage method on click',()=>{
    let link=fixture.debugElement.query(By.css('#sibling'))
    const checkCall=spyOn(component,'gotoPage');
    link.triggerEventHandler('click',null);
    expect(checkCall).toHaveBeenCalled();
  })






});
