import {
  ChangeDetectorRef, Component, ComponentFactoryResolver, Compiler, ComponentRef, Input, OnChanges, OnDestroy,
  OnInit, SimpleChanges, ViewChild, ViewContainerRef, HostBinding
} from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AnyControlComponent } from '../../controls/any-control/any-control.component';
import { CurrencyControlComponent } from '../../controls/currency-control/currency-control.component';
import { DateControlComponent } from '../../controls/date-control/date-control.component';
import { DropdownControlComponent } from '../../controls/dropdown-control/dropdown-control.component';
import { HiddenControlComponent } from '../../controls/hidden-control/hidden-control.component';
import { LabelControlComponent } from '../../controls/label-control/label-control.component';
import { NumberControlComponent } from '../../controls/number-control/number-control.component';
import { ObjectControlComponent } from '../../controls/object-control/object-control.component';
import { TableControlComponent } from '../../controls/table-control/table-control.component';
import { TableControlMakerComponent } from '../../controls/table-control-maker/table-control-maker.component';
import { TableMakerCheckerComponent } from '../../controls/table-maker-checker/table-maker-checker.component';
import { TextControlComponent } from '../../controls/text-control/text-control.component';
import { PasswordControlComponent } from '../../controls/password-control/password-control.component';
import { UrlControlComponent } from '../../controls/url-control/url-control.component';
import { ChartControlComponent } from '../../controls/chart-control/chart-control.component';

@Component({
  selector: 'app-generic-container',
  templateUrl: './generic-container.component.html',
  styleUrls: ['./generic-container.component.css']
})
export class GenericContainerComponent implements OnInit, OnDestroy, OnChanges {

  @ViewChild('container', { read: ViewContainerRef, static: true }) container: ViewContainerRef;
  @Input() context: any;
  @Input() pageId: any;
  private componentRef: ComponentRef<any>;
  private isViewInitialized = false;
  fieldClass: any;

  constructor(private readonly componentFactoryResolver: ComponentFactoryResolver,
              private compiler: Compiler,
              private cdRef: ChangeDetectorRef) { }
  private readonly mappings = {
    any: AnyControlComponent,
    label: LabelControlComponent,
    text: TextControlComponent,
    number: NumberControlComponent,
    date: DateControlComponent,
    hidden: HiddenControlComponent,
    select: DropdownControlComponent,
    object: ObjectControlComponent,
    table: TableControlComponent,
    tableMaker: TableControlMakerComponent,
    tableChecker: TableMakerCheckerComponent,
    currency: CurrencyControlComponent,
    password: PasswordControlComponent,
    url: UrlControlComponent,
    grid: ChartControlComponent
  };

  getComponentType(typeName: string): any {
    const comp = (this.mappings[typeName]);
    if (comp === undefined) { return AnyControlComponent; }
    return comp;
  }
  // @HostBinding('class') get HeadingClass() {
  //   return this.fieldClass;
  // }
  updateComponent() {
    if (!this.isViewInitialized) {
      return;
    }
    if (this.componentRef) {
      this.componentRef.destroy();
    }

    const factory = this.componentFactoryResolver.resolveComponentFactory(this.getComponentType(this.context.type));
    this.componentRef = this.container.createComponent(factory);
    // to access the created instance use
    this.componentRef.instance.updateProperties(this.context, this.pageId);
    // this.compRef.instance.someOutput.subscribe(val => doSomething());
    this.cdRef.detectChanges();
  }


  ngOnDestroy(): void {
    if (this.componentRef) {
      this.componentRef.destroy();
      this.componentRef = null;
    }
  }

  ngOnChanges() {
    this.updateComponent();
  }

  ngAfterViewInit() {
    this.isViewInitialized = true;
    this.updateComponent();
  }

  ngOnInit(): void {
    if (this.context.schema.format === 'password') {
      this.context.type = 'password';
    }
    const componentType = this.getComponentType(this.context.type);
    const factory = this.componentFactoryResolver.resolveComponentFactory(componentType);
    this.componentRef = this.container.createComponent(factory);
  }

}
