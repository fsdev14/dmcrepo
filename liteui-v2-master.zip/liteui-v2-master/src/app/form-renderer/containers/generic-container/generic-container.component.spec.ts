import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import {
  ChangeDetectorRef, Component, ComponentFactoryResolver, Compiler, ComponentRef, Input, OnChanges, OnDestroy,
  OnInit, SimpleChanges, ViewChild, ViewContainerRef, HostBinding
} from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AnyControlComponent } from '../../controls/any-control/any-control.component';
import { CurrencyControlComponent } from '../../controls/currency-control/currency-control.component';
import { DateControlComponent } from '../../controls/date-control/date-control.component';
import { DropdownControlComponent } from '../../controls/dropdown-control/dropdown-control.component';
import { HiddenControlComponent } from '../../controls/hidden-control/hidden-control.component';
import { LabelControlComponent } from '../../controls/label-control/label-control.component';
import { NumberControlComponent } from '../../controls/number-control/number-control.component';
import { ObjectControlComponent } from '../../controls/object-control/object-control.component';
import { TableControlComponent } from '../../controls/table-control/table-control.component';
import { TableControlMakerComponent } from '../../controls/table-control-maker/table-control-maker.component';
import { TableMakerCheckerComponent } from '../../controls/table-maker-checker/table-maker-checker.component';
import { TextControlComponent } from '../../controls/text-control/text-control.component';
import { PasswordControlComponent } from '../../controls/password-control/password-control.component';
import { UrlControlComponent } from '../../controls/url-control/url-control.component';
import { ChartControlComponent } from '../../controls/chart-control/chart-control.component';
import { FormControl, FormsModule } from '@angular/forms';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { By } from '@angular/platform-browser';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { ConfigService } from 'src/app/services/config.service';
import { RestService } from 'src/app/services/rest.service';

import { GenericContainerComponent } from './generic-container.component';

class MockRestService extends RestService {

  data={
     'schema':{
       'type': 'object',
       'linkName': 'Amortization Details - ARMA09/10/16/ARQA - 02-Loan Earned / Unearned Amounts',
       'properties': {
           '4728': {
               'type': 'number',
               'required': true,
               'default': 1,
               'minimum': 1,
               'maximum': 999,
               'title': 'Record Number'
           },
           '4729': {
               'type': 'number',
               'required': true,
               'default': 0,
               'minimum': 0,
               'maximum': 99,
               'title': 'Record Type'
           },
           '4735': {
               'type': 'string',
               'default': 0,
               'title': 'Unearned Principal'
           },
           '4736': {
               'type': 'string',
               'default': 0,
               'title': 'Unearned Principal Reversal'
           },
           '4737': {
               'type': 'string',
               'default': 0,
               'title': 'Earned Principal'
           },
           'ERR1':{
             
               'type': 'string',
               'title': ''
           
           }
         }
       }
   }
 
   getLastResponse() {
       return this.data;
   }
 }
describe('GenericContainerComponent', () => {
  let component: GenericContainerComponent;
  let fixture: ComponentFixture<GenericContainerComponent>;
  let componentFactoryResolver:ComponentFactoryResolver;
  let service:MockRestService;
  let formvalidator:FormvalidatorService;
  let configService:ConfigService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ GenericContainerComponent ],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([]),FormsModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA,ComponentFactoryResolver], 
      providers: [FormvalidatorService,ConfigService,
        {
            provide: RestService,
            useClass:MockRestService
        },
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenericContainerComponent);
    component = fixture.componentInstance;
    component.context={
      'type': 'label',
      'hidden': true,
      'name': 'ERR1',
      'fieldClass': '',
      'label': '',
      'schema': {
          'type': 'string',
          'title': '',
          'format':''
      }
  }
  //component['isViewInitialized']=false;
  
  
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have correct component type after execution of getComponentType with label arfument',()=>{
    expect(component.getComponentType('label')).toBe(LabelControlComponent);
  })

  it('should have AnyControl component component type after execution of getcomponent type with epty string',()=>{
    expect(component.getComponentType('')).toBe(AnyControlComponent);
  })

  it('should have update component correctly',()=>{
    component.updateComponent();
    expect(component['componentRef'].componentType).toBe(LabelControlComponent);
  })


  it('should have correct context type after execution of ngOninit',()=>{
    component.context = { ...component.context, ...{'schema':{'format':'password'}} };
    component.ngOnInit();
    expect(component.context.type).toEqual('password')
  })
});
