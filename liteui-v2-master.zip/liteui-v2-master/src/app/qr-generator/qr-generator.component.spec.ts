import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { qrGeneratorComponent } from './qr-generator.component';
import { TranslatePipe } from 'src/app/translate.pipe';

describe('qrGeneratorComponent', () => {
  let component: qrGeneratorComponent;
  let fixture: ComponentFixture<qrGeneratorComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ qrGeneratorComponent, TranslatePipe ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(qrGeneratorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
