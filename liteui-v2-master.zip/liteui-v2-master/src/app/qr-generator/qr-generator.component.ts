import { Component, OnInit } from '@angular/core';
import { NgxQrcodeElementTypes, NgxQrcodeErrorCorrectionLevels } from '@techiediaries/ngx-qrcode';
import { RestService } from '../services/rest.service';
import { ConfigService } from '../services/config.service';
import { mfaService } from '../services/mfa.service';


@Component({
  selector: 'app-qr-generator',
  templateUrl: './qr-generator.component.html',
  styleUrls: ['./qr-generator.component.css']
})
export class qrGeneratorComponent {

  
  constructor(private mfaService: mfaService, private configService: ConfigService, private restService: RestService) { }

  elementType = NgxQrcodeElementTypes.URL;
  correctionLevel = NgxQrcodeErrorCorrectionLevels.HIGH;
  value = this.restService.registrationUri;
  deviceStatus: string;
  errorLabel = false;
  errMessage = "Incorrect OTP, Please enter the OTP again!";
  displayOTPSection = this.restService.displayOTPSection;

  async activateDeviceOTP(otp: number) {
     let res = await this.mfaService.activateMFADevice(otp);
     if (res.status) {
      this.errorLabel = false;
      this.displayOTPSection = true;
      await this.mfaService.requestOTP();
     } else {
      this.errorLabel = true;
     }
  }

  async verifyUser(otp: number) {
    let res = await this.mfaService.verifyUser(otp);
    if (res.status) {
      this.errorLabel = false;
      this.restService.externalUserVerified.next(true);
      this.restService.authenticationModal.next(false);
    } else {
      this.errorLabel = true;
    }
  }

}
