import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AuthGuard } from './auth/auth.guard';
import { SelectivePreloadingStrategyService } from './services/selective-preloading-strategy.service';
import { HomeComponent } from './home/home.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { SecretResetComponent } from './auth/secret-reset/secret-reset.component';
import { LoginComponent } from './auth/login/login.component';
import { ErrorComponent } from './error/error.component';
import { HelpComponent } from './help/help.component';
import { SsoComponent } from './auth/sso/sso.component';

const appRoutes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then(m => m.HomeModule),
    canLoad: [AuthGuard]
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'error',
    component: ErrorComponent
  },
  {
    path: 'help',
    component: HelpComponent
  },
  {
    path: 'secret',
    component: SecretResetComponent,
    canActivate: [AuthGuard]
  },
  { path: 'user/:username', component: SsoComponent },
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes,
      {
        onSameUrlNavigation: 'reload',
        enableTracing: false,
        preloadingStrategy: SelectivePreloadingStrategyService,
        useHash: true,
        relativeLinkResolution: 'legacy'
      }
    )
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
