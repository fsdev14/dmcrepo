import { TestBed } from '@angular/core/testing';
import { ConfigService } from './services/config.service';
import { TranslationService } from './services/translation.service';
import { TranslatePipe } from './translate.pipe';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';

describe('TranslatePipe', () => {

  let translationSerivce: TranslationService;
  let configService: ConfigService;
  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [TranslationService, ConfigService], imports: [HttpClientTestingModule, RouterTestingModule] });
    configService = TestBed.inject(ConfigService);
    translationSerivce = TestBed.inject(TranslationService);
  })

  it('create an instance', () => {
    const pipe = new TranslatePipe(translationSerivce);
    expect(pipe).toBeTruthy();
  });

  it('should translate text', () => {});
});