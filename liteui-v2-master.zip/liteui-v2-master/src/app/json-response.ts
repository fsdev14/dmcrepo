export class JsonResponse{
    schema: any;
    object: any;
    data: any;
    view: any;
    dmcparam: any;
    tableGridJsonPaths: any;
}
