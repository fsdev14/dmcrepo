import { TablePagePipe } from './table-page.pipe';

describe('TablePagePipe', () => {
  it('create an instance', () => {
    const pipe = new TablePagePipe();
    expect(pipe).toBeTruthy();
  });
});
