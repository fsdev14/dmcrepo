/// <reference lib="webworker" />

let intervals:any;
let timerStart:boolean;
let count:number;
let timeOutDuration;

addEventListener('message', ({ data }) => {   
      if(data.includes('resetTimer:')) {
        timeOutDuration = Number(data.split(':')[1]);
        timerStart = true;
        clearInterval(intervals);
        count = 0;
      }
      if (timerStart) {
         intervals = setInterval(()=>{
          count++;
          updateCount(count)
        },1000);        
        timerStart = false;
      }    
                    
 
});

function updateCount(count){  
  if(count >= timeOutDuration) {
    postMessage(count);
    clearInterval(intervals);    
    }
  else{    
  }
}
