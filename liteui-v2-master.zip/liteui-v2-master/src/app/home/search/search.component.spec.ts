import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, ElementRef, SimpleChange, SimpleChanges } from '@angular/core';
import { TranslatePipe } from 'src/app/translate.pipe';
import { Node } from 'src/app/services/node';
import { BrowserModule, By } from '@angular/platform-browser';

import { NodemapService } from 'src/app/services/nodemap.service';
import { ConfigService } from 'src/app/services/config.service';
import { SearchComponent } from './search.component';

describe('SearchComponent', () => {
  let component: SearchComponent;
  let fixture: ComponentFixture<SearchComponent>;
  let nodeMapService:NodemapService;
  let configService:ConfigService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchComponent,TranslatePipe],
      imports: [ HttpClientTestingModule,BrowserModule, RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[ConfigService,NodemapService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchComponent);
    component = fixture.componentInstance;
    component.searchTextBox='ARCL';
    component.contents=[{
     'name': 'Extended Name Lookup ARCL',
      'category1': 'Customer Management System',
      'category2': 'Business Function',
      'category3': '',
      'category4': '',
      'order': '',
      'displayAsMenu': true,
      'content': {
          'messageName': 'M.CMS.ARXXLFS.ATOM.I',
          'messageVersion': 'R00000',
          'serviceName': 'ARXXLFS',
          'language': 'EN'
      },
      'path': [
          {
              'category': 'Customer Management System',
              'link': 'Customer_Management_System'
          },
          {
              'category': 'Business Function',
              'link': 'Customer_Management_System_Business_Function'
          }
      ]
    
  },{
    'name': 'XYZ',
      'category1': 'Customer Management System',
      'category2': 'Business Function',
      'category3': '',
      'category4': '',
      'order': '',
      'displayAsMenu': true,
      'content': {
          'messageName': 'M.CMS.ARXXLFS.ATOM.I',
          'messageVersion': 'R00000',
          'serviceName': 'ARXXLFS',
          'language': 'EN'
      },
      'path': [
          {
              'category': 'Customer Management System',
              'link': 'Customer_Management_System'
          },
          {
              'category': 'Business Function',
              'link': 'Customer_Management_System_Business_Function'
          }
      ]
    
  }
  
]
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have focus on searFocus after execution of handleKeyboardEvent with desired argument for focus',()=>{
    const keyEvent = new KeyboardEvent('keydown', { key: 'S',ctrlKey:true,shiftKey:true}); 
    const search=fixture.nativeElement;
    const  searchBox:HTMLInputElement=search.querySelector('#search-box')
    const checkCall=spyOn(searchBox,'focus')
    component.handleKeyboardEvent(keyEvent);
    expect(searchBox.focus).toHaveBeenCalled();
  })

  it('should not have focus on searFocus after execution of handleKeyboardEvent with argument not desired for focus',()=>{
    const keyEvent = new KeyboardEvent('keydown', { key: 'P',ctrlKey:true,shiftKey:true}); 
    const search=fixture.nativeElement;
    const  searchBox:HTMLInputElement=search.querySelector('#search-box')
    const checkCall=spyOn(searchBox,'focus')
    component.handleKeyboardEvent(keyEvent);
    expect(searchBox.focus).not.toHaveBeenCalled();
  })

  it('should reverse the value of showSearch in case of 0 argument given to hideSearchbox',()=>{
    let testShowSearch=!component.showSearch;
    component.hideSearchBox(0);
    expect(component.showSearch).toBe(testShowSearch);
  })

  
  it('should not reverse the value of showSearch in case of argument given other than 0 to hideSearchbox',()=>{
    let testShowSearch=component.showSearch;
    component.hideSearchBox(9);
    expect(component.showSearch).toBe(testShowSearch);
  })

  it('showSearch should have correct value after execution of focus method in case of searchtextbox length>3',()=>{
    component.Onfocus();
    expect(component.showSearch).toBe(true);
  })

  it('showSearch should have correct value after execution of focus method in case of searchtextbox length<3',()=>{
    component.searchTextBox='';
    fixture.detectChanges();
    component.Onfocus();
    expect(component.showSearch).toBe(false);
  })

  it('prevtext should have correct value after execution of triggerSearch in case of uppercase of argument equals to prevtext',()=>{
    component.prevtext='ACL';
    component.triggerSearch('arcl')
    expect(component.prevtext).toEqual('ARCL')
  })

  it('showSearch,searchText,contents should have correct value in case of length of argument >3 of triggerSearch method',()=>{
    component.triggerSearch('arcl');
    expect(component.showSearch).toBe(true);
    expect(component.searchText).toBe(true)
    expect(component.contents).toEqual([])
  })

  it('showSearch,searchText,contents should have correct value in case of length of argument <3 of triggerSearch method',()=>{
    component.triggerSearch('arl');
    expect(component.showSearch).toBe(false);
    expect(component.searchText).toBe(false)
    expect(component.contents).toEqual([])
  })

  it('should have searchBox',()=>{
    let searchBox=fixture.debugElement.query(By.css('#searchBox'));
    expect(searchBox).toBeTruthy();
  })

  it('should have searchTextBox',()=>{
    let searchTextBox=fixture.debugElement.query(By.css('#search-box'))
    expect(searchTextBox).toBeTruthy();
  })

  it('searchtext box should call onfocus on focus',()=>{
    let searchTextBox=fixture.debugElement.query(By.css('#search-box'));
    const checkCall=spyOn(component,'Onfocus');
    searchTextBox.triggerEventHandler(null,'focus');
    expect(checkCall).toHaveBeenCalled();
  })

  it('searchtext box should call hideSearchBox on blur',()=>{
    let searchTextBox=fixture.debugElement.query(By.css('#search-box'));
    const checkCall=spyOn(component,'hideSearchBox');
    searchTextBox.triggerEventHandler(null,'blur');
    expect(checkCall).toHaveBeenCalled();
  })

  it('should have searchresult div in case of showSearch has true value',()=>{
    component.showSearch=true;
    fixture.detectChanges();
    let searchresults=fixture.debugElement.query(By.css('#searchresults'))
    expect(searchresults).toBeTruthy();

  })

  it('should have searchresult div in case of showSearch has false value',()=>{
    component.showSearch=false;
    fixture.detectChanges();
    let searchresults=fixture.debugElement.query(By.css('#searchresults'))
    expect(searchresults).not.toBeTruthy();
  })

  it('should have hideSearch div',()=>{
    component.showSearch=true;
    component.searchText=true;
    fixture.detectChanges();
    let hideSearch=fixture.debugElement.query(By.css('#hideSearch'));
    expect(hideSearch).toBeTruthy();
  })

  it('should call hideSearchBox on click of hideSearch',()=>{
    component.showSearch=true;
    component.searchText=true;
    fixture.detectChanges();
    let hideSearch=fixture.debugElement.query(By.css('#hideSearch'));
    const checkCall=spyOn(component,'hideSearchBox');
    hideSearch.triggerEventHandler(null,'click');
    expect(checkCall).toHaveBeenCalled();
  })

  it('should have close button',()=>{
    component.showSearch=true;
    component.searchText=true;
    fixture.detectChanges();
    let close=fixture.debugElement.query(By.css('#close'));
    expect(close).toBeTruthy();
  })

  it('should have search result correctly in case of data in contents',()=>{
     component.showSearch=true;
     fixture.detectChanges();
     let searchResults=fixture.debugElement.query(By.css('#totalResult'))
     expect(searchResults).toBeTruthy();
     expect(searchResults.nativeElement.innerHTML).toEqual(' '+component.contents.length+' '+'results found. ')
  })

  it('should have no result message  correctly in case of no data in contents',()=>{
    component.contents=[]
    component.showSearch=true;
    fixture.detectChanges();
    let searchResults=fixture.debugElement.query(By.css('#noResults'))
    expect(searchResults).toBeTruthy();
    expect(searchResults.nativeElement.innerHTML).toEqual('No results.')
 })
 it('search result name should be correct',()=>{
    component.showSearch=true;
    fixture.detectChanges();
    let name=fixture.debugElement.queryAll(By.css('#name'));
    expect(name.length).toBe(component.contents.length);
    component.contents.forEach((item,index)=>{
      expect(name[index].nativeElement.innerText).toBe(component.contents[index].name)
    })
    
 })

 it('search result category1 should be correct',()=>{
  component.showSearch=true;
  fixture.detectChanges();
  let category1=fixture.debugElement.queryAll(By.css('#category1'));
  expect(category1.length).toBe(component.contents.length);
  component.contents.forEach((item,index)=>{
    expect(category1[index].nativeElement.innerText).toBe(component.contents[index].category1)
  })
})
  
 it('search result category1 should be correct',()=>{
  component.showSearch=true;
  fixture.detectChanges();
  let category2=fixture.debugElement.queryAll(By.css('#category2'));
  expect(category2.length).toBe(component.contents.length);
  component.contents.forEach((item,index)=>{
    expect(category2[index].nativeElement.innerText).toBe(component.contents[index].category2)
  })
  
})

it('should have searching div in case of searching have true value',()=>{
  component.searching=true;
  component.showSearch=true;
  fixture.detectChanges();
  let searching=fixture.debugElement.query(By.css('#searching'));
  expect(searching).toBeTruthy();
})

it('should not have searching div in case of searching have false value',()=>{
  component.showSearch=true;
  fixture.detectChanges();
  let searching=fixture.debugElement.query(By.css('#searching'));
  expect(searching).not.toBeTruthy();
})

it('should not have no result div in case of searching have false value and no data in fieldContents',()=>{
  component.showSearch=true;
  fixture.detectChanges();
  //console.log('contents',component.fieldContents)
  let noResult=fixture.debugElement.query(By.css('#noResult'));
  expect(noResult).toBeTruthy();
})

it('should not have error message in case of false value to error message',()=>{
  component.showSearch=true;
  fixture.detectChanges();
  let errorMessage=fixture.debugElement.query(By.css('#errorMessage'));
  expect(errorMessage).not.toBeTruthy();
})

it('should  have error message in case of true value to error message',()=>{
  component.errorMessage=true;
  component.showSearch=true;
  fixture.detectChanges();
  let errorMessage=fixture.debugElement.query(By.css('#errorMessage'));
  expect(errorMessage).toBeTruthy();
})

});
