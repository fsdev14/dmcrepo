import { Component, OnInit, Output, Input, Renderer2, ViewChild, ElementRef, AfterViewInit, HostListener } from '@angular/core';
import { NodemapService } from 'src/app/services/nodemap.service';
import { ActivatedRoute, Router } from '@angular/router';
import { RestService } from 'src/app/services/rest.service';
import { fromEvent, map, filter, debounceTime, distinctUntilChanged, switchMap } from 'rxjs';
import { SearchService } from 'src/app/services/search.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit, AfterViewInit {
  @ViewChild('searchTextBox', { read: ElementRef }) searchButton: ElementRef;
  @ViewChild('searchFocus') searchFocus;
  constructor(private nodeMapService: NodemapService,
              private router: Router,
              private route: ActivatedRoute,
              private restService: RestService,
              private renderer: Renderer2,
              private searchService: SearchService) {
    this.renderer.listen('window', 'click', (e: any) => {
      if (e.target.type === 'search' || e.target.parentElement?.id === 'SearchResultBox') {
      }
      else {
        this.showSearch = false;
      }
    });


  }
  bannedList = 'account,number,date,card,table,data,field,code,transaction';
  showSearch = false;
  searchText = false;
  searchTextBox = '';
  searching = false;
  errorMessage = false;
  contents = [];
  fieldContents = [
  ];


  prevtext = '';
  ngOnInit() {

  }

  @HostListener('window:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
    if (event.key == 'S' && event.ctrlKey && event.shiftKey) {
      this.searchFocus.nativeElement.focus();
    }
  }
  ngAfterViewInit() {
    const searchBox = this.searchButton.nativeElement as HTMLInputElement;

    const typeahead = fromEvent(searchBox, 'input').pipe(
      map(e => (e.target as HTMLInputElement).value),
      filter(text => {
        this.fieldContents = [];
        return text.length > 3 && this.bannedList.indexOf(text.trim().toLowerCase()) === -1; 
      }),
      debounceTime(600),
      distinctUntilChanged(),
      switchMap(searchTerm => {
        this.searching = true;
        return this.searchService.search(searchTerm);  } )
    );

    typeahead.subscribe(data => {
      if(JSON.parse(String(data)).results !== undefined){
      JSON.parse(String(data)).results.forEach((metaObject) => {
        const html = this.getPath(metaObject);
        metaObject.path = html;
        this.fieldContents.push(metaObject);
      });
      this.searching = false;
    }
    else{
      this.searching = false;
      this.errorMessage = true;
    }
    });
  }

  hideSearchBox(timeout = 0) {
    if (timeout === 0) {
      this.showSearch = !this.showSearch;
    }
  }
  Onfocus() {
    if (this.searchTextBox.length > 3) {
      this.showSearch = true;
    }
  }

  triggerSearch(searchTextBox: string): any {
    searchTextBox = searchTextBox.toString().toUpperCase();
    if (this.prevtext === searchTextBox) {
      return true;
    } else {
      this.prevtext = searchTextBox;
    }
    
    if (searchTextBox.length > 3) {
      this.showSearch = true;
      this.searchText = true;
      let counter = 0;
      this.contents = [];

      this.nodeMapService.searchableNodes.forEach((metaObject) => {
        if (counter >= 20) { return; } // limit to 20 results
        const path = this.getPath(metaObject);
        if (metaObject.name.toUpperCase().indexOf(searchTextBox) >= 0) {
          metaObject.path = path;
          this.contents.push(metaObject);
          counter = counter + 1;
        }
      });

    } else {
      this.contents = [];
      this.showSearch = false;
      this.searchText = false;
    }
    this.searchTextBox = searchTextBox;

    return true;
  }

  getPath(metaObject: any ) {
    const html = [];
    let cat = '';
    if (metaObject.category1 && metaObject.category1.length > 0) {
      cat = metaObject.category1;
      html.push({ category: metaObject.category1, link: cat.replace(/ /g, '_') });
    }
    if (metaObject.category2 && metaObject.category2.length > 0) {
      cat = cat + '_' + metaObject.category2;
      html.push({ category: metaObject.category2, link: cat.replace(/ /g, '_') });
    }
    if (metaObject.category3 && metaObject.category3.length > 0) {
      cat = cat + '_' + metaObject.category3;
      html.push({ category: metaObject.category3, link: cat.replace(/ /g, '_') });
    }
    if (metaObject.category4 && metaObject.category4.length > 0) {
      cat = cat + '_' + metaObject.category4;
      html.push({ category: metaObject.category4, link: cat.replace(/ /g, '_') });
    }
    return html;
  }

  gotoPage(item: any) {
    this.showSearch = false;
    this.searchService.fieldName = item.fieldName;
    this.restService.post(item.content).subscribe(
      response => {
        this.restService.parse(response);
        this.router.navigate([`/home/page/${item.content.messageName}`]);
      }
    );
  }
  gotoAppMenu(item: any) {
    this.showSearch = false;
    this.restService.post(item.content).subscribe(
      response => {
        this.restService.parse(response);
        this.router.navigate([`home/menu/${item.path[0].link}`]);
      }
    );
  }
  
   gotoAppModule(item: any) {
    this.showSearch = false;
    this.restService.post(item.content).subscribe(
      response => {
        this.restService.parse(response);
        this.router.navigate([`home/menu/${item.path[1].link}`]);
      }
    );
  }

  highlight(haystack: string, needle: string): any {
    const reText = new RegExp(needle, 'gi');
    return haystack.replace(reText, '<mark>$&</mark>', );
  }



}




