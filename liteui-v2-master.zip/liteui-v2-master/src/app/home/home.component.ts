import { Component, OnInit, SimpleChanges, OnChanges, AfterViewChecked } from '@angular/core';
import { Config, ConfigService } from '../services/config.service';
import { AuthService } from '../auth/auth.service';
import { NodemapService } from '../services/nodemap.service';
import { RestService } from '../../app/services/rest.service';
import { FilesetService } from './../services/fileset.service';
import { ProfileService } from 'src/app/services/profile.service';
import {
  trigger,
  state,
  style,
  animate,
  transition
  // ...
} from '@angular/animations';
import { lastValueFrom, Observable } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  animations: [
    trigger('openClose', [
      state('open', style({
        opacity: 1, height: '*'
      })),
      state('closed', style({
        opacity: 0, height: 0
      })),
      transition('open => closed', [
        animate('0.1s')
      ]),
      transition('closed => open', [
        animate('0.1s')
      ]),
    ])
  ]
})
export class HomeComponent implements OnInit, OnChanges, AfterViewChecked {
  title: string;
  user: string;
  config: Config;
  appNavToggle = false;
  rightSidebarToggle = false;
  drawerToggle = false;
  name: any;
  route: any;
  regionname: any;
  regionurl: any;
  fileset = '';
  fileSetChange: any = {};
  fileSetFlag = false;
  logoSrc: any;
  logoStyle: any;
  externalUserflag = false;
  loadPage = this.restService.loadHomePage;

  constructor(
    private configService: ConfigService,
    private restService: RestService,
    private authService: AuthService,
    private nodeMapService: NodemapService,
    private filesetService: FilesetService,
    private profileService: ProfileService
  ) {
    this.showregion();
  }

  ngOnInit() {
    this.title = this.configService.config.dashboardTitle;
    this.user = this.authService.messageHeader.H_name;

    this.restService.externalUserVerify().subscribe(res => {
      if (res == true && this.externalUserflag == false) {
        this.loadPage = true;
        this.externalUserflag = true;
        this.fetchInitialData();
        this.setfileSetAndProfile();
        window.removeEventListener('resize', this.setWindowHeight);
        window.addEventListener('resize', this.setWindowHeight);
        this.setWindowHeight();
      }
    })

  }

  async fetchInitialData() {
    if (!this.nodeMapService.hasMenuLoaded()) {
      const nodeMapData = await lastValueFrom(this.nodeMapService.getMessageLinks());
      this.restService.parse(nodeMapData);
      this.nodeMapService.update(nodeMapData);

      const fileSetListData = await lastValueFrom(this.filesetService.fetchFileSetList());
      this.filesetService.update(fileSetListData);
      const profileData = await lastValueFrom(this.profileService.loadProfile());
      this.profileService.update(profileData);
    }
  }

  setfileSetAndProfile() {

    this.fileset = this.filesetService.getfileSetValue();
    this.getClientLogo();



  }
  getFileSetList() {
    return this.filesetService.getFileSetList();
  }

  getClientLogo() {
    this.logoStyle = this.profileService.logoStyle;
    this.logoSrc = this.profileService.logoSrc;
  }

  ngOnChanges(changes: SimpleChanges) {
    console.log(changes);
  }

  setWindowHeight() {
    const totalHeight = window.innerHeight - 4 * 16;
    // document.getElementById('formPage').style.height = totalHeight + 'px';
    
    var element = document.getElementById('formPage')?.style.height;
    element = totalHeight + 'px';
    if (document.getElementById('formPage')) {
      document.getElementById('formPage').style.height = element;
    }
  }

  ngAfterViewChecked() {
    if (this.loadPage) {
      this.setWindowHeight();
    }
  }
  toggleAppNav() {
    this.appNavToggle = !this.appNavToggle;
    this.toggleDrawer();
  }

  toggleRightSidebar() {
    this.rightSidebarToggle = !this.rightSidebarToggle;
  }

  toggleDrawer() {
    this.drawerToggle = !this.drawerToggle;
  }

  onActivate(componentReference) {
    componentReference.updateOnActive();
  }


  showregion() {
    this.regionurl = this.configService.config.remoteUrl;
    this.regionurl = this.regionurl.split('/');
    this.regionname = this.regionurl[this.regionurl.length - 1].replace('dmc', '').toUpperCase();
    document.title = `LiteUI - ${this.regionname}`;
  }

  changefileSet(fileset) {
    this.fileset = fileset;
    this.fileSetFlag = false;
    this.filesetService.changefileSet(fileset);
  }
  getFileSet() {
    this.fileset = this.filesetService.getfileSetValue();
    return this.fileset;
  }
  activeFile() {
    this.fileSetFlag = !this.fileSetFlag;
  }
  hideFile() {
    this.fileSetFlag = false;
  }
}


