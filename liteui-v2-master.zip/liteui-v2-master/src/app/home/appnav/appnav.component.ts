import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NodemapService } from 'src/app/services/nodemap.service';

@Component({
  selector: 'app-appnav',
  templateUrl: './appnav.component.html',
  styleUrls: ['./appnav.component.scss']
})
export class AppnavComponent implements OnInit {
  @Output() close = new EventEmitter();
  drawerToggle: boolean;
  
  constructor(private nodeMapService: NodemapService, private router: Router, private route: ActivatedRoute) { }
  appNavToggle: any;
  rootNodes: any;
  ddActiveFlag = false;
  dd2ActiveFlag = false;
  activeItem = '';
  
  ngOnInit() {
    this.rootNodes = this.nodeMapService.rootNodes;
  }
 toggleAppNav(node) {

    if (!node.expanded) {
         this.rootNodes.forEach(item => item.expanded = false);
    }
    node.expanded = !node.expanded;
  }
 
  gotoAppMenu(child) {
    this.router.navigate(['./menu', child], { relativeTo: this.route });
    this.close.emit();
    this.ddActiveFlag = false;
  }

  ddActive() {
    this.ddActiveFlag = true;
  }
  ddHide() {
    this.ddActiveFlag = false;
  }
  dd2Active(activeItem, show = true) {
    if (show) {
      this.activeItem = activeItem;
    } else {
      this.activeItem = '';
    }
    
  }
  dd2Toggle(activeItem) {
    this.dd2ActiveFlag = !this.dd2ActiveFlag;
  }
  isDD2Active(activeItem) {
    return this.activeItem === activeItem;
  }
}
