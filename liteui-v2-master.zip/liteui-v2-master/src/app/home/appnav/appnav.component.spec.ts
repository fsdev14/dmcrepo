import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, SimpleChange, SimpleChanges } from '@angular/core';
import { TranslatePipe } from 'src/app/translate.pipe';
import { Node } from 'src/app/services/node';
import { By } from '@angular/platform-browser';
import { NodemapService } from 'src/app/services/nodemap.service';  
import { ConfigService } from 'src/app/services/config.service';

import { AppnavComponent } from './appnav.component';

describe('AppnavComponent', () => {
  let component: AppnavComponent;
  let fixture: ComponentFixture<AppnavComponent>;
  let nodemapService:NodemapService;
  let configService:ConfigService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AppnavComponent,TranslatePipe],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([]),],
      schemas: [CUSTOM_ELEMENTS_SCHEMA ],
      providers:[NodemapService,ConfigService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppnavComponent);
    component = fixture.componentInstance;
    

    let data=[
      {
        'childs':[],
       'contents':{
            'messageName': 'M.ASM.ASXQCFS.ATOM.I',
            'messageVersion': 'R00000',
            'serviceName': '',
            'language': 'EN'
        },
        'displayAsMenu': true,
        'groupName': '',
        'name': 'ASM CTA Combined History  ASQC',
        'order': ''
        },
        {
        'childs':[],
      'contents':{
            'messageName': 'M.ASM.ASXH1FS.ATOM.I',
            'messageVersion': 'R00000',
            'serviceName': '',
            'language': 'EN'
        },
        'displayAsMenu': true,
        'groupName': '',
        'name': 'Contact History Display  ASHI',
        'order':''
      }
    ]


    let con={}
    let parent=null;
    let Node1=new Node(parent,'Customer Management System',con,'Test')
    let Node2=new Node(parent,'Account Details - ARMB/ARQB/ARAB',con,'Test Data')
    //component.rootNodes=[Node1,Node2]
    component.rootNodes=[
      {
        'childs':data,
         'parent':parent,
         'name':'Customer Management System',
         'content':con,
         'grpName':'Test',   
      },
      {
        'childs':data,
         'parent':parent,
         'name':'Account Details - ARMB/ARQB/ARAB',
         'content':con,
         'grpName':'Test Data',   
      },
    ]

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have correct value of activeitem after execution of dd2Active method',()=>{
    component.dd2Active('Financial Authorisation System')
    expect(component.activeItem).toEqual('Financial Authorisation System');
  })

  it('should have correct value of activeitem after execution of dd2Active method with false value of show',()=>{
    component.dd2Active('Financial Authorisation System',false)
    expect(component.activeItem).toEqual('');
  })

  it('should have dropdown div',()=>{
    let dropdown=fixture.debugElement.query(By.css('#dropdown'))
    expect(dropdown).toBeTruthy();
  })

  it('should have Application link',()=>{
    let application=fixture.debugElement.query(By.css('#dropdownMenuLink'))
    expect(application).toBeTruthy();
  })
  it('Application link should call ddActive on click',()=>{
    let application=fixture.debugElement.query(By.css('#dropdownMenuLink'))
    const callCheck=spyOn(component,'ddActive');
    application.triggerEventHandler(null,'click')
    expect(callCheck).toHaveBeenCalled();
  })

  it('should not have searchbox nav in case of ddActiveflag has false value',()=>{
    let searchBox=fixture.debugElement.query(By.css('#searchBox'))
    expect(searchBox).not.toBeTruthy();
  })
  it('should  have searchbox nav in case of ddActiveflag has true value',()=>{
    component.ddActiveFlag=true
    fixture.detectChanges();
    let searchBox=fixture.debugElement.query(By.css('#searchBox'))
    expect(searchBox).toBeTruthy();
  })

  it('should have correct name for search result',()=>{
    component.ddActiveFlag=true;
    fixture.detectChanges();
    let searchResult=fixture.debugElement.queryAll(By.css('#searchResult'));
    expect(searchResult.length).toBe(component.rootNodes.length)
    component.rootNodes.forEach((item,index)=>{
      expect(searchResult[index].nativeElement.innerHTML).toBe(component.rootNodes[index].name)
    })

  })

  it('should have correct name for search result',()=>{
    component.ddActiveFlag=true;
    fixture.detectChanges();
    let child=fixture.debugElement.queryAll(By.css('#childname'));
    expect(child.length).toBe(component.rootNodes.length)
    component.rootNodes.forEach((item,index)=>{
      expect(child[index].nativeElement.innerHTML).toBe(component.rootNodes[index].childs.name)
    })

  })

 //tohaveBeenCalled

});
