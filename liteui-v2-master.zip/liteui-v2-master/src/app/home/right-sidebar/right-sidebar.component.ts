import { Router,  Route} from '@angular/router';
import { RestService } from './../../services/rest.service';
import { Config, Theme, ConfigService } from './../../services/config.service';
import { AuthService } from './../../auth/auth.service';
import { HttpService } from './../../services/http.service';
import { Component, OnInit } from '@angular/core';
import { ProfileService } from 'src/app/services/profile.service';
import { NodemapService } from 'src/app/services/nodemap.service';
import { MaskingService } from 'src/app/services/masking.service';
import { FilesetService } from './../../services/fileset.service';
import {
  trigger,
  state,
  style,
  animate,
  transition
  // ...
} from '@angular/animations';
import { NONE_TYPE } from '@angular/compiler';
import { TranslationService } from 'src/app/services/translation.service';
import { ConversionService } from 'src/app/services/conversion.service';

@Component({
  selector: 'app-right-sidebar',
  templateUrl: './right-sidebar.component.html',
  styleUrls: ['./right-sidebar.component.css'],
  animations: [
    trigger('openClose', [
    state('open', style({
      opacity: 1, height: '*'
    })),
    state('closed', style({
      opacity: 0, height: 0
    })),
      transition('open => closed', [
        animate('100ms 0.3s')
      ]),
      transition('closed => open', [
        animate('0.1s')
      ]),
  ])
  ]
})

export class RightSidebarComponent implements OnInit {
  config: Config;
  themeCode = 0;
  themeOptions: Array<Theme>;
  languageOptions: any;
  ddActiveFlag = false;
  languageCode = 'EN';
  user: any;
  constructor(private authService: AuthService,
              private configService: ConfigService,
              private restService: RestService,
              private profileService: ProfileService,
              private nodeMapService: NodemapService,
              private maskingService: MaskingService,
              private translationService: TranslationService,
              private conversionService: ConversionService,
              private router: Router,
              private fileSetService: FilesetService) {
    this.config = this.configService.config;
    this.user = this.authService.messageHeader.H_name;
    this.languageCode = this.translationService.getLanguage();
   }
  ngOnInit(): void {
    const userClient = this.configService.messageHeader.H_name?.substring(0, 5);
    this.themeOptions = this.config.themeOptions.filter(theme => theme.client === '00000'
      || theme.client === userClient || userClient === '00000');
    this.languageOptions = this.config.languages;
  }
  reloadApplications() {
    this.nodeMapService.getMessageLinks().subscribe(
      data => {
        this.nodeMapService.update(data);
      });
  }

  logout() {
    this.authService.logout();
    this.nodeMapService.rootNodes = [];
    this.nodeMapService.menuLoaded = false;
    this.restService.user = '';
    this.restService.externalUserFlag = false;
    this.restService.externalUserVerified.next(false);
    this.restService.loadHomePage = false;
    this.router.navigate(['/login']);
  }

  changeTheme() {
    this.profileService.changeTheme(this.themeCode);
  }

  changeLanguage() {
    this.translationService.setLanguage(this.languageCode);
  }

  clearCrossReference() {
    this.configService.resetCrossReferenceRepo();
    this.maskingService.resetMaskingRepo();
    this.restService.gotoPage({linkName: 'Something',
    content: {
      messageName: this.restService.getLastResponse().data.H_messageName,
      messageVersion: this.restService.getLastResponse().data.H_messageVersion
    }
  });
  }
  ddActive() {
    this.themeCode = this.profileService.currentTheme();
    this.languageCode = this.translationService.getLanguage();
    this.ddActiveFlag = true;
  }
  ddHide() {

    this.ddActiveFlag = false;
  }

  toggleDD() {
    this.ddActiveFlag?this.ddHide():this.ddActive();
  }

}

