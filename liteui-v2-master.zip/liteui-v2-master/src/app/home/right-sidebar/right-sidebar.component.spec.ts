import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, SimpleChange, SimpleChanges } from '@angular/core';
import { TranslatePipe } from 'src/app/translate.pipe';
import { Node } from 'src/app/services/node';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; 
import { BrowserModule, By } from '@angular/platform-browser';
import { AuthService } from 'src/app/auth/auth.service';

import { RightSidebarComponent } from './right-sidebar.component';
import { ConversionService } from 'src/app/services/conversion.service';
import { ConfigService } from 'src/app/services/config.service';



describe('RightSidebarComponent', () => {
  let component: RightSidebarComponent;
  let fixture: ComponentFixture<RightSidebarComponent>;
  let configService:ConfigService;
  let authSErvice:AuthService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ RightSidebarComponent ,TranslatePipe],
      imports: [ HttpClientTestingModule,BrowserModule, BrowserAnimationsModule, RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA,ConfigService],
      providers:[AuthService,ConfigService]
    })
    .compileComponents();
  }));


  beforeEach(() => {
    fixture = TestBed.createComponent(RightSidebarComponent);
    component = fixture.componentInstance;

  
    configService=TestBed.inject(ConfigService)
    component.config={
      'remoteUrl': '',
      'loginRequest': '',
      'showSearch': null,
      'menuMessage': '',
      'searchRequest': '',
      'displayDashboard':null,
      'dashboardTitle': '',
      'loginPageTitle':'',
      'documentTitle':'',
      'defaultDateFormat':'DD/MM/YYYY',
      'enableRSA':true,
      'profileMessage':'',
      'makerChecker':'',
      'appCodes':'',
      'documentationFormat': '',
      'documentationRepository': '',
      'ssoLogin':null,
      'selectedTheme':null,
      'themeOptions' : [
        {
            'name': 'Default',
            'fileName': 'theme-fiserv',
            'client': '00000',
            'logo':'',
            'variables' : [
            {
                'name':'primary',
                'value':'#ff6600'
            } ,
            {
              'name':'primary',
                'value':'#ff6600'
            }
            ]
        }
      ],
      'defaultMask':'',
      'enableMask':true,
      'maskByXref': null,
      'maskXrefRepository':[],
      'maskRepository': [],
      'formChangesLimit':null,
      'languages':[{
        'code': 'EN',
        'label': 'English',
        'fileName': 'en.json'
    }],
      'timeOutDuration': null,
      'fileSetChange': ''
    }
    configService.messageHeader={
      'H_name': '00000USERNAME',
      'H_context': '00000803377224594'
    }

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have dropdown div',()=>{
    let dropdown=fixture.debugElement.query(By.css('#dropdown'));
    expect(dropdown).toBeTruthy();
  })
  it('dropdown div should call ddHide method on focusout',()=>{
    let dropdown=fixture.debugElement.query(By.css('#dropdown'));
    const checkCall=spyOn(component,'ddHide');
    dropdown.triggerEventHandler(null,'focusout')
    expect(checkCall).toHaveBeenCalled();
  })


  it('user div should have correct value',()=>{
    component.user='test';
    fixture.detectChanges();
    let user=fixture.debugElement.query(By.css('#user'));
    expect(user.nativeElement.innerHTML).toBe(component.user)
  })

  it('close button should call ddHide on click',()=>{
    let close=fixture.debugElement.query(By.css('#close'));
    const checkCall=spyOn(component,'ddHide');
    close.triggerEventHandler(null,'click'),
    expect(checkCall).toHaveBeenCalled();
  })

  it('reloadApplication  menu link should call reloadApplications on click',()=>{
    component.ddActiveFlag=true;
    fixture.detectChanges()
    let reloadApplication=fixture.debugElement.query(By.css('#reloadApplication'));
    const checkCall=spyOn(component,'reloadApplications');
    reloadApplication.triggerEventHandler(null,'click'),
    expect(checkCall).toHaveBeenCalled();
  })

  it(' changTheme link button should call changeTheme on on Change',()=>{
    component.ddActiveFlag=true;
    fixture.detectChanges()
    let changeTheme=fixture.debugElement.query(By.css('#changeTheme'));
    const checkCall=spyOn(component,'changeTheme');
    changeTheme.triggerEventHandler(null,'change'),
    expect(checkCall).toHaveBeenCalled();
  })

  it('changeTheme should have correct options name',()=>{
    component.ddActiveFlag=true;
    fixture.detectChanges()
    let changeTheme=fixture.debugElement.queryAll(By.css('#themeName'));
    expect(changeTheme.length).toBe(component.themeOptions.length)
    component.themeOptions.forEach((item,index)=>{
      expect(changeTheme[index].nativeElement.innerHTML).toBe(' '+component.themeOptions[index].name+' ')
    })

  })

  //
  it(' language link button should call changelanguage on on Change',()=>{
    component.ddActiveFlag=true;
    fixture.detectChanges()
    let language=fixture.debugElement.query(By.css('#language'));
    const checkCall=spyOn(component,'changeLanguage');
    language.triggerEventHandler(null,'change'),
    expect(checkCall).toHaveBeenCalled();
  })

  it('language menu should have correct options name',()=>{
    component.ddActiveFlag=true;
    fixture.detectChanges()
    let language=fixture.debugElement.queryAll(By.css('#language'));
    expect(language.length).toBe(component.languageOptions.length)
    component.languageOptions.forEach((item,index)=>{
      expect(language[index].nativeElement.innerText).toBe(' '+component.languageOptions[index].label+' '+'('+component.languageOptions[index].code+')'+' ')
    })
  })

  it(' logout link button should call log out on click',()=>{
    component.ddActiveFlag=true;
    fixture.detectChanges()
    let logout=fixture.debugElement.query(By.css('#logOut'));
    const checkCall=spyOn(component,'logout');
    logout.triggerEventHandler(null,'click'),
    expect(checkCall).toHaveBeenCalled();
  })
});
