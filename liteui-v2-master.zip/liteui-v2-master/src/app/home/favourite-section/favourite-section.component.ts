import { RestService } from 'src/app/services/rest.service';
import { Component } from '@angular/core';
import { ProfileService } from './../../services/profile.service';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';

@Component({
  selector: 'app-favourite-section',
  templateUrl: './favourite-section.component.html',
  styleUrls: ['./favourite-section.component.css']
})
export class FavouriteSectionComponent  {
  
  constructor(private profileService: ProfileService, private restService: RestService,
              private route: ActivatedRoute,
              private router: Router ) { }

  getFavourites() {
    return this.profileService.favourites;
  }
  deleteFavourites(item) {
    this.profileService.deleteFavourites(item.content.messageName);
  }
  gotoPage(item) {
    this.restService.post(item.content).subscribe(
      response => {
        this.restService.parse(response);
        this.router.navigate(['/home/page', item.content.messageName]);
      }
    );
  }
  profileWorking() { 
    return this.profileService.serviceStatus;
  }

  updateOnActive() {

  }

}
