import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, SimpleChange, SimpleChanges } from '@angular/core';
import { TranslatePipe } from 'src/app/translate.pipe';
import { Node } from 'src/app/services/node';
import { By } from '@angular/platform-browser';
import { ConfigService } from 'src/app/services/config.service';

import { FavouriteSectionComponent } from './favourite-section.component';

import { ProfileService } from 'src/app/services/profile.service';

class MockProfileService extends ProfileService{

  favourites=[
    {
      'name': 'Customer Number Lookup  ARNL',
      'category1': 'Customer Management System',
      'category2': 'Business Function',
      'category3': '',
      'category4': '',
      'order': '',
      'displayAsMenu': true,
      'content': {
          'messageName': 'M.CMS.ARXNLFS.ATOM.I',
          'messageVersion': 'R00000',
          'serviceName': '',
          'language': 'EN'
      }
  },
  {
      'name': 'Extended Name Lookup  ARCL',
      'category1': 'Customer Management System',
      'category2': 'Business Function',
      'category3': '',
      'category4': '',
      'order': '',
      'displayAsMenu': true,
      'content': {
          'messageName': 'M.CMS.ARXXLFS.ATOM.I',
          'messageVersion': 'R00000',
          'serviceName': 'ARXXLFS',
          'language': 'EN'
      },
      'path': [
          {
              'category': 'Customer Management System',
              'link': 'Customer_Management_System'
          },
          {
              'category': 'Business Function',
              'link': 'Customer_Management_System_Business_Function'
          }
      ]
  }
  ]
}

describe('FavouriteSectionComponent', () => {
  let component: FavouriteSectionComponent;
  let fixture: ComponentFixture<FavouriteSectionComponent>;
  let profileService:ProfileService;
  let configService:ConfigService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ FavouriteSectionComponent,TranslatePipe],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [ProfileService,ConfigService,
        {
            provide: ProfileService,
            useClass:MockProfileService
        },
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FavouriteSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have error div when profileWorking return false',()=>{
    spyOn(component,'profileWorking').and.returnValue(false);
    fixture.detectChanges();
    let error=fixture.debugElement.query(By.css('#error'));
    expect(error).toBeTruthy();
  })

  it('should not have error div when profileWorking return true',()=>{
    spyOn(component,'profileWorking').and.returnValue(true);
    fixture.detectChanges();
    let error=fixture.debugElement.query(By.css('#error'));
    expect(error).not.toBeTruthy();
  })

  it('delete button should call deleteFavourite method on click',()=>{
    spyOn(component,'profileWorking').and.returnValue(true);
    fixture.detectChanges();
    let error=fixture.debugElement.query(By.css('#delete'));
    let callCheck=spyOn(component,'deleteFavourites');
    error.triggerEventHandler(null,'click');
    expect(callCheck).toHaveBeenCalled();
  })

  it('should have item of getFavourites',()=>{
    spyOn(component,'profileWorking').and.returnValue(true);
    fixture.detectChanges();
    let getFavourites=fixture.debugElement.queryAll(By.css('#favourites'));
    expect(getFavourites.length).toBe(component.getFavourites().length);
   component.getFavourites().forEach((item,index)=>{
      expect(getFavourites[index].nativeElement.innerHTML).toBe(component.getFavourites()[index].name)
    })
  })

  it('favourite item button should call gotoPage method on click',()=>{
    spyOn(component,'profileWorking').and.returnValue(true);
    fixture.detectChanges();
    let error=fixture.debugElement.query(By.css('#favourites'));
    let callCheck=spyOn(component,'gotoPage');
    error.triggerEventHandler(null,'click');
    expect(callCheck).toHaveBeenCalled();
  })

  it('should have correct category1 of getFavourites',()=>{
    spyOn(component,'profileWorking').and.returnValue(true);
    fixture.detectChanges();
    let category1=fixture.debugElement.queryAll(By.css('#category1'));
    expect(category1.length).toBe(component.getFavourites().length);
   component.getFavourites().forEach((item,index)=>{
      expect(category1[index].nativeElement.innerHTML).toBe(component.getFavourites()[index].category1)
    })
  })

  it('should have correct category2 of getFavourites',()=>{
    spyOn(component,'profileWorking').and.returnValue(true);
    fixture.detectChanges();
    let category2=fixture.debugElement.queryAll(By.css('#category2'));
    expect(category2.length).toBe(component.getFavourites().length);
   component.getFavourites().forEach((item,index)=>{
      expect(category2[index].nativeElement.innerHTML).toBe(component.getFavourites()[index].category2)
    })
  })
});
