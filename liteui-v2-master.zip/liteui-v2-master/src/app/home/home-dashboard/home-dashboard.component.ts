import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { Component, OnChanges, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { PageContainerComponent } from 'src/app/form-renderer/containers/page-container/page-container.component';
import { ConversionService } from 'src/app/services/conversion.service';
import { RestService } from 'src/app/services/rest.service';
const data: any = require('src/assets/mock/sample.sample1.json');
@Component({
  selector: 'app-home-dashboard',
  templateUrl: './home-dashboard.component.html',
  styleUrls: ['./home-dashboard.component.css']
})
export class HomeDashboardComponent implements OnInit, OnChanges {
  showData: any;
  previousPage = '';
  ddActiveFlag = false;
  pageContainerOptions = {showBreadcrumbs: true, hideButtons: false};

  constructor(private conversionService: ConversionService,
              private restService: RestService,
              private router: Router,
              private formvalidatorService: FormvalidatorService) { }


  ngOnInit() {
    this.updateOnActive();
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  }

  updateOnActive() {
    const a = this.restService.getLastResponse();
    if ( JSON.stringify(a) === this.previousPage) {
      return;
    }
    this.previousPage = (JSON.stringify(a));
    this.showData = {}; 
    this.showData.pageId = crypto.getRandomValues(new Uint8Array(4)).join('').toString();
    this.formvalidatorService.setOptions( this.showData.pageId, this.conversionService.convert(a));
    this.showData = this.formvalidatorService.getOptions(this.showData.pageId);
  }
  getShowData() {
    if(this.formvalidatorService.getLatestPageId()){
      this.showData = this.formvalidatorService.getOptions(this.formvalidatorService.getLatestPageId());
    }
    return this.showData;
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.updateOnActive();
  }

}
