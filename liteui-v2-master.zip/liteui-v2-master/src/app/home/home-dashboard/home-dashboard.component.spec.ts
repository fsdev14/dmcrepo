import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, SimpleChange, SimpleChanges } from '@angular/core';
import { TranslatePipe } from 'src/app/translate.pipe';
import { Node } from 'src/app/services/node';
import { BrowserModule, By } from '@angular/platform-browser';
import { ConfigService } from 'src/app/services/config.service';
import { HomeDashboardComponent } from './home-dashboard.component';
import { ConversionService } from 'src/app/services/conversion.service';

class MockConversionService extends ConversionService{

  data={
   

  
    'adhocButtonLayer':[
        {
            'id': 'button14',
            'buttonName': 'Query',
            'displayAsButton': true,
            'displayAsLink': false,
            'targetMessage': {
                'messageName': 'M.CMS.AMPS7AS.AS.QU.QUERY1',
                'messageVersion': 'R00000'
            },
            'keyFieldCodeMapping': [
                {
                    'parentMessageFieldCode': '5003',
                    'targetMessageFieldCode': '5003'
                },
                {
                    'parentMessageFieldCode': '5004',
                    'targetMessageFieldCode': '5004'
                },
                {
                    'parentMessageFieldCode': '4728',
                    'targetMessageFieldCode': '4728'
                },
                {
                    'parentMessageFieldCode': '4729',
                    'targetMessageFieldCode': '4729'
                }
            ],
            'fieldCodeMapping': [],
            'constants': {}
        }
    ],
    'fields':{
    '4728':{
        'type': 'number',
        'readonly': false,
        'hidden': false,
        'label': 'Record Number',
        'name': '4728',
        'isKeyField': true,
        'order': 3,
        'fieldClass': ''
    }
  
    },
    'form':{
        'attributes': {
            'action': '',
            'method': 'post'
        },
        'buttons': {
            'submit': {
                'value': 'List'
            },
            'button14': {
                'value': 'Query'
            }
        }
    },
    'links': undefined,
    'messageName': 'M.CMS.AMPS7AS.AS.GE.GET-LIST',
    'pageName': 'Amortization Details - ARMA09/10/16/ARQA',
    'renderForm': 'true'
    }
  public convert(request: any):any{
      return this.data;
  }

  }


describe('HomeDashboardComponent', () => {
  let component: HomeDashboardComponent;
  let fixture: ComponentFixture<HomeDashboardComponent>;
  let conversionService:ConversionService;
  let configService:ConfigService

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ HomeDashboardComponent,TranslatePipe],
      imports: [ HttpClientTestingModule,BrowserModule, RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [ConversionService,ConfigService,
        {
            provide: ConversionService,
            useClass:MockConversionService
        },
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have appPage element',()=>{
    let appPage=fixture.debugElement.query(By.css('#appPage'));
    expect(appPage).toBeTruthy();
  })
});
