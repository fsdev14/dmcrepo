import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, SimpleChange, SimpleChanges } from '@angular/core';
import { TranslatePipe } from 'src/app/translate.pipe';
import { Node } from 'src/app/services/node';
import { By } from '@angular/platform-browser';
import { ConfigService } from 'src/app/services/config.service';
import { AppmenuComponent } from './appmenu.component';
import { NodemapService } from 'src/app/services/nodemap.service';

class MockNodemapService extends NodemapService{

  rootNodes=[
    {
      'childs':[
        {
          'childs':[],
          'contents':{
            'language': 'EN',
            'messageName': 'M.ASM.ASXQCFS.ATOM.I',
            'messageVersion': 'R00000',
'             serviceName': '',
          },
          'displayAsMenu': true,
           'groupName': ' ',
           'name': 'ASM CTA Combined History  ASQ',
          'order': ''
        }
      ],
      'displayAsMenu': undefined,
      'groupName': 'Account_Services_Management_Business_Function',
      'name': 'Business Function',
      'order': ''
  }
  ];
  nodeMap= {
    'Account_Service_Management':{
        'childs':[
          {
            'childs':[],
            'contents':{
              'language': 'EN',
              'messageName': 'M.ASM.ASXQCFS.ATOM.I',
              'messageVersion': 'R00000',
'             serviceName': '',
            },
            'displayAsMenu': undefined,
             'groupName': 'Account_Services_Management',
             'name': 'Account Services Management',
          }
        ],
        'displayAsMenu': undefined,
        'groupName': 'Account_Services_Management',
        'name': 'Account Services Management',
        
    }
  };
}

describe('AppmenuComponent', () => {
  let component: AppmenuComponent;
  let fixture: ComponentFixture<AppmenuComponent>;
  let mockNodemapService:MockNodemapService;
  let confiService:ConfigService;
  let clickedData={
    'childs':[
      {
        'childs':[],
        'contents':{
          'language': 'EN',
          'messageName': 'M.ASM.ASXQCFS.ATOM.I',
          'messageVersion': 'R00000',
'             serviceName': '',
        },
        'displayAsMenu': undefined,
         'groupName': 'Account_Services_Management',
         'name': 'Account Services Management',
      }
    ],
    'displayAsMenu': undefined,
    'groupName': 'Account_Services_Management',
    'name': 'Account Services Management'
}
 

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AppmenuComponent,TranslatePipe],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([]),],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [NodemapService,ConfigService,
        {
            provide: NodemapService,
            useClass:MockNodemapService
        },
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppmenuComponent);
    component = fixture.componentInstance;
    let clickedData={
      'childs':[
        {
          'childs':[],
          'contents':{
            'language': 'EN',
            'messageName': 'M.ASM.ASXQCFS.ATOM.I',
            'messageVersion': 'R00000',
'             serviceName': '',
          },
          'displayAsMenu': undefined,
           'groupName': 'Account_Services_Management',
           'name': 'Account Services Management',
        }
      ],
      'displayAsMenu': undefined,
      'groupName': 'Account_Services_Management',
      'name': 'Account Services Management'
  }
   //mockNodemapService=TestBed.inject(MockNodemapService)
 
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  it('should have correct page title in case of undefined selectNode.name',()=>{
    component.showMenuComponents();
    expect(component.pageTitle).toEqual('Applications')
  })

  it('should have correct length of list in case of undefined selectNode.name',()=>{
    component.showMenuComponents()
    expect(component.list.length).toEqual(1)
  })

  it('should have correct list and correct data in clicked listin case of selectNode.name',()=>{
    component.selectNode.name= 'Account_Service_Management';
    component.showMenuComponents()
    expect(component.clicked).toEqual(clickedData)
  })

  it('should have showMenu element',()=>{
    let showMenu=fixture.debugElement.query(By.css('#showMenu'))
    expect(showMenu).toBeTruthy();
  })

  it('should have correct title',()=>{
    let title=fixture.debugElement.query(By.css('#title'));
    expect(title.nativeElement.innerHTML).toBe(component.pageTitle)
  })


  it('should have correct heading name from category list',()=>{
    const heading=fixture.debugElement.queryAll(By.css('#category'))
    expect(heading.length).toEqual(component.categoryList.length);
    expect(heading).toBeTruthy();
    component.categoryList.forEach((links,index)=>{
    expect(heading[index].properties.innerHTML).toEqual(component.categoryList[index]);
     })
  })

  it('should have correct categories button name from categories',()=>{
    const categoriesBtn=fixture.debugElement.queryAll(By.css('#categoriesBtn')) 
    for(let i=0;i<component.categoryList.length;i++){
      component.categories[component.categoryList[i]].forEach((links,index)=>{
        expect(categoriesBtn[index].properties.innerHTML).toEqual(component.categories[component.categoryList[i]][i].name)
      })
    }
    
  })

  it('categories button name from categories should call gotoPage(items) on clicke',()=>{
    const categoriesBtn=fixture.debugElement.query(By.css('#categoriesBtn')) 
    const callCheck=spyOn(component,'gotoPage');
    categoriesBtn.triggerEventHandler(null,'click');
    expect(callCheck).toHaveBeenCalled();
    
  })
  


  
});
