import { switchMap } from 'rxjs/operators';
import { Component, OnInit, OnChanges } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { Node } from 'src/app/services/node';
import { NodemapService } from 'src/app/services/nodemap.service';
import { RestService } from 'src/app/services/rest.service';
import { SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-appmenu',
  templateUrl: './appmenu.component.html',
  styleUrls: ['./appmenu.component.css']
})
export class AppmenuComponent implements OnInit, OnChanges {
  list: Array<Node>;
  categories: any = {};
  categoryList: Array<string> = [];
  clicked: any;
  pageTitle = 'Functions';
  selectNode: any;
  
  constructor(private route: ActivatedRoute,
              private router: Router,
              private nodemapservice: NodemapService,
              private restService: RestService) { }

  ngOnInit(): void {
    this.route.params
      .subscribe(parm => {
        this.selectNode = parm;
      });
  }
  ngOnChanges(changes: SimpleChanges): void {
    this.list = this.nodemapservice.rootNodes;
  }

  showMenuComponents() {
    if (this.selectNode.name === undefined) {
      this.pageTitle = 'Applications';
      this.list = this.nodemapservice.rootNodes;
    } else {
      this.clicked = this.nodemapservice.nodeMap[this.selectNode.name];
      this.list = this.clicked.childs.sort();
    }

    let category = '';
    this.categoryList = [];
    this.categories = {};
    for (const x of this.list) {
      // This is to group alphabetically by picking the first character of the name.
      // It is possible 1st character is empty
      if (category !== x.name.charAt(0).toLocaleUpperCase() && x.name.trim().length > 0) {
        category = x.name.charAt(0).toLocaleUpperCase();
        if(!this.categoryList.includes(category)) {
          this.categories[category] = [];
          this.categoryList.push(category);
        }
      }
      if (category !== '') {
        this.categories[category].push(x);
      }

    }
    return true;
  }

  gotoPage(item: any) {
    this.restService.gotoPage(item);
  }

  updateOnActive() {

  }

}



