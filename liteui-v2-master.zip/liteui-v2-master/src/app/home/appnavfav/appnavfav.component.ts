import { ActivatedRoute, Router } from '@angular/router';
import { Component } from '@angular/core';
import { RestService } from 'src/app/services/rest.service';
import { ProfileService } from 'src/app/services/profile.service';

@Component({
  selector: 'app-appnavfav',
  templateUrl: './appnavfav.component.html',
  styleUrls: ['./appnavfav.component.scss']
})
export class AppnavfavComponent {

  constructor(private profileService: ProfileService, private router: Router,
              private route: ActivatedRoute,
              private restService: RestService) { }
  appNavToggle: any;
  rootNodes: any;
  ddActiveFlag = false;
  dd2ActiveFlag = false;
  activeItem = '';


  gotoPage(item) {
    this.ddHide();
    this.restService.post(item.content).subscribe(
      response => {
        this.restService.parse(response);
        this.router.navigate(['/home/page', item.content.messageName]);
      }
    );
  }
  getFavourites() {
    return this.profileService.favourites;
  }
  profileWorking(): boolean {
    return this.profileService.serviceStatus;
  }
  toggleDD(){
    this.ddActiveFlag = !this.ddActiveFlag;
  }
  ddActive() {
    this.ddActiveFlag = true;
  }
  ddHide() {
    this.ddActiveFlag = false;
  }
  dd2Active(activeItem, show = true) {
    if (show) {
      this.activeItem = activeItem;
    } else {
      this.activeItem = '';
    }

  }
  focus(event) {
    console.log(event);
  }

}
