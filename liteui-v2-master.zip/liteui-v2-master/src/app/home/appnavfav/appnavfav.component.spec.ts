import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, SimpleChange, SimpleChanges } from '@angular/core';
import { TranslatePipe } from 'src/app/translate.pipe';
import { Node } from 'src/app/services/node';
import { By } from '@angular/platform-browser';

import { AppnavfavComponent } from './appnavfav.component';
import { ProfileService } from 'src/app/services/profile.service';
import { ConfigService } from 'src/app/services/config.service';

class MockProfileService extends ProfileService{

  favourites=[
    {
      'name': 'Customer Number Lookup  ARNL',
      'category1': 'Customer Management System',
      'category2': 'Business Function',
      'category3': '',
      'category4': '',
      'order': '',
      'displayAsMenu': true,
      'content': {
          'messageName': 'M.CMS.ARXNLFS.ATOM.I',
          'messageVersion': 'R00000',
          'serviceName': '',
          'language': 'EN'
      }
  },
  {
    'name': 'Extended Name Lookup  ARCL',
    'category1': 'Customer Management System',
    'category2': 'Business Function',
    'category3': '',
    'category4': '',
    'order': '',
    'displayAsMenu': true,
    'content': {
        'messageName': 'M.CMS.ARXXLFS.ATOM.I',
        'messageVersion': 'R00000',
        'serviceName': 'ARXXLFS',
        'language': 'EN'
    }
}
  ]
}


describe('AppnavfavComponent', () => {
  let component: AppnavfavComponent;
  let fixture: ComponentFixture<AppnavfavComponent>;
  let profileService:ProfileService;
  let configService:ConfigService

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AppnavfavComponent,TranslatePipe],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([]),],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [ProfileService,ConfigService,
        {
            provide: ProfileService,
            useClass:MockProfileService
        },
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppnavfavComponent);
    component = fixture.componentInstance;
    component.getFavourites();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have correct value of activeitem after execution of dd2Active method',()=>{
    component.dd2Active('Financial Authorisation System')
    expect(component.activeItem).toEqual('Financial Authorisation System');
  })

  it('should have correct value of activeitem after execution of dd2Active method with false value of show',()=>{
    component.dd2Active('Financial Authorisation System',false)
    expect(component.activeItem).toEqual('');
  })

  it('should have dropdown class div in case of profileWorking method return true',()=>{
    spyOn(component,'profileWorking').and.returnValue(true);
    fixture.detectChanges();
    let dropdown=fixture.debugElement.query(By.css('#dropdown'));
    expect(dropdown).toBeTruthy();
  })

  it(' dropdown should call focus on focus event',()=>{
    spyOn(component,'profileWorking').and.returnValue(true);
    fixture.detectChanges();
    let dropdown=fixture.debugElement.query(By.css('#dropdown'));
    let callCheck=spyOn(component,'focus');
    dropdown.triggerEventHandler(null,'focus')
    expect(callCheck).toHaveBeenCalled();
  })

  it('should not have dropdown class div in case of profileWorking method return false',()=>{
    spyOn(component,'profileWorking').and.returnValue(false);
    fixture.detectChanges();
    let dropdown=fixture.debugElement.query(By.css('#dropdown'));
    expect(dropdown).not.toBeTruthy();
  })

  it('should have dropdownMenuLink tag should call toggleDD on click',()=>{
    spyOn(component,'profileWorking').and.returnValue(true);
    fixture.detectChanges();
    const callCheck=spyOn(component,'toggleDD')
    let dropdownMenuLink=fixture.debugElement.query(By.css('#dropdownMenuLink'));
    dropdownMenuLink.triggerEventHandler(null,'click')
    expect(callCheck).toHaveBeenCalled();
  })

  it('should have dropdown menu class div in case of ddActiveFlag have true value',()=>{
    spyOn(component,'profileWorking').and.returnValue(true);
    component.ddActiveFlag=true;
    fixture.detectChanges();
    let dropdownmenu=fixture.debugElement.query(By.css('#dropdownMenu'));
    expect(dropdownmenu).toBeTruthy();
  })

  it('should not have dropdown menu class div in case of ddActiveFlag have false value',()=>{
    spyOn(component,'profileWorking').and.returnValue(true);
    component.ddActiveFlag=false;
    fixture.detectChanges();
    let dropdownmenu=fixture.debugElement.query(By.css('#dropdownMenu'));
    expect(dropdownmenu).not.toBeTruthy();
  })

  it(' dropdown menu should call focus method on focus event',()=>{
    spyOn(component,'profileWorking').and.returnValue(true);
    component.ddActiveFlag=true;
    fixture.detectChanges();
    let dropdownmenu=fixture.debugElement.query(By.css('#dropdownMenu'));
    const callCheck=spyOn(component,'focus');
    dropdownmenu.triggerEventHandler(null,'focus');
   expect(callCheck).toHaveBeenCalled();
  })

  it('should have dropdown item class div in case of ddActiveFlag have true value',()=>{
    spyOn(component,'profileWorking').and.returnValue(true);
    component.ddActiveFlag=true;
    fixture.detectChanges();
    let dropdownitem=fixture.debugElement.query(By.css('#dropdownItem'));
    expect(dropdownitem).toBeTruthy();
  })

  it('should not have dropdown item class div in case of ddActiveFlag have false value',()=>{
    spyOn(component,'profileWorking').and.returnValue(true);
    component.ddActiveFlag=false;
    fixture.detectChanges();
    let dropdownitem=fixture.debugElement.query(By.css('#dropdownItem'));
    expect(dropdownitem).not.toBeTruthy();
  })

  it(' dropdown item should call focus ddhide method on click event',()=>{
    spyOn(component,'profileWorking').and.returnValue(true);
    component.ddActiveFlag=true;
    fixture.detectChanges();
    let dropdownItemLink=fixture.debugElement.query(By.css('#dropdownItemLink'));
    const callCheck=spyOn(component,'ddHide');
    dropdownItemLink.triggerEventHandler(null,'click');
   expect(callCheck).toHaveBeenCalled();
  })


  it('getFavourites item should call gotoPage method on click',()=>{
    spyOn(component,'profileWorking').and.returnValue(true);
    component.ddActiveFlag=true;
    fixture.detectChanges();
    let getFavourites=fixture.debugElement.query(By.css('#favourites'));
    const callCheck=spyOn(component,'gotoPage');
    getFavourites.triggerEventHandler(null,'click');
    expect(callCheck).toHaveBeenCalled();
    
  })


});
