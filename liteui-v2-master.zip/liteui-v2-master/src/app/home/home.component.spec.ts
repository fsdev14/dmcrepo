import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { Config, ConfigService } from '../services/config.service';
import { AuthService } from '../auth/auth.service';
import { NodemapService } from '../services/nodemap.service';
import { RestService } from '../../app/services/rest.service';
import { FilesetService } from './../services/fileset.service';
import { ProfileService } from 'src/app/services/profile.service';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, SimpleChange, SimpleChanges } from '@angular/core';
import { TranslatePipe } from 'src/app/translate.pipe';
import { Node } from 'src/app/services/node';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; 
import { BrowserModule, By } from '@angular/platform-browser';

import { HomeComponent } from './home.component';
import { Observable } from 'rxjs';
class MockConfigService extends ConfigService{
  config={
    'remoteUrl': 'https://d4dvwb001.1dc.com/devddmc',
    'loginRequest': '',
    'showSearch': null,
    'menuMessage': '',
    'searchRequest': '',
    'displayDashboard':null,
    'dashboardTitle': '',
    'loginPageTitle':'',
    'documentTitle':'',
    'defaultDateFormat':'DD/MM/YYYY',
    'enableRSA':true,
    'documentationFormat': '',
    'documentationRepository': '',
    'ssoLogin':null,
    'profileMessage':'',
    'makerChecker':'',
    'appCodes':'',
    'fileSetChange':{},
    'timeOutDuration':14,
    'selectedTheme':null,
    'themeOptions' : [
      {
          'name': 'Default',
          'fileName': 'theme-fiserv',
          'client': '00000',
          'logo':'',
          'variables' : [
          {
              'name':'primary',
              'value':'#ff6600'
          } ,
          {
            'name':'primary',
              'value':'#ff6600'
          }
          ]
      }
    ],
    'defaultMask':'',
    'enableMask':true,
    'maskByXref': null,
    'maskXrefRepository':[],
    'maskRepository': [],
    'formChangesLimit':null,
    'languages':[{
      'code': 'EN',
      'label': 'English',
      'fileName': 'en.json'
    }]
}
}

class MockNodeMapService extends NodemapService{
  getMessageLinks(): Observable<any> {
      return  new Observable<any>();
  }
}


describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;
  let configService:ConfigService;
  let filesetService:FilesetService

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ HomeComponent ],
      imports: [ HttpClientTestingModule,BrowserModule, BrowserAnimationsModule, RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA,ConfigService,FilesetService],
      providers: [
        {
            provide: ConfigService,
            useClass:MockConfigService
        },
        {
          provide:NodemapService,
          useClass:MockNodeMapService
        }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    filesetService=TestBed.inject(FilesetService)
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('title should be correct',()=>{
    component.title='fiserv';
    fixture.detectChanges();
    let title=fixture.debugElement.query(By.css('#title'));
    expect(title.nativeElement.innerText).toBe(component.title);
  })

  it('should have correct region name',()=>{
    let regionName=fixture.debugElement.query(By.css('#regionName'));
    expect(regionName.nativeElement.innerText).toBe(component.regionname)
  })


});
