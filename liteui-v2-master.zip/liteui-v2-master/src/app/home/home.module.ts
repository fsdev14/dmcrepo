import { AuthGuard } from './../auth/auth.guard';
import { AuthModule } from './../auth/auth.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeComponent } from './home.component';
import { HomeDashboardComponent } from './home-dashboard/home-dashboard.component';

import { HomeRoutingModule } from './home-routing.module';
import { SearchComponent } from './search/search.component';
import { AppnavComponent } from './appnav/appnav.component';
import { AppnavfavComponent } from './appnavfav/appnavfav.component';

import { SecretResetComponent } from '../auth/secret-reset/secret-reset.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RightSidebarComponent } from './right-sidebar/right-sidebar.component';
import { GenericContainerComponent } from 'src/app/form-renderer/containers/generic-container/generic-container.component';
import { GenericControlComponent } from 'src/app/form-renderer/controls/generic-control/generic-control.component';
import { AnyControlComponent } from 'src/app/form-renderer/controls/any-control/any-control.component';
import { TextControlComponent } from 'src/app/form-renderer/controls/text-control/text-control.component';
import { NumberControlComponent } from 'src/app/form-renderer/controls/number-control/number-control.component';
import { DateControlComponent } from 'src/app/form-renderer/controls/date-control/date-control.component';
import { DropdownControlComponent } from 'src/app/form-renderer/controls/dropdown-control/dropdown-control.component';
import { HiddenControlComponent } from 'src/app/form-renderer/controls/hidden-control/hidden-control.component';
import { FormContainerComponent } from 'src/app/form-renderer/containers/form-container/form-container.component';
import { PageContainerComponent } from 'src/app/form-renderer/containers/page-container/page-container.component';
import { SiblingLinkContainerComponent } from 'src/app/form-renderer/containers/sibling-link-container/sibling-link-container.component';
import { FormButtonContainerComponent } from 'src/app/form-renderer/containers/form-button-container/form-button-container.component';
import { ObjectControlComponent } from 'src/app/form-renderer/controls/object-control/object-control.component';
import { TableControlComponent } from 'src/app/form-renderer/controls/table-control/table-control.component';
import { TableControlMakerComponent } from 'src/app/form-renderer/controls/table-control-maker/table-control-maker.component';
import { TableMakerCheckerComponent } from 'src/app/form-renderer/controls/table-maker-checker/table-maker-checker.component';
import { LabelControlComponent } from 'src/app/form-renderer/controls/label-control/label-control.component';
import { ShowErrorsComponent } from 'src/app/form-renderer/controls/show-errors/show-errors.component';
import { CurrencyControlComponent } from 'src/app/form-renderer/controls/currency-control/currency-control.component';
import { AppmenuComponent } from 'src/app/home/appmenu/appmenu.component';
import { FavouriteSectionComponent } from './favourite-section/favourite-section.component';
import { AppBreadcrumbComponent } from './app-breadcrumb/app-breadcrumb.component';
import { ListtableContainerComponent } from 'src/app/form-renderer/containers/listtable-container/listtable-container.component';
import { SectionLinkContainerComponent } from 'src/app/form-renderer/containers/section-link-container/section-link-container.component';
import { SearchPipe } from 'src/app/search.pipe';
import { MaskingPipe } from 'src/app/masking.pipe';
import { UrlControlComponent } from 'src/app/form-renderer/controls/url-control/url-control.component';
import { TranslatePipe } from 'src/app/translate.pipe';
import { PasswordControlComponent } from '../form-renderer/controls/password-control/password-control.component';
import { ChartControlComponent } from '../form-renderer/controls/chart-control/chart-control.component';
import { TablePagePipe } from '../table-page.pipe';
@NgModule({
  imports: [
    CommonModule,
    HomeRoutingModule,
    AuthModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers:[
    AuthGuard
  ],
  declarations: [
    HomeComponent,
    HomeDashboardComponent,
    SearchComponent,
    AppnavComponent,
    AppnavfavComponent,
    SecretResetComponent,
    RightSidebarComponent,
    GenericContainerComponent,
    GenericControlComponent,
    AnyControlComponent,
    FormContainerComponent,
    PageContainerComponent,
    SiblingLinkContainerComponent,
    FormButtonContainerComponent,
    TextControlComponent,
    HiddenControlComponent,
    NumberControlComponent,
    DateControlComponent,
    DropdownControlComponent,
    AppmenuComponent,
    FavouriteSectionComponent,
    ObjectControlComponent,
    TableControlComponent,
    TableControlMakerComponent,
    TableMakerCheckerComponent,
    LabelControlComponent,
    ShowErrorsComponent,
    CurrencyControlComponent,
    AppBreadcrumbComponent,
    ListtableContainerComponent,
    SectionLinkContainerComponent,
    SearchPipe,
    UrlControlComponent,
    MaskingPipe,
	  PasswordControlComponent,
    TranslatePipe,
    TablePagePipe,
    ChartControlComponent
  ],
  exports: [SecretResetComponent]
})
export class HomeModule {}
