import { FavouriteSectionComponent } from './favourite-section/favourite-section.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from './home.component';

import { AuthGuard } from '../auth/auth.guard';
import { HomeDashboardComponent } from './home-dashboard/home-dashboard.component';
import { AppnavComponent } from './appnav/appnav.component';
import { AppmenuComponent } from './appmenu/appmenu.component';

const HomeRoutes: Routes = [
  {
    path: '',
    component: HomeComponent,
    canActivate: [AuthGuard],
    children: [
          { path: 'page/:name', canActivate: [AuthGuard], component: HomeDashboardComponent  },
          { path: 'menu/:name', canActivate: [AuthGuard], component: AppmenuComponent },
          { path: 'menu', canActivate: [AuthGuard], component: AppmenuComponent },
          { path: 'favourites', canActivate: [AuthGuard], component: FavouriteSectionComponent},
          { path: '', redirectTo: 'menu', pathMatch: 'full' }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(HomeRoutes )
  ],
  exports: [
    RouterModule
  ]
})
export class HomeRoutingModule { }
