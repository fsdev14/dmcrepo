import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, SimpleChange, SimpleChanges } from '@angular/core';
import { TranslatePipe } from 'src/app/translate.pipe';
import { AppBreadcrumbComponent } from './app-breadcrumb.component';
import { Node } from 'src/app/services/node';
import { By } from '@angular/platform-browser';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { RestService } from 'src/app/services/rest.service';
import { ConfigService } from 'src/app/services/config.service';

describe('AppBreadcrumbComponent', () => {
  let component: AppBreadcrumbComponent;
  let fixture: ComponentFixture<AppBreadcrumbComponent>;
  let restService:RestService;
  let configService:ConfigService;
 

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AppBreadcrumbComponent,TranslatePipe],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[RestService,ConfigService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppBreadcrumbComponent);
    component = fixture.componentInstance;
    let con={}
    let parent=null;
    let Node1=new Node(parent,'Customer Management System',con,'Test')
    let Node2=new Node(parent,'Account Details - ARMB/ARQB/ARAB',con,'Test Data')
    //component.crumbs=[Node1,Node2]

   
    
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  it('should have empty crumbs array',()=>{ 
      let changes:SimpleChanges;
      component.ngOnChanges(changes)
      expect(component.crumbs).toEqual([]);
  })

  

  

});
