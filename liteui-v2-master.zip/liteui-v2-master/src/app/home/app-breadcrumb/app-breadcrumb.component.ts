import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { RestService } from 'src/app/services/rest.service';
import {Node} from 'src/app/services/node';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './app-breadcrumb.component.html',
  styleUrls: ['./app-breadcrumb.component.css']
})
export class AppBreadcrumbComponent implements OnInit {

  @Input() content: any;
  crumbs: Array<Node>[];
  conversionService: any;
  constructor(private restService: RestService) { }

  ngOnInit(): void {
  }

  gotoMenu(item: any) {
     this.restService.gotoPage(item);
  }



  ngOnChanges(changes: SimpleChanges): void {
    this.crumbs = [];
    do {
      if (this.content === undefined ) {
        return;
      }
      this.crumbs.push(this.content);
      this.content = this.content.parent;
    } while (this.content !== null);
    this.crumbs = this.crumbs.reverse();
  }


}
