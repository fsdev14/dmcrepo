import { Pipe, PipeTransform } from '@angular/core';
import { of } from 'rxjs';

@Pipe({
  name: 'tablePage'
})
export class TablePagePipe implements PipeTransform {

  transform(tableRows: any, pageSize: number, currentPage: number ): any {
    return tableRows.slice((currentPage - 1) * pageSize, currentPage * pageSize );
  }  

}
 