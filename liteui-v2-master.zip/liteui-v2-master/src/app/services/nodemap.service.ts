import { Injectable } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { ConfigService } from './config.service';
import { HttpService } from './http.service';
import { tap } from 'rxjs/operators';
import { Node } from './node';
import { Observable, of } from 'rxjs';
import { RestService } from './rest.service';

@Injectable({
  providedIn: 'root'
})
export class NodemapService {

  constructor(public configService: ConfigService,
              public authService: AuthService, private httpService: HttpService, private restService: RestService) { }
  menuMessage: any;
  menuJson: any;
  isMenuLoading = false;
  menuLoaded = false;
  nodeMap = {};
  rootNodes = [];
  searchableNodes = [];

  hasMenuLoaded(): boolean {
    return this.menuLoaded;
  }
  getMessageLinks(): Observable<any> {

    this.menuMessage = { ...this.authService.messageHeader, ...this.configService.config.menuMessage, };
    if ( this.menuMessage.searchTerm ) {
      delete this.menuMessage.searchTerm;
    }
    this.isMenuLoading = true;
    this.menuMessage['4001'] =  this.configService.messageHeader.H_name.substring(0, 5);
    this.menuMessage['4002'] =  this.configService.messageHeader.H_name.substring(5);
    return this.restService.post(this.menuMessage);

  }

  update(data) {
    this.menuJson = JSON.parse(data).menu;
    this.populateMenuData();
    this.isMenuLoading = false;
    this.menuLoaded = true;
  }

  isNodeInArr(arr: Array<Node>, obj: any) {
    for (const o of arr) {
      if (o.name === obj.name && o.groupName === obj.groupName && (!obj.content || (obj.content.messageName === o.content.messageName))) {
        return o;
      }
    }
    return null;
  }

  compareStrings(a: string, b: string) {

    a = a.toLowerCase();
    b = b.toLowerCase();

    return (a < b) ? -1 : (a > b) ? 1 : 0;
  }
  sortJSON(objs: Array<Node>) {
    objs = objs.sort((a: Node, b: Node) => {
      return this.compareStrings(a.name, b.name);
    });
    return objs;
  }
  /*
   *Utility method to order links according to name alphabetically
   */
  orderRecursiveLinks(parent: Node, nodes: Array<Node>) {

    nodes = this.sortJSON(nodes);
    nodes.forEach(obj => {
      if (obj.childs) {
        this.orderRecursiveLinks(obj, obj.childs);
      }
    });
  }

  childNodeGenerator(parent: Array<Node>, child: Node, flag: boolean) {
    const tempNode = this.isNodeInArr(parent, child);
    if (tempNode == null) {
      if (flag) {
        parent.push(child);
      }
    } else {
      child = tempNode;
    }
    return child;
  }

  /*
   *Function to populate menu nodes data using response JSON
   */
  populateMenuData() {
    this.searchableNodes = [];
    let node: Node;
    let secondNode: Node;
    let thirdNode: Node;
    let fourthNode: Node;
    let msgNode: Node;
    this.menuJson.forEach(obj => {
      if (obj.category1 && obj.category1.trim().length > 0) {
        node = new Node(null, obj.category1, {}, obj.category1.replace(/ /g, '_'));
        node = this.childNodeGenerator(this.rootNodes, node, obj.displayAsMenu);
        this.nodeMap[node.groupName] = node;
        if (obj.category2 && obj.category2.trim().length > 0) {
          secondNode = new Node(node, obj.category2, {}, (node.groupName + '_' + obj.category2).replace(/ /g, '_'));
          secondNode = this.childNodeGenerator(node.childs, secondNode, obj.displayAsMenu);
          this.nodeMap[secondNode.groupName] = secondNode;
          if (obj.category3 && obj.category3.trim().length > 0) {
            thirdNode = new Node(secondNode, obj.category3, {}, (secondNode.groupName + '_' + obj.category3).replace(/ /g, '_'));
            thirdNode = this.childNodeGenerator(secondNode.childs, thirdNode, obj.displayAsMenu);

            this.nodeMap[thirdNode.groupName] = thirdNode;
            if (obj.category4 && obj.category4.trim().length > 0) {
              fourthNode = new Node(thirdNode, obj.category4, {}, (thirdNode.groupName + '_' + obj.category4).replace(/ /g, '_'));
              fourthNode = this.childNodeGenerator(thirdNode.childs, fourthNode, obj.displayAsMenu);
              this.nodeMap[fourthNode.groupName] = fourthNode;

              msgNode = new Node(fourthNode, obj.name, obj.content, '', obj.order, obj.displayAsMenu);
              msgNode = this.childNodeGenerator(fourthNode.childs, msgNode, obj.displayAsMenu);
              this.nodeMap[msgNode.content.messageName] = msgNode;
            } else {
              msgNode = new Node(thirdNode, obj.name, obj.content, '', obj.order, obj.displayAsMenu);
              msgNode = this.childNodeGenerator(thirdNode.childs, msgNode, obj.displayAsMenu);
              this.nodeMap[msgNode.content.messageName] = msgNode;
            }
          } else {
            msgNode = new Node(secondNode, obj.name, obj.content, '', obj.order, obj.displayAsMenu);
            msgNode = this.childNodeGenerator(secondNode.childs, msgNode, obj.displayAsMenu);

            this.nodeMap[msgNode.content.messageName] = msgNode;
          }
        } else {
          msgNode = new Node(node, obj.name, obj.content, '', obj.order, obj.displayAsMenu);
          msgNode = this.childNodeGenerator(node.childs, msgNode, obj.displayAsMenu);

          this.nodeMap[msgNode.content.messageName] = msgNode;
        }
      } else {
        if (obj.name && obj.name.trim().length > 0) {
          msgNode = new Node(null, obj.name, obj.content, '', obj.order, obj.displayAsMenu);
          this.nodeMap[msgNode.content.messageName] = msgNode;

        }
      }
      if (obj.displayAsMenu) {
        let inserted = false;
        for (let i = 0; i < this.searchableNodes.length; i++) {
          if (this.searchableNodes[i].name.localeCompare(obj.name) > 0) {
            inserted = true;
            this.searchableNodes.splice(i, 0, obj);
            break;
          }
        }
        if (!inserted) {
          this.searchableNodes.push(obj);
        }


      }

    });
    this.orderRecursiveLinks(null, this.rootNodes);
  }
}
