import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { IsLoadingService } from '@service-work/is-loading';
import { lastValueFrom, throwError } from 'rxjs';

export interface Config {
    remoteUrl: string;
    loginRequest: any;
    showSearch: boolean;
    menuMessage: any;
    searchRequest: any;
    displayDashboard: boolean;
    dashboardTitle: string;
    loginPageTitle: string;
    documentTitle: string;
    defaultDateFormat: string;
    enableRSA: boolean;
	secretEncryption:boolean;
    ssoLogin: boolean;
    ciamBaseUrl: string;
    svcForMFA: any;
    enableMFA: boolean;
    profileMessage: any;
    makerChecker: any;
    appCodes: any;
    selectedTheme: number;
    themeOptions: Array<Theme>;
    defaultMask: string;
    enableMask: boolean;
    maskByXref: boolean;
    maskXrefRepository: Array<XrefMaskables>;
    maskRepository: Array<Maskables>;
    formChangesLimit: number;
    languages: Array<Languages>;
    timeOutDuration: number;
    fileSetChange: any;
    documentationFormat: string;
    documentationRepository: string;
}

export interface Maskables {
    messageName: string;
    maskFields: [{ name: string, mask: string }];
}
export interface XrefMaskables {
    xref: string;
    mask: string;
}
export interface Languages {
    code: string;
    label: string;
    fileName: string;
}
export interface Theme {
    name: string;
    client: string;
    logo: string;
    fileName: string;
    variables: any;
}
@Injectable()
export class ConfigService {
    config!: Config;
    crossReferenceRepo = {};
    globalCrossReferenceRepo = { WSSCLIENT: null };
    configUrl = 'assets/config.json';
    messageHeader: any;
   
    constructor(private https: HttpClient, private isLoadingService: IsLoadingService) {

    }

    async getConfigData() {
        this.isLoadingService.add();
        this.config = await lastValueFrom(this.https.get<Config>(this.configUrl))

        this.isLoadingService.remove();

    }
    getConfig() {
        return this.config;
    }
    setMasking(enable: boolean): void {
        this.config.enableMask = enable;
    }


    getLoginRequest() {
        return this.config.loginRequest;
    }

    setMessageHeader(header: any) {
        this.messageHeader = header;
    }

    resetCrossReferenceRepo() {
        this.crossReferenceRepo = {};
    }

}
