import { Injectable } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { ConfigService } from './config.service';
import { RestService } from './rest.service';
import { NodemapService } from './nodemap.service';
import { TranslationService } from './translation.service';
import { ErrorHandlingService } from './errorHandling.service';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  config: any;
  profileMessage: any;
  favourites: Array<any>;
  serviceStatus = false;
  menuNodes: any;
  newFav: any;
  selectThemeStore=0;
  logoSrc :any;
  logoStyle:any;

  constructor(
    private configService: ConfigService,
    private restService: RestService,
    private authService: AuthService,
    private translationService: TranslationService,
    private nodeMapService: NodemapService,
    private errorHandlingService: ErrorHandlingService) {
    this.config = this.configService.config;
  }

  loadProfile() {
    this.profileMessage = this.config.profileMessage;
    this.profileMessage['4001'] = this.configService.messageHeader.H_name.substring(0, 5);
    this.profileMessage['4002'] = this.configService.messageHeader.H_name.substring(5);

    return this.restService.post(this.config.profileMessage);
  }
  update(x){
    try {
      const data = this.restService.parse(x).data;

      if (typeof data !== 'undefined') {
        this.configService.config.selectedTheme = data['4006'];
        this.selectThemeStore = data['4006'];
         if(data['4001']==='0'){
          this.applyTheme(data['4006']);
         }
         else{
          this.applyThemeByclientId();
         }
        
       
       
      }

      this.loadFavourites(data.object2.table2);

      let userLanguage = data['4007'] || 'EN';
      if (userLanguage === ' ' || userLanguage === undefined) {
        userLanguage = 'EN';
      }
      this.translationService.setInitialLanguage(userLanguage);

    } catch (error) {
      this.serviceStatus = false;
      console.log(error);
      console.log('Error Loading Favourites Data. Feature will be turned off.');
    }
  }

  changeTheme(theme: number) {
    this.profileMessage['4006'] = theme;
    if(this.serviceStatus) {
      this.restService
        .post(this.profileMessage).subscribe(res => {
          const response = this.restService.parse(res).data;
          if (typeof response !== 'undefined') {
            this.selectThemeStore = theme;
            this.applyTheme(theme);
          }
        });
    }else {
      this.selectThemeStore = theme;
      this.applyTheme(theme);

    }
    
  }
  currentTheme() {
    return this.selectThemeStore;
  }

  applyTheme(theme = 0) {
    if (theme === 4) {
      document.querySelector('audio')?.play();
    } else {
      document.querySelector('audio')?.pause();
   const userClient = this.configService.messageHeader.H_name?.substring(0, 5);  
    const themeOptions = this.config.themeOptions.filter(theme => theme.client === '00000'
      || theme.client === userClient || userClient === '00000');
    const selectedTheme = themeOptions[theme].fileName;
    
    const themeData = themeOptions[theme];
    // if (theme === '2') {
    //   let root = document.documentElement;
    //   root.style.setProperty('--bs-primary', '#ff6600');
    //   root.style.setProperty('--bs-orange', '#ff6600');
    //   root.style.setProperty('--bs-primary', '#ff6600');
    //   root.style.setProperty('--bs-blue', '#2e8bc9');
    //   root.style.setProperty('--bs-teritiary', '#2e8bc9');
    //   root.style.setProperty('--bs-secondary', '#2e8bc9');
    //   root.style.setProperty('--bs-error', '#dd3435');
    //   root.style.setProperty('--bs-danger', '#dd3435');
    //   root.style.setProperty('--bs-warning', '#f3b823');
    //   root.style.setProperty('--bs-success', '#54b34a');
    //   root.style.setProperty('--bs-light', '#333');
    //   root.style.setProperty('--bs-lighter', '#888');
    //   root.style.setProperty('--bs-dark', '#f1f1f1');
    //   root.style.setProperty('--bs-gray', '#0e0e0e');
    //   root.style.setProperty('--bs-black', 'black');
    //   root.style.setProperty('--bs-white', 'white');
    //   root.style.setProperty('--bs-bright', '#222');
    //   root.style.setProperty('--bs-brighter', '#111');
    // }
    const root = document.documentElement;
    themeData.variables.forEach((property) => {
      root.style.setProperty(`--bs-${property.name}`, property.value);
    });

    const body = document.getElementsByTagName('body')[0];
    body.className = selectedTheme;

    const logo = document.getElementById('client-logo') as HTMLImageElement;
    const logoImage = this.getClientLogo();
    if (logoImage === 'undefined') {
      logo.style.display = 'none';
      this.logoSrc = '';
      this.logoStyle = 'none';
    } else {
      logo.style.display = 'inline';
      this.logoStyle = 'inline';
      this.logoSrc = `./assets/images/${logoImage}`;
      logo.src = `./assets/images/${logoImage}`;
    }
  }
  }
  
  
  applyThemeByclientId() {
 const userClient = this.configService.messageHeader.H_name?.substring(0, 5);  
  const themeOptions = this.config.themeOptions.filter(theme => theme.client === '00000'
    || theme.client === userClient || userClient === '00000');
  const themeData = themeOptions.find(t=>t.client===userClient);
  const selectedTheme=themeData.fileName;
  const root = document.documentElement;
  themeData.variables.forEach((property) => {
    root.style.setProperty(`--bs-${property.name}`, property.value);
  });

  const body = document.getElementsByTagName('body')[0];
  body.className = selectedTheme;

  const logo = document.getElementById('client-logo') as HTMLImageElement;
 // const logoImage = themeData.icon;
 const logoImage=`${themeData?.icon}`;
  if (logoImage === 'undefined') {
    logo.style.display = 'none';
    this.logoSrc = '';
    this.logoStyle = 'none';
  } else {
    logo.style.display = 'inline';
    this.logoStyle = 'inline';
    this.logoSrc = `./assets/images/${logoImage}`;
    logo.src = `./assets/images/${logoImage}`;
  }
}

  getClientLogo(): string{
   const userClient = this.configService.messageHeader.H_name?.substring(0, 5);
    const themeOptions = this.config.themeOptions.filter(theme => theme.client === '00000'
      || theme.client === userClient || userClient === '00000');
      return `${themeOptions[this.selectThemeStore]?.icon}`;
  }
  loadFavourites(items: any) {
    this.favourites = [];
    this.menuNodes = this.nodeMapService.menuJson;
    items.forEach( item => {
      if (item['4005'].trim().length > 0 && item['4005'].trim() !== 'undefined') {
        const found = this.menuNodes.filter(x => x.content.messageName.trim() === item['4005'].trim());
        if (found[0]){
          this.favourites.push(found[0]);
        }
        this.serviceStatus = true;
      }
    });
  }

  isFavourite(item: string): boolean {
    try {
     return this.serviceStatus && this.favourites.findIndex(x => x?.content.messageName === item) >= 0;
    } catch (error) {
      console.log('Error checking isFavourite');
      this.errorHandlingService.errorHandler(error.stack,'UIERR0008');
    }
    return false;
  }

  deleteFavourites(item: string) {
    const idx = this.favourites.findIndex(x => x.content.messageName === item);
    if (idx === -1) {return; }

    this.favourites.splice(idx, 1);
    this.serviceFavourites();

  }

  addFavourites(item: string) {
    const newFav = this.nodeMapService.menuJson.find(x => x.content.messageName.trim() === item.trim());
    if (newFav && newFav !== undefined) {
      this.favourites.push(newFav);
      this.serviceFavourites();
    }
  }

  serviceFavourites() {
    const profileMessage = this.config.profileMessage;
    profileMessage['4001'] = this.configService.messageHeader.H_name.substring(0, 5);
    profileMessage['4002'] = this.configService.messageHeader.H_name.substring(5);
    let counter = 0;
    // this.favourites.forEach((val, id) => {
    //   profileMessage['4005_' + (id + 1)] = val.content.messageName;
    //   counter = id + 2;
    // });
    for (; counter < 20; counter++) {
      profileMessage['4005_' + (counter + 1)] = (this.favourites[counter] && this.favourites[counter].content.messageName) || '';
    }

    this.restService.post(profileMessage).subscribe(x => {
      try {
        const data = this.restService.parse(x).data;
      } catch (error) {
        console.log('Profile Service Failed to update. Retry?');
        this.errorHandlingService.errorHandler(error.stack,'UIERR0009');
      }
    });
  }

}

