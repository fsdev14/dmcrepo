export class Node {

    childs: Array<Node> = [];
    parent: Node;
    name: string;
    content: any;
    groupName: string;
    order: number;
    displayAsMenu = true;
    constructor(parent: Node, name: string, content: any, grpName: string, order?: number, displayAsMenu?:boolean) {
        this.parent = parent;
        this.name = name;
        this.content = content;
        this.groupName = grpName;
        this.order = order;
        this.displayAsMenu = displayAsMenu;
    }

    addChild(node: Node) {
        this.childs.push(node);
    }
}
