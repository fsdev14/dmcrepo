import { TestBed } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, SimpleChange, SimpleChanges } from '@angular/core';
import { TranslatePipe } from 'src/app/translate.pipe';
import { MaskingService } from './masking.service';

import { ConversionService } from './conversion.service';
import { ConfigService } from './config.service';

describe('ConversionService', () => {
  let service: ConversionService;
  let maskingService:MaskingService;
  let configService:ConfigService;

  let options:{
    adhocButtonLayer:[],
    fields:{
    '4001':
    {
        'type': 'select',
        'readonly': false,
        'hidden': false,
        'label': 'Primary Data Switch',
        'optionLabels': [
            'Last/Business/Store/Generic Name (0)',
            'Identification Number (1)',
            'Phone Number (2)',
            'Postal Code (3)',
            'Email ID (4)'
        ],
        'name': '4001',
        'removeDefaultNone': true,
        'isKeyField': true,
        'sectionId': 'section1',
        'order': 1,
        'fieldClass': 'col-lg-4 col-md-6'
    },
    '4002':{
        'readonly': false,
        'hidden': false,
        'label': 'Primary Data',
        'name': '4002',
        'isKeyField': true,
        'sectionId': 'section1',
        'order': 2,
        'fieldClass': 'col-lg-8 col-md-12'
    }
    
    form:{
        'attributes': {
            'action': '',
            'method': 'post'
        },
        'buttons': {
            'submit': {
                'value': 'Submit'
            }
        }
    },
    splittoSections:[
        {
            'sectionId': 'section1',
            'sectionName': '01-Customer Name Extended Lookup'
        },
        {
            'sectionId': 'section2',
            'sectionName': '02-Optional Data'
        }
    ],
    tableGridJsonPaths: []
    }
  }

  let data={
    4001: '0',
    4002: ' ',
    4003: '0',
    4009: ' '
    }

    let schemaMap:{
      '0101':{
          'type': 'string',
          'title': ' Security Signon'
      },
      '0102':{
          'type': 'string',
          'title': ' Signon Name'
      }
      }
      
      let view:{
      layout:{
        'bindings':{
        4001: 'key',
        4002: 'key',
        4003: 'key',
        4009: 'nonkey'
      }
      template: './partials/threeColumnLayout.html'
      }
      parent: 'bootstrap-edit'
      }

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[MaskingService,ConfigService]
    });
    service = TestBed.inject(ConversionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  
});
