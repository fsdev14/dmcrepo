import { ConfigService } from './config.service';
import { ProfileService } from 'src/app/services/profile.service';
import { RestService } from 'src/app/services/rest.service';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FilesetService {
  fileSet = '';
  fileSetList = [];
  fileSetChange: any = {};
  config: any;
  fileSetDidOnce = false;
  constructor(private restService: RestService,
    private profileService: ProfileService,
    private configService: ConfigService) {
    this.config = this.configService.config;
  }


  getfileSetValue() {
    const fs = this.restService.getFileSet();
    if (fs === '') {
      return this.fileSet;
    }
    this.fileSet = `FS${fs}`;
    return this.fileSet;
  }
  update(fileSetListData: any) {
    try {
      const fileListData = this.restService.parse(fileSetListData).data.object1.table1;
      this.fileSetList = [];
      fileListData.forEach(element => {
        this.fileSetList.push(Object.values(element));
      });
    } catch (e) {
      console.log(e);
      console.log('Fileset load failed. Feature will be turned off.');
    }

  }
  getFileSetList() {
    return this.fileSetList;
  }
  fetchFileSetList(): Observable<any> {
    let fileSetListMessage: any = {};
    fileSetListMessage['4001'] = '0';
    fileSetListMessage.H_messageName = 'M.WSS.WMXFSFS.ATOM.I';
    fileSetListMessage.H_messageVersion = 'R00000';
    fileSetListMessage.H_language = 'EN';

    return this.restService.post(fileSetListMessage);
  }

  changefileSet(event) {
    this.fileSetChange = this.config.fileSetChange;
    const changeset = event[0]?.replace('FS', '');
    this.fileSetChange['4001'] = '0';
    this.fileSetChange['4002'] = changeset;
    this.restService
      .post(this.fileSetChange).subscribe(res => {
        const response = this.restService.parse(res).data;
        this.fileSet = `FS${response.H_fileSet}`;

      })
  }
}
