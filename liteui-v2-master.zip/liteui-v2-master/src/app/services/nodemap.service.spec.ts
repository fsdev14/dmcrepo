import { TestBed } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthService } from '../auth/auth.service';
import { ConfigService } from './config.service';
import { HttpService } from './http.service';
import { tap } from 'rxjs/operators';
import { Node } from './node';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, SimpleChange, SimpleChanges } from '@angular/core';

import { NodemapService } from './nodemap.service';

class MockAuthService extends AuthService{
  messageHeader={
    'H_name': '00000ASHUBHAM',
    'H_context': '00001599277986135'
}
}

class MockConfigService extends ConfigService{
  messageHeader={
    'H_name': '00000ASHUBHAM',
    'H_context': '00001599277986135'
}
  config={
    'remoteUrl': 'https://d4dvwb001.1dc.com/devddmc',
    'loginRequest': '',
    'showSearch': null,
    'menuMessage': {
      'messageName': 'M.WSS.WMXACFS.ATOM.I',
      'messageVersion': 'R00000',
      'getMessageLinks': true
  },
    'searchRequest': '',
    'displayDashboard':null,
    'dashboardTitle': '',
    'loginPageTitle':'',
    'documentTitle':'',
    'defaultDateFormat':'DD/MM/YYYY',
    'enableRSA':true,
    'profileMessage':'',
    'makerChecker':'',
    'appCodes':'',
    'fileSetChange':{},
    'timeOutDuration':14,
    'selectedTheme':null,
    'themeOptions' : [],
    'defaultMask':'',
    'enableMask':true,
    'maskByXref': null,
    'maskXrefRepository':[],
    'maskRepository': [],
    'formChangesLimit':null,
    'languages':[],
    'documentationFormat': '',
    'documentationRepository': '',
    'ssoLogin':null
}
}

describe('NodemapService', () => {
let service:NodemapService
let configService:ConfigService;
let arr=[{
  'displayAsMenu':undefined,
  'childs': [],
  'addChild':null,
  'order': undefined,
  'parent': null,
  'name': 'Customer Management System',
  'content': {},
  'groupName': 'Customer_Management_System'
}]
let obj=
  {
    'displayAsMenu':undefined,
    'childs': [],
    'addChild':null,
    'order': undefined,
    'parent': null,
    'name': 'Customer Management System',
    'content': {},
    'groupName': 'Customer_Management_System'
  
}

  beforeEach(() => {
    TestBed.configureTestingModule({
    imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[{
        provide: ConfigService,
        useClass:MockConfigService
    },
  {
    provide:AuthService,
    useClass:MockAuthService
  }]
    });
  service = TestBed.inject(NodemapService);
  configService=TestBed.inject(ConfigService);
});
  it('should be created', () => {
    const service: NodemapService = TestBed.get(NodemapService);
    expect(service).toBeTruthy();
  });

  it('hasMenuLoded method should returncorrect value',()=>{
    expect(service.hasMenuLoaded()).toBe(false);
  })

  it('should not have menumessage.searchTerm',()=>{
    service.getMessageLinks();
    expect(service.menuMessage.searchTerm).toBe(undefined)
  })

  it('menuMessage field should have correct value',()=>{
    service.getMessageLinks();
    expect(service.menuMessage['4001']).toBe(configService.messageHeader.H_name.substring(0, 5));
    expect(service.menuMessage['4002']).toBe(configService.messageHeader.H_name.substring(5));
  })

  it('isNodeInArr should return correct value',()=>{
    expect(service.isNodeInArr(arr,obj)).toBe(arr[0]);
  })

  it('isNodeInArr should return null in case of false condition of arr',()=>{
    let arr2=[];
    expect(service.isNodeInArr(arr2,obj)).toBe(null);
  })

  it('childNodeGenerator should return correct value',()=>{
    expect(service.childNodeGenerator(arr,obj,false)).toBe(arr[0]);
  })

  it('childNodeGenerator should return correct value in case isnodeInArr return null',()=>{
    let arr2=[]
    service.childNodeGenerator(arr2,obj,true);
    expect(arr2[0]).toBe(obj);
  })

  it('childNodeGenerator should return correct value in case isnodeInArr return null and flag argument will be false',()=>{
    let arr2=[]
    service.childNodeGenerator(arr2,obj,false);
    expect(arr2[0]).toBe(undefined);
  })
  

  
});
