import { Injectable } from '@angular/core';
import { ConfigService } from './config.service';

@Injectable({
  providedIn: 'root'
})
export class DocumentationService {

  constructor(private configService: ConfigService) { }

  openDocumentation(pageName: string): void {
    const repository = this.configService.config.documentationRepository === 'default' ? 'assets/doc' : this.configService.config.documentationRepository ;
    const baseUrl = this.configService.config.remoteUrl.toLowerCase().replace('dmc', '');

    const format = this.configService.config.documentationFormat;

    if ( format === 'default') {
      window.open(`${pageName}`)
      return;
    }
    if (repository.toLowerCase().indexOf('http') >=0) {
      window.open(`${repository}/${pageName}.${format}`);
    } else {
      window.open(`${baseUrl}/${repository}/${pageName}.${format}`);
    }
    
  }
}
