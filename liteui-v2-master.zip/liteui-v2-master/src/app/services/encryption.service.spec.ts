import { TestBed } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, SimpleChange, SimpleChanges } from '@angular/core';

import { EncryptionService } from './encryption.service';

describe('EncryptionService', () => {
  let service:EncryptionService;
  let testingData='testing data';
  let testingNumber=1234567890;

  beforeEach(() => {
    TestBed.configureTestingModule({
    imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[]
    });
  service = TestBed.inject(EncryptionService);
});

  it('should be created', () => {
    const service: EncryptionService = TestBed.get(EncryptionService);
    expect(service).toBeTruthy();
  });

  it('hexToASCII method should return correct value',()=>{
      let result=testingData
      .match(/.{1,2}/g)
      .map(v => String.fromCharCode(parseInt(v, 16)))
      .join('');
      expect(service.hexToASCII(testingData)).toBe(result);
  });

  it('hexToBase64 method should return correct value',()=>{
    let result=btoa(
      testingData
          .match(/\w{2}/g)
          .map(a =>
              String.fromCharCode(parseInt(a, 16)))
          .join('')
  );
    expect(service.hexToBase64(testingData)).toBe(result);
});

it('base64IETF method should return correct value',()=>{
  let result;
  result = testingData.replace(/\\n/g, ''); // Remove linebrk
  result = result.split('=')[0]; // Remove any trailing '='s
  result = result.replace(/\+/g, '-'); // 62nd char of encoding
  result = result.replace(/\//g, '_'); // 63rd char of encoding
  expect(service.base64IETF(testingData)).toBe(result);
});





});
