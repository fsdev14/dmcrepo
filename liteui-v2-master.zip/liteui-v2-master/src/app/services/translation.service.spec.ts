import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ConfigService } from './config.service';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { TranslationService } from './translation.service';

class MockConfigService extends ConfigService{
  messageHeader={
    'H_name': '00000ASHUBHAM',
    'H_context': '00001599277986135'
}
  config={
    'remoteUrl': 'https://d4dvwb001.1dc.com/devddmc',
    'loginRequest': '',
    'showSearch': null,
    'menuMessage': {
      'messageName': 'M.WSS.WMXACFS.ATOM.I',
      'messageVersion': 'R00000',
      'getMessageLinks': true
  },
    'searchRequest': '',
    'displayDashboard':null,
    'dashboardTitle': '',
    'loginPageTitle':'',
    'documentTitle':'',
    'defaultDateFormat':'DD/MM/YYYY',
    'enableRSA':true,
    'profileMessage':'',
    'makerChecker':'',
    'appCodes':'',
    'fileSetChange':{},
    'timeOutDuration':14,
    'selectedTheme':null,
    'themeOptions' : [],
    'defaultMask':'',
    'enableMask':true,
    'maskByXref': null,
    'maskXrefRepository':[],
    'maskRepository': [],
    'formChangesLimit':null,
    'languages':[] ,
    'documentationFormat': '',
    'documentationRepository': '',
    'ssoLogin':null
}
}


describe('TranslationService', () => {
  let service: TranslationService;

  beforeEach(() => {
    TestBed.configureTestingModule({
    imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[{
        provide: ConfigService,
        useClass:MockConfigService
    }]
    });
  service = TestBed.inject(TranslationService);
  
  
  
});

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('loadDictionary should return null in case of language ==EN',()=>{
    service.loadDictionary('EN');
    expect(service.dictionary).toEqual({});
  })

  it('getLanguage should return language',()=>{
    expect(service.getLanguage()).toBe(service.language);
  })

  it('setInitialLanguage should set the language and execute correctly',()=>{
    const callCheck=spyOn(service,'loadDictionary')
    service.setInitialLanguage('EN');
    expect(service.language).toBe('EN');
    expect(callCheck).toHaveBeenCalled();
  })

  it('setLanguage should execute correctly',()=>{
    const callCheck=spyOn(service,'setInitialLanguage')
    const callCheck2=spyOn(service,'serviceLanguage')
    service.setLanguage('EN');
    expect(callCheck).toHaveBeenCalled();
    expect(callCheck2).toHaveBeenCalled();
  })
});
