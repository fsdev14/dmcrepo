import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TestBed } from '@angular/core/testing';
import { ConfigService } from './config.service';

import { FormlinkService } from './formlink.service';

describe('FormlinkService', () => {
  let service: FormlinkService;
  let configService: ConfigService;
  beforeEach(() => {
    TestBed.configureTestingModule({providers: [ConfigService], imports: [HttpClientTestingModule, RouterTestingModule]});
    configService = TestBed.inject(ConfigService);
    configService.getConfigData();
    service = TestBed.inject(FormlinkService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
