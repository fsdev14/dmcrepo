/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { mfaService } from './mfa.service';

describe('Service: PingExternal', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [mfaService]
    });
  });

  it('should ...', inject([mfaService], (service: mfaService) => {
    expect(service).toBeTruthy();
  }));
});
