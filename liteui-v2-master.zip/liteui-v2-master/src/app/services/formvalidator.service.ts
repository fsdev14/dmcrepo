import { Injectable } from '@angular/core';
import { map } from 'rxjs';
import { Form, UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Config, ConfigService } from './config.service';
import { MaskingService } from './masking.service';
import { ConversionService } from './conversion.service';
import { DocumentationService } from './documentation.service';

@Injectable({
  providedIn: 'root'
})
export class FormvalidatorService {
  formGroup: Map <string, UntypedFormGroup> = new Map();
  config: Config;
  options: any = {};
  formatCurrency: any;
  latestPageId:any;
  previousFormData: any = {};
 
  constructor(private configService: ConfigService,
              private maskingSerivce: MaskingService,
              private activatedRoute: ActivatedRoute,
              private conversionService: ConversionService,
              private documentationService: DocumentationService) { this.config = this.configService.config; }

  showDocs(page: string) {
    this.documentationService.openDocumentation(page);
  }
  setFormGroup(pageId: string, form: UntypedFormGroup) {
    this.formGroup.set(pageId, form);
  }

  getFormGroup(pageId: string): UntypedFormGroup {
    return this.formGroup.get(pageId);
  }

  setOptions(pageId: any, options: any) {
    this.latestPageId = pageId;
    this.options[pageId] = options;
  }
  getOptions(pageId: any): any {
    return this.options[pageId];
  }
  getLatestPageId(){
    return this.latestPageId;
  }
  clearOption() {
    this.options = {};
  }
  removeOptions(pageId: any){
    delete this.options[pageId];
  }

  setPreviousFormData(_data: any) {
    this.previousFormData = _data;
  }

  getPreviousFormData(): any {
    return this.previousFormData;
  }

   buildFormGroup(pageId: any, fields: any): UntypedFormGroup {
    const fieldGroup = {};
    let val = '';
    for (const field of fields) {
      if (field.type === 'object') {
        Object.values(field.fields).forEach( (f: any) => {

          if (f.schema.format === 'password') {
            val = f.data === ' ' ? null : f.data;
          } else {
            val = f.data;
          }

          fieldGroup[f.name] = new UntypedFormControl({ value: val, disabled: f.readonly });
        });
       } else {

        if (field.schema.format === 'password') {
          val = field.data === ' ' ? null : field.data;
        } 
        if (field.type === 'select') {
          val = field.data === '' ? ' ' : field.data;
        }
        else {
          val = field.data;
        }


        if(field.isChangedField){
          fieldGroup[field.name] = new UntypedFormControl({ value: val, disabled: field.readonly } );
          fieldGroup[field.name].markAsDirty();
        }
        else{
          fieldGroup[field.name] = new UntypedFormControl({ value: val, disabled: field.readonly } );
        }

       }
    }
    this.formGroup.set(pageId,  new UntypedFormGroup(fieldGroup));
    return this.formGroup.get(pageId);
  }


  // addFields(fields: any): FormGroup {
  //   for (const field of fields) {
  //     this.addField(field);
  //   }
  //   return this.formGroup;
  // }

  addField(pageId: string, field: any): void {
    if(field.name == field.changedFieldName){
      this.formGroup.get(pageId).setControl(field.name, new UntypedFormControl({ value: field.data, disabled: field.readonly }));
      this.formGroup.get(pageId).controls[field.name].markAsDirty();
    } else{
      this.formGroup.get(pageId).setControl(field.name, new UntypedFormControl({ value: field.data, disabled: field.readonly }));
    }
    
  }

  getFormDirtyValues(pageId: any): any {
    const response = {};
    const group = this.formGroup.get(pageId);
    const controls = group.controls;
    const messageName = group.get('H_messageName').value;

    const isFunctional = messageName.indexOf('ATOM.I') >= 0 || messageName.indexOf('SVC.I') >= 0;
    if (isFunctional) {
      return this.getAllFormRawValues(this.getOptions(pageId));

    }
    const previousMessage = this.previousFormData.H_messageName;
    if (previousMessage !== messageName) {
      this.previousFormData = {};
    }
    Object.keys(this.previousFormData).forEach(item => {
      if (this.previousFormData[item] !== undefined) {
        response[item] = this.previousFormData[item];
      }
    });
    Object.keys(controls).forEach(item => {
      if (controls[item].dirty) {
        response[item] = controls[item].value;
      }
    });
    return response;
  }


  getAllFormRawValues(content: any): any {
    const response = this.getFormGroup(content.pageId).getRawValue();
    return this.processFormValues(content, response);
  }
  getFormRawValues(content: any): any {

    const response = this.getFormDirtyValues(content.pageId);
    return this.processFormValues(content, response);
  }

  processFormValues(content: any, response: any): any{
    const dirtyKeys = Object.keys(response);
    Object.entries(content.fields).forEach(([key, item]: any) => {
      /* include Header/Hidden fields, Key Fields and Dirty fields but skip ERR fields */

      if (item.name.indexOf('ERR') >= 0) {
        return;
      }
      if (item.type === 'tableMaker' || item.type === 'table') {
        
        Object.entries(item.fields).forEach(([childkey, childitem]: any) => {
          if (childitem.isKeyField || childitem.required) {
            for (let x = 0; x < item.data.length; x++) {
              response[childkey + '_' + (x + 1)] = this.formattedValue(childitem,
                this.formGroup.get(content.pageId).controls[childitem.name + '_' + (x + 1)].value);
            }
          }
          dirtyKeys.filter(x => x.match(childkey)).forEach(child => {
            response[child] = this.formattedValue(childitem, response[child], child);
          });
        });
      }
      if (item.type === 'object') {
        console.log('Processing as object');
        Object.entries(item.fields).forEach(([subkey, subitem]: any) => {
          if (subitem.type === 'table' || subitem.type === 'tableMaker' || subitem.type === 'object') {
            Object.entries(subitem.fields).forEach(([childkey, childitem]: any) => {
              if (childitem.isKeyField || childitem.required) {
                for (let x = 0; x < subitem.data.length; x++) {
                  const name = childkey + '_' + (x + 1);
                  response[name] = this.formattedValue(childitem,
                    this.formGroup.get(content.pageId).controls[childitem.name + '_' + (x + 1)].value, childitem.name + '_' + (x + 1));
                }
              }
              dirtyKeys.filter(x => x.match(childkey)).forEach(child => {
                response[child] = this.formattedValue(childitem, response[child], child);
              });
            });
          } else {
            response[subkey] = this.formattedValue(subitem, this.formGroup.get(content.pageId).controls[subkey].value);
          }
        });
      } else if (key.startsWith('H_') || item.isKeyField
        || key.indexOf('IEFLAG') >= 0 || key.indexOf('OP') >= 0 || item.required) {
        response[key] = this.formattedValue(item, this.formGroup.get(content.pageId).controls[item.name].value);
      } else {
        dirtyKeys.filter(x => x.match(key)).forEach(child => {
          response[child] = this.formattedValue(item, response[child]);
        });
      }
    }
    );

    return response;
  }

  formattedValue(context: any, value: string, name: string = ''): string {
    if (context.type === 'date') {
      if (value === '0000-00-00' || value === '0'
      || value.indexOf(undefined) >= 0
      || value === '00/00/0000'
      || value.trim() === ''
      || value === '0000000' ) { return '00/00/0000'; }

      if (value.indexOf('/') >= 0 ) { return value; }
      const dateValue: any = new Date(value);
      if (dateValue === 'Invalid Date') {
        return '00/00/0000';
      }
      const date = this.pad(String(dateValue.getDate()), 2, '0');
      const month = this.pad(String(dateValue.getMonth() + 1), 2, '0');
      const year = String(dateValue.getFullYear());
      switch (this.config.defaultDateFormat) {
        case 'DD/MM/YYYY':
          return `${date}/${month}/${year}`;
        case 'MM/DD/YYYY':
          return`${month}/${date}/${year}`;
      }
    }
    if (context.type === 'currency') {
      return this.getProcessedCurrencyValue(context, value);
    }
    if (context.mask === undefined || context.mask === '') {
     return this.maskingSerivce.getUnmaskedValue(`${context.name}_${name}`,value);
    }
    return this.maskingSerivce.getUnmaskedValue(name.length ? name : context.name, value);
  }

  pad(n: string, width: number, z: string): string {
    z = z || '0';
    n = n + '';
    return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n;
  }

  getProcessedCurrencyValue(context: any, data: string): string {
    const reg = new RegExp('\\' + context.thousandsSeparator, 'g');
    let decValue = data.replace(context.prefix, '').replace(context.suffix, '')
      .replace(reg, '').replace(context.centsSeparator, '').replace(new RegExp(/\+/g), '').trim();
    let isNegative = '';
    if (decValue.indexOf('-') > -1) {
      isNegative = '-';
      decValue = `${decValue.replace(new RegExp(/\-/g), '')}`;
    }

    decValue = decValue.padStart(context.centsLimit + 1, '0');
    const decValueMinor = decValue.substring(decValue.length - context.centsLimit);
    let decValueMajor: string = decValue.substring(0, decValue.length - context.centsLimit);
    while (decValueMajor.startsWith('0') && decValueMajor !== '0') {
      decValueMajor = decValueMajor.substring(1);
    }
    decValueMajor = decValueMajor.replace(/\B(?=(\d{3})+(?!\d))/g, context.thousandsSeparator);

    if(!context.centsLimit){
      return `${context.prefix}${isNegative}${decValueMajor}${decValueMinor}${context.suffix}`;
    }
    else{
      return `${context.prefix}${isNegative}${decValueMajor}${context.centsSeparator}${decValueMinor}${context.suffix}`;
    }
  }

  formSubmit(content: any, restService: any){
    this.setPreviousFormData(content);
    restService.post(content).subscribe(
        response => {
          let resp: any;

          this.maskingSerivce.unMaskedRepo = {};
          resp = this.conversionService.convert(restService.parse(response));
          let messageName = resp.inputMessageName || resp.messageName;
          const formSuccess = resp.fields?.H_status?.data && (resp.fields?.H_status?.data === 'Y' || resp.fields?.H_status?.data === 'P');
          if (formSuccess) { // reset previous form data if form was successful.
            this.setPreviousFormData({});
          }
          if (messageName === undefined) {
            messageName = this.options[this.latestPageId].messageName;
            this.setOptions(this.latestPageId, {...resp, ...this.options[this.latestPageId]} );
          }          
          restService.navigateToPage(messageName);

        });
  }
}
