import { Injectable } from '@angular/core';
import { publicKey } from 'src/assets/mock/publicKey';
import * as Forge from 'node-forge';

@Injectable({
  providedIn: 'root'
})
export class EncryptionService {
  constructor() {}
  /*
  Store the calculated ciphertext here, so we can decrypt the message later.
  */
  ciphertext: any;
  private publicKey: any;
   EMEApublicKey = publicKey;
  /*
  Fetch the contents of the "message" textbox, and encode it
  in a form we can use for the encrypt operation.
  */
  getMessageEncoding(message: any): Uint8Array {
    const enc = new TextEncoder();
    return enc.encode(message);
  }

  /*
  Get the encoded message, encrypt it and display a representation
  of the ciphertext in the "Ciphertext" element.
  */
  async encryptMessage(message) {
    const encoded = this.getMessageEncoding('message');
    this.ciphertext = await window.crypto.subtle.encrypt(
      {
        name: 'RSA-OAEP'
      },
      this.publicKey,
      this.str2ab(message)
    );
    this.ciphertext = this.ab2hex(this.ciphertext);
  }

  async importKey(key: string) {
    key = this.base64IETF(this.hexToBase64(key));
    this.publicKey = await window.crypto.subtle.importKey(
      'jwk',
      {
        kty: 'RSA',
        e: 'AQAB',
        n: key,
        alg: 'RSA-OAEP',
        ext: true
      },
      {
        name: 'RSA-OAEP',
        hash: { name: 'SHA-1' } // can be "SHA-1", "SHA-256", "SHA-384", or "SHA-512"
      },
      true,
      ['encrypt']
    );
  }


/**
 *  Utility to convert HEX String to ASCII
 */

 hexToASCII(hexstring: string) {
        return hexstring
            .match(/.{1,2}/g)
            .map(v => String.fromCharCode(parseInt(v, 16)))
            .join('');
    }
    /**
     * Utility to convert from Hex to base64 String.
     */

hexToBase64(hexstring: string) {
        return btoa(
            hexstring
                .match(/\w{2}/g)
                .map(a =>
                    String.fromCharCode(parseInt(a, 16)))
                .join('')
        );
    }

    /*
     * Converts a Base64 String to IETF Base64 string.
     */

base64IETF(s: string) {
        s = s.replace(/\\n/g, ''); // Remove linebrk
        s = s.split('=')[0]; // Remove any trailing '='s
        s = s.replace(/\+/g, '-'); // 62nd char of encoding
        s = s.replace(/\//g, '_'); // 63rd char of encoding

        return s;
    }

    /*
    Convert Arraybuffer to String.
    */
ab2str(buf: number) {
        return String.fromCharCode.apply(null, new Uint16Array(buf));
    }

    /* Convert String to ArrayBuffer
     */
str2ab(str: string) {
        const buf = new ArrayBuffer(str.length * 2); // 2 bytes for each char
        const bufView = new Uint16Array(buf);
        for (let i = 0, strLen = str.length; i < strLen; i++) {
            bufView[i] = str.charCodeAt(i);
        }
        return buf;
    }
    /* Convert String to ArrayBuffer
     */
str2ab8(str: string) {
        const buf = new ArrayBuffer(str.length); // 2 bytes for each char
        const bufView = new Uint8Array(buf);
        for (let i = 0, strLen = str.length; i < strLen; i++) {
            bufView[i] = str.charCodeAt(i);
        }
        return buf;
    }

    /*
    Convert ArrayBuffer to HEX String
    */
ab2hex(ab: number) {
        const abx = new Uint8Array(ab);
        let res = '';
        for (const a of abx) {
            res += this.pad(a.toString(16), 2, '0');
        }
        return res;
    }
pad(n: string, width: number, z: string) {
        z = z || '0';
        n = n + '';
        return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n;
    }
	
    encryptWithPublicKey(valueToEncrypt: any): string {
      const rsa = Forge.pki.publicKeyFromPem(this.EMEApublicKey);
  
      const scheme={
        name: 'RSA-OAEP',
        hash:'sha256'
        
      };
        const encryptedBytes = rsa.encrypt(valueToEncrypt.toString(),'RSA-OAEP');
        return window.btoa(encryptedBytes);
  
    }

}
