import { FormvalidatorService } from './formvalidator.service';
import { Injectable } from '@angular/core';
import { RestService } from './rest.service';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RuleConversionService {
  dialogFlag = new Subject<any>();
  getDialogFlag = this.dialogFlag.asObservable();

  dialogMsg = new Subject<any>();
  getDialogMsg = this.dialogMsg.asObservable();
  eventValue:any;
  pageId:any;
  selectedFiled:any;
  amtPctReq:any;
  lastResponse:any;
  resData:any;
  prevFormData:any;
  changeGridPath:any;
  filterDataPath:any;
  customKey:any;
  constructor(
              private restService: RestService,
              private formValidatorService: FormvalidatorService) {
                this.getDialogMsg.subscribe(message => {
                  this.setdialogFlag(false, this.eventValue, this.pageId);
                  if(message === true){
                    this.amtPctConversion(this.eventValue, this.pageId);
                  }
                })
               }

  setdialogFlag(flag, eventValue, pageid) {
    this.eventValue = eventValue;
    this.pageId = pageid;
    return this.dialogFlag.next(flag);
  } 

  setdialogMsg(value){
    return this.dialogMsg.next(value);
  }

  getDialogAction(){
    this.getDialogMsg.subscribe(message => {
      if(message === true){
        this.amtPctConversion(this.eventValue, this.pageId);
      }
      this.setdialogFlag(false, this.eventValue, this.pageId);
    })
  }
 
  amtPctConversion(event, pageId) {
    this.selectedFiled = event.target.name;
    this.amtPctReq = {};
    this.amtPctReq[this.selectedFiled] = event.target.value;
    this.amtPctReq.ruleOnlyValidation = true;
    this.amtPctReq.changedField = this.selectedFiled;
    this.lastResponse = this.restService.getLastResponse();
    let keys = Object.keys(this.lastResponse.options.fields).filter(x => (this.lastResponse.options.fields[x].isKeyField || x.indexOf('H_') > -1));
    keys.forEach(y => {
      this.amtPctReq[y] = this.lastResponse.options.fields[y].data;
    });
    this.restService.post(this.amtPctReq).subscribe(x => {
      this.resData = JSON.parse(x);
      this.prevFormData = {};
      this.prevFormData = this.formValidatorService.getOptions(pageId);

      const allKeys = Object.keys(this.prevFormData.fields);
      this.customKey = allKeys.filter(x => x.startsWith('OF'))[0];

      Object.keys(this.resData.fields).forEach(key => {
        let tableFieldsData = [];
        tableFieldsData.push(key);
        if (this.prevFormData.fields[key]) {
          this.prevFormData = this.getProcessedValue(this.prevFormData, this.resData.fields, this.resData, tableFieldsData);
          this.prevFormData.fields[this.selectedFiled].data = event.target.value;
          this.prevFormData.fields[this.selectedFiled].isChangedField = true;
          this.prevFormData = { ...this.prevFormData };
          this.formValidatorService.setOptions(pageId, this.prevFormData);
        }
        else if (this.customKey) {
          if (this.prevFormData.fields[this.customKey].fields[key]) {
            this.prevFormData.fields[this.customKey] = this.getProcessedValue(this.prevFormData.fields[this.customKey], this.resData.fields, this.resData, tableFieldsData);
            this.prevFormData.fields[this.customKey].fields[this.selectedFiled].data = event.target.value;
            this.prevFormData.fields[this.customKey].fields[this.selectedFiled].isChangedField = true;
            this.prevFormData = { ...this.prevFormData };
            this.formValidatorService.setOptions(pageId, this.prevFormData);
          }
        }
        else if (this.prevFormData.tableGridJsonPaths.length > 0) {
          this.prevFormData.tableGridJsonPaths.forEach(element => {
            this.changeGridPath = element.replaceAll('$.', '').replaceAll('.', '.fields.').split('.');
            this.filterDataPath = this.prevFormData.fields;
            this.changeGridPath.forEach(element => {
              this.filterDataPath = this.filterDataPath[element];
            });
            tableFieldsData = Object.keys(this.filterDataPath.fields).filter(element => element.includes(key));
            if (this.filterDataPath.fields[key] || tableFieldsData?.length > 0) {
              this.filterDataPath = this.getProcessedValue(this.filterDataPath, this.resData.fields, this.resData, tableFieldsData);
              if (this.selectedFiled.split('_')[1]) {
                this.filterDataPath.fields[this.selectedFiled.split('_')[0]].data[this.selectedFiled.split('_')[1] - 1] = event.target.value;
                this.filterDataPath.fields[this.selectedFiled.split('_')[0]].isChangedField = true;
                this.filterDataPath.fields[this.selectedFiled.split('_')[0]].changedFieldName = this.selectedFiled;
              }
              this.prevFormData = { ...this.prevFormData };
              this.formValidatorService.setOptions(pageId, this.prevFormData);
            }
          });
        }
      });
    });
  }

  getProcessedValue(formdata, fields, data, tableFieldsData) {
    if (tableFieldsData.length) {
      tableFieldsData.forEach((element: any, i: any) => {
        const decValue = formdata.fields[element]?.data.replace(formdata.fields[element].prefix, '').replace(formdata.fields[element].suffix, '')
          .replace(new RegExp('\\' + formdata.fields[element].thousandsSeparator, 'g'), '')
          .replace(formdata.fields[element].centsSeparator, '').replace(new RegExp(/\+/g), '');
        if (formdata.fields[element]) {
          formdata.fields[element].data = decValue;
          formdata.fields[element] = { ...formdata.fields[element], ...data.fields[element] };
          formdata.fields[element].isChangedField = true;
        }
        if (element.split('_')[1]) {
          formdata.data[element.split('_')[1] - 1][element.split('_')[0]] = decValue;
          formdata.fields[element] = { ...formdata.fields[element], ...data.fields[element.split('_')[0]] };
          formdata.fields[element].prefix = data.fields[element.split('_')[0]].prefix;
          formdata.fields[element].suffix = data.fields[element.split('_')[0]].suffix;
          formdata.fields[element].name = element;
        }
      })
      tableFieldsData = [];
    }
    return formdata;
  }
}
