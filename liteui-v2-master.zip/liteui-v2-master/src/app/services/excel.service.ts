import { Injectable } from '@angular/core';
import * as XLSX from 'xlsx';

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';

@Injectable()
export class ExcelService {

  constructor() { }
 
  public dataMapping(mapObj: any[], excelFileName: string){
    
    let columns = [];
    mapObj.forEach(index => {
      columns.push(index.name);
    })
   
     const columnsString = columns.map((elem1) => {

      for (let i=0;i<mapObj.length;i++) {
        if (mapObj[i].name == elem1 || mapObj[i].fieldCode == elem1)
        {
          return mapObj[i].label;
        }
      }

    })
    
    let arr = [];
    
    mapObj.forEach(index => {
        arr.push(index.data);    
    })

     const transpose = m => m[0].map((x,i) => m.map(x => x[i]));
     arr = transpose(arr);
     arr.unshift(columnsString);
     this.exportAsExcelFile(arr, excelFileName);
  }


  dataMappingListtable(obj: any[], mapObj: any[], excelFileName: string): void {

   
    const columns = Object.keys(obj[0]);

    const columnsString = columns.map((elem1) => {

      for (let i=0;i<mapObj.length;i++) {
        if (mapObj[i].name == elem1 || mapObj[i].fieldCode == elem1)
        {
          return mapObj[i].label;
        }
      }

    })

    let arr = [];
    arr.push(columnsString);

    for (let i=0;i<obj.length;i++) {

      let temp = Object.values(obj[i]);
      arr.push(temp);
      
    }
  
     this.exportAsExcelFile(arr, excelFileName);
  }

  private exportAsExcelFile(json: any[], excelFileName: string) {
  
    const myworksheet: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(json);
    const myworkbook: XLSX.WorkBook = { Sheets: { 'data': myworksheet }, SheetNames: ['data'] };
    const excelBuffer: any = XLSX.write(myworkbook, { bookType: 'xlsx', type: 'array' });
    this.saveAsExcelFile(excelBuffer, excelFileName);
  }
 
  saveAsExcelFile(buffer: any, fileName: string) {
    const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE
    });
   
    let link = document.createElement('a');
    link.download = fileName;
    link.href = URL.createObjectURL(data);
    link.click();
    URL.revokeObjectURL(link.href);
  }
  public importFromFile(bstr: string): XLSX.AOA2SheetOpts {
    /* read workbook */
    const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

    /* grab first sheet */
    const wsname: string = wb.SheetNames[0];
    const ws: XLSX.WorkSheet = wb.Sheets[wsname];

    /* save data */
    const data = <XLSX.AOA2SheetOpts>(XLSX.utils.sheet_to_json(ws, { header: 1 }));
    return data;
  }
}