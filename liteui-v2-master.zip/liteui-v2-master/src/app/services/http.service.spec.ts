import { HttpClient } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { RestService } from 'src/app/services/rest.service';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, Inject, SimpleChange, SimpleChanges } from '@angular/core';

import { HttpService } from './http.service';

describe('HttpService', () => {
  let service:HttpService
  
  beforeEach(() => {
    TestBed.configureTestingModule({
    imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[]
    });
  service = TestBed.inject(HttpService);
  
});

  it('should be created', () => {
    const service: HttpService = TestBed.inject(HttpService);
    expect(service).toBeTruthy();
  });
});
