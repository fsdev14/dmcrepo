
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ConfigService } from './config.service';
import { RestService } from './rest.service';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RuleConversionService } from './rule-conversion.service';
import { Observable, of, Subject } from 'rxjs';
import {prevFormData,res,res2,prevFormData2} from 'src/assets/mock/ruleConversionMockData';

class MockFormvalidator extends FormvalidatorService{
  
getOptions(pageId: any) {
   
  return prevFormData;
}

}

class MockRestService extends RestService {

  config={
    'remoteUrl': 'https://d4dvwb001.1dc.com/devddmc',
    'loginRequest': '',
    'showSearch': null,
    'menuMessage': {
      'messageName': 'M.WSS.WMXACFS.ATOM.I',
      'messageVersion': 'R00000',
      'getMessageLinks': true
  },
    'searchRequest': '',
    'displayDashboard':null,
    'dashboardTitle': '',
    'loginPageTitle':'',
    'documentTitle':'',
    'defaultDateFormat':'DD/MM/YYYY',
    'enableRSA':true,
    'profileMessage':'',
    'makerChecker':'',
    'appCodes':'',
    'fileSetChange':{},
    'timeOutDuration':14,
    'selectedTheme':null,
    'themeOptions' : [],
    'defaultMask':'',
    'enableMask':true,
    'maskByXref': null,
    'maskXrefRepository':[],
    'maskRepository': [],
    'formChangesLimit':null,
    'languages':[],
    'documentationFormat': '',
    'documentationRepository': '',
    'ssoLogin':null
}
  
  getLastResponse() {
    let data={
      "schema": {
          "type": "object",
          "linkName": "Credit Plans - ARMC/ARQC/ARAC - 11-Commission; Subsidy & Disb Fee",
          "properties": {
              "1001": {
                  "type": "number",
                  "default": 0,
                  "minimum": 0,
                  "maximum": 999,
                  "title": "Primary Commission Amortization Table"
              },
              "1002": {
                  "type": "string",
                  "enum": [
                      "0",
                      "2",
                      "3",
                      "4",
                      "5",
                      "6",
                      "7",
                      "8",
                      "9"
                  ],
                  "title": "Delinquency Trigger Clawback-Primary Commission"
              },
         
      
          }
      },
      "view": {
          "parent": "bootstrap-edit",
          "layout": {
              "template": "./partials/threeColumnLayout.html",
              "bindings": {
                  "1001": "nonkey",
                  "1002": "nonkey",
                
              }
          }
      },
      "tableGridJsonPaths": [],
      "options": {
          "adhocButtonLayer": [
              {
                  "id": "button4",
                  "buttonName": "Reset",
                  "displayAsButton": true,
                  "displayAsLink": false,
                  "targetMessage": {
                      "messageName": "M.CMS.AMCPAS.AS.UP.UPDATE11",
                      "messageVersion": "R00000"
                  }
               
              },
              {
                  "id": "button2",
                  "buttonName": "Query",
                  "displayAsButton": true,
                  "displayAsLink": false,
                  "targetMessage": {
                      "messageName": "M.CMS.AMCPAS.AS.QU.QUERY11",
                      "messageVersion": "R00000"
                  }
          
              }
          ],
          "renderForm": "true",
          "form": {
              "attributes": {
                  "action": "",
                  "method": "post"
              },
              "buttons": {
                  "submit": {
                      "value": "Submit"
                  },
                  "button4": {
                      "value": "Reset"
                  },
                  "button2": {
                      "value": "Query"
                  },
                  "button2001": {
                      "value": "Exit"
                  }
              }
          },
          "tableGridJsonPaths": ["$.object2.table2"],
          "fields": {
              "1001": {
                  "type": "number",
                  "readonly": false,
                  "hidden": false,
                  "label": "Primary Commission Amortization Table",
                  "name": "1001",                  "order": 5,
                  "fieldClass": "col-lg-4 col-md-6 col-xxl-2 col-xxl-2 col-xxl-2",
                  "data": "0",
                  "view": "nonkey",
                  "schema": {
                      "type": "number",
                      "default": 0,
                      "minimum": 0,
                      "maximum": 999,
                      "title": "Primary Commission Amortization Table"
                  }
              },
              "1007": {
                  "type": "select",
                  "readonly": false,
                  "hidden": false,
                  "label": "Delinquency Trigger Clawback-Primary Commission",
                  "name": "1002",
                  "removeDefaultNone": true,
                  "order": 6,
                  "fieldClass": "col-lg-4 col-md-6 col-xxl-2 col-xxl-2 col-xxl-2",
                  "data": "0",
                  "view": "nonkey",
                  "schema": {
                      "type": "string",
                      "enum": [
                          "0",
                          "2",
                          "3",
                          "4",
                          "5",
                          "6",
                          "7",
                          "8",
                          "9"
                      ],
                      "title": "Delinquency Trigger Clawback-Primary Commission"
                  }
              },
              "1003": {
                  "type": "select",
                  "readonly": false,
                  "hidden": false,
                  "label": "Early Settlement To Trigger-Primary Commission",
                  "optionLabels": [
                      "No (0)",
                      "Yes (1)"
                  ],
                  "name": "1003",
                  "removeDefaultNone": true,
                  "order": 7,
                  "fieldClass": "col-lg-4 col-md-6 col-xxl-2 col-xxl-2 col-xxl-2",
                  "data": "0",
                  "view": "nonkey",
                  "schema": {
                      "type": "string",
                      "enum": [
                          "0",
                          "1"
                      ],
                      "title": "Early Settlement To Trigger-Primary Commission"
                  }
              },
             
            
          }
      },
      "data": {
          "1001": "0",
          "1002": "0",
        
          "H_token": "a6fe5e4b65cecb29deb4c4fc7a2d852c2e85496691779735500b6d86af0b821a"
      },
      "links": [
          {
              "linkId": "button1000",
              "linkName": "01-Credit Plan Specification",
              "content": {
                  "4001": "10",
                  "4002": "10001",
                  "messageName": "M.CMS.AMCPAS.AS.UP.UPDATE1",
                  "messageVersion": "R00000"
              },
              "active": false
          },
          {
              "linkId": "button1001",
              "linkName": "02-Repayment Table",
              "content": {
                  "4001": "10",
                  "4002": "10001",
                  "messageName": "M.CMS.AMCPAS.AS.UP.UPDATE2",
                  "messageVersion": "R00000"
              },
              "active": false
          },
        
          {
              "linkId": "button1022",
              "linkName": "Z04-Installment Bill Control",
              "content": {
                  "4001": "10",
                  "4002": "10001",
                  "messageName": "M.CMS.AMCPAS.AS.UP.UPDATE23",
                  "messageVersion": "R00000"
              },
              "active": false
          }
      ]
  }
  
  return data;
  }
   
   
   post(content: any): Observable<any> {                    
                      
  const data=JSON.stringify(res)
  
return of(data)
  }

}


describe('RuleConversionService', () => {
  let service: RuleConversionService;
  let restService:RestService;
  let formvalidator:FormvalidatorService;
  let configService:ConfigService;
  let MockConfigService:ConfigService;
  let mockRestService:MockRestService;
  let mockFormvalidator:MockFormvalidator;

  beforeEach(() => {
    TestBed.configureTestingModule({
    imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[ConfigService,{
        provide: RestService,
        useClass:MockRestService},
    {
        provide:FormvalidatorService,
        useClass:MockFormvalidator
    }]
    });
  service = TestBed.inject(RuleConversionService);
  configService=TestBed.inject(ConfigService)
  formvalidator=TestBed.inject(FormvalidatorService);
  restService=TestBed.inject(RestService)
 // mockRestService=TestBed.inject(MockRestService)
  configService.config={
    'remoteUrl': 'https://d4dvwb001.1dc.com/devddmc',
    'loginRequest': '',
    'showSearch': null,
    'menuMessage': '',
    'searchRequest': '',
    'displayDashboard':null,
    'dashboardTitle': '',
    'loginPageTitle':'',
    'documentTitle':'',
    'defaultDateFormat':'',
    'enableRSA':true,
    'profileMessage':'',
    'makerChecker':'',
    'appCodes':'',
    'selectedTheme':null,
    'themeOptions': [],
    'defaultMask':'',
    'enableMask':false,
    'maskByXref': null,
    'maskXrefRepository':[],
    'maskRepository': [],
    'formChangesLimit':null,
    'languages':[],
    'timeOutDuration': null,
    'fileSetChange': '',
    'documentationFormat': '',
    'documentationRepository': '',
    'ssoLogin':null
  }

  
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  
  it('setdilogflag should be executed properly',()=>{
    let flag=true;
    let event={};
    let pageId=12345;
    service.setdialogFlag(flag,event,pageId);
    expect(service.eventValue).toBe(event);
    expect(service.pageId).toBe(pageId);
  });

  it('getDialogAction should have executed correctly and call amtPctConversion method in case of getDialogueMsg have true value',()=>{
    service.getDialogMsg=of(true);
    const callCheck=spyOn(service,'amtPctConversion');
    service.getDialogAction();
    expect(callCheck).toHaveBeenCalled();
    
  })

  it('getDialogAction should have executed correctly and call setdialogFlag method in case of getDialogueMsg have other than true value',()=>{
    service.getDialogMsg=of(false);
    const callCheck=spyOn(service,'setdialogFlag');
    service.getDialogAction();
    expect(callCheck).toHaveBeenCalled();
  })

  it('amtPctConversion should be executed properly',()=>{
          let mockevent={
            "target":{
              "value":"6789",
              "name":"0202_2"  //1007
            }
          }

          let pageid=84096;

          service.amtPctConversion(mockevent,pageid);
          expect(service.selectedFiled).toBe(mockevent.target.name);
          expect(service.amtPctReq[mockevent.target.name]).toBe(mockevent.target.value);
          expect(service.amtPctReq.ruleOnlyValidation).toBe(true);

  });

  //for if part

  it('amtpctconversion  should execute correctly in case of _fields ',()=>{
    let mockevent={
      "target":{
        "value":"6789",
        "name":"0202_2"  //0203_2
      }
    }
    let pageid=84096;
   
    service.amtPctConversion(mockevent,pageid);
    expect(service.filterDataPath.fields[service.selectedFiled.split('_')[0]].data[service.selectedFiled.split('_')[1]-1]).toBe(mockevent.target.value)
    expect(service.filterDataPath.fields[service.selectedFiled.split('_')[0]].isChangedField).toBe(true)
    expect(service.filterDataPath.fields[service.selectedFiled.split('_')[0]].changedFieldName).toBe(service.selectedFiled);
     

});

  
  //for else part
it('amtpctconversion  should execute correctly in case of fields ',()=>{
    let mockevent={
      "target":{
        "value":"6789",
        "name":1007
      }
    }
    const data2=of(JSON.stringify(res2))
    
    let pageid=84096;
    spyOn(restService,'post').and.returnValue(data2);
    spyOn(formvalidator,'getOptions').and.returnValue(prevFormData2);
    service.amtPctConversion(mockevent,pageid);
    expect(service.prevFormData.fields[service.selectedFiled].isChangedField).toBe(true)
    expect(service.prevFormData.fields[service.selectedFiled].data).toBe(mockevent.target.value)
    expect(service.prevFormData.fields[service.selectedFiled].isChangedField).toBe(true)

});
   

});
