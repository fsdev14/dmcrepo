import { TestBed } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthService } from '../auth/auth.service';
import { ConfigService } from './config.service';
import { HttpService } from './http.service';
import { tap } from 'rxjs/operators';
import { Node } from './node';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, SimpleChange, SimpleChanges } from '@angular/core';

import { FormvalidatorService } from './formvalidator.service';

describe('FormvalidatorService', () => {
  let service: FormvalidatorService;
  let configService:ConfigService;
  let option={
    'adhocButtonLayer':[
        {
            'id': 'button14',
            'buttonName': 'Query',
            'displayAsButton': true,
            'displayAsLink': false,
            'targetMessage': {
                'messageName': 'M.CMS.AMBSAS.AS.QU.QUERY1',
                'messageVersion': 'R00000'
            },
            'keyFieldCodeMapping': [
                {
                    'parentMessageFieldCode': '4601',
                    'targetMessageFieldCode': '4601'
                },
                {
                    'parentMessageFieldCode': '4602',
                    'targetMessageFieldCode': '4602'
                },
                {
                    'parentMessageFieldCode': '4003',
                    'targetMessageFieldCode': '4003'
                },
                {
                    'parentMessageFieldCode': '9904',
                    'targetMessageFieldCode': '9904'
                }
            ],
            'fieldCodeMapping': [],
            'constants': {}
        },
        {
            'id': 'button15',
            'buttonName': 'Update',
            'displayAsButton': true,
            'displayAsLink': false,
            'targetMessage': {
                'messageName': 'M.CMS.AMBSAS.AS.UP.UPDATE1',
                'messageVersion': 'R00000'
            },
            'keyFieldCodeMapping': [
                {
                    'parentMessageFieldCode': '4601',
                    'targetMessageFieldCode': '4601'
                },
                {
                    'parentMessageFieldCode': '4602',
                    'targetMessageFieldCode': '4602'
                },
                {
                    'parentMessageFieldCode': '4003',
                    'targetMessageFieldCode': '4003'
                },
                {
                    'parentMessageFieldCode': '9904',
                    'targetMessageFieldCode': '9904'
                }
            ],
            'fieldCodeMapping': [],
            'constants': {}
        }
    ],
    'fields':{
    '4003':{
        'type': 'number',
        'readonly': false,
        'hidden': false,
        'label': 'Product(Req only for ADD)',
        'name': '4003',
        'isKeyField': true,
        'crossReference': 'CMSLOGO',
        'order': 3,
        'fieldClass': 'col-12',
        'data': '0',
        'schema': {
            'type': 'number',
            'required': true,
            'default': 0,
            'minimum': 0,
            'maximum': 998,
            'title': 'Product(Req only for ADD)'
        }
    }
    },
    
    'form':{
        'attributes': {
            'action': '',
            'method': 'post'
        },
        'buttons': {
            'submit': {
                'value': 'List'
            },
            'button14': {
                'value': 'Query'
            },
            'button15': {
                'value': 'Update'
            },
            'button118': {
                'value': 'Add'
            }
        }
    },
    
    'links': undefined,
    'messageName': 'M.CMS.AMBSAS.AS.GE.GET-LIST',
    'pageName': 'Account Details - ARMB/ARQB/ARAB',
    'renderForm': 'true',
    'table': undefined
    }

    let pageId: '1524795241'

    let context={
        'type': 'date',
        'readonly': false,
        'hidden': false,
        'label': 'Product(Req only for ADD)',
        'name': '4003',
        'isKeyField': true,
        'crossReference': 'CMSLOGO',
        'order': 3,
        'fieldClass': 'col-12',
        'data': '0',
        'schema': {
            'type': 'date',
            'required': true,
            'default': 0,
            'minimum': 0,
            'maximum': 998,
            'title': 'Product(Req only for ADD)'
        }
    }
let name= ''
let value= '0'
  beforeEach(() => {
    TestBed.configureTestingModule({
    imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[ConfigService]
    });
  service = TestBed.inject(FormvalidatorService);
  service.config={
    'remoteUrl': '',
    'loginRequest': '',
    'showSearch': null,
    'menuMessage': '',
    'searchRequest': '',
    'displayDashboard':null,
    'dashboardTitle': '',
    'loginPageTitle':'',
    'documentTitle':'',
    'defaultDateFormat':'DD/MM/YYYY',
    'enableRSA':true,
    'profileMessage':'',
    'makerChecker':'',
    'appCodes':'',
    'selectedTheme':null,
    'themeOptions': [],
    'defaultMask':'',
    'enableMask':true,
    'maskByXref': null,
    'maskXrefRepository':[],
    'maskRepository': [],
    'formChangesLimit':null,
    'languages':[],
    'timeOutDuration': null,
    'fileSetChange': '',
    'documentationFormat': '',
    'documentationRepository': '',
    'ssoLogin':null
  }

  
});

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('setOptions should execute properly and give latestpageId and option correct values',()=>{
    service.setOptions(pageId,option);
    
    expect(service.options[pageId]).toBe(option)
  })

  it('getOption should return correct data',()=>{
    service.options[pageId]=option;
    expect(service.getOptions(pageId)).toEqual(service.options[pageId]);
  })

  it('clear option should execute properly',()=>{
    service.clearOption();
    expect(service.options).toEqual({});
  })
  it('formattedValue should return correct data in case of context.type=data',()=>{
      let value2='0000-00-00';
      expect(service.formattedValue(context,value2,name)).toBe('00/00/0000')
  })

  it('formattedValue should return correct data in case of value=00/00/0000',()=>{
    let value2='00/00/0000';
    expect(service.formattedValue(context,value2,name)).toBe('00/00/0000')
})

it('should call getProcessedCurrencyValue in case of context.type=currency',()=>{
    const newContext = { ...context, ...{'type':'currency'} };
    const checkCall=spyOn(service,'getProcessedCurrencyValue');
    service.formattedValue(newContext,value,name);
    expect(checkCall).toHaveBeenCalled();
})

it('should call getProcessedCurrencyValue in case of context.type=currency',()=>{
    const newContext = { ...context, ...{'type':'numer'} };
    expect(service.formattedValue(newContext,value,name)).toBe(value);
})
});
