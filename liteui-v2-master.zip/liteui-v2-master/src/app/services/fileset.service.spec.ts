import { TestBed } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { RestService } from 'src/app/services/rest.service';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, Inject, SimpleChange, SimpleChanges } from '@angular/core';
import { of } from 'rxjs';
import { ConfigService } from './config.service';

import { FilesetService } from './fileset.service';


class MockRestService extends RestService {

  getFileSet(): string {
      return '';
  }
}

describe('FilesetService', () => {
  let service: FilesetService;
  let mockRestService:MockRestService
  let restService:RestService
  let configService:ConfigService;
  let testData='testdata'
  

  beforeEach(() => {
    TestBed.configureTestingModule({
    imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[RestService,ConfigService,{
        provide: RestService,
        useClass:MockRestService
    },]
    });
  service = TestBed.inject(FilesetService);
  restService=TestBed.inject(RestService)
  configService=TestBed.inject(ConfigService)
  
  
});

beforeEach(() => {
  //mockRestService=TestBed.inject(MockRestService)
});

  it('should be created', () => {
    expect(service).toBeTruthy();
  }); 

  it('getFileSetValue should set correct value to fileset',()=>{
    let result=`FS${testData}`;
    spyOn(restService, 'getFileSet').and.returnValue(testData);
    service.getfileSetValue();
    expect(service.fileSet).toEqual(result);
  })

  it('getFileSetlist should return correct filesetlist',()=>{
    expect(service.getFileSetList()).toEqual([]);
  })

  it('getFileSetValue should set correct value to fileset if getFileSetValue from Restservice return empty string',()=>{
    service.getfileSetValue();
    expect(service.fileSet).toEqual('');
  })
  
});
