import { Injectable } from '@angular/core';
import { ConfigService } from './config.service';

@Injectable({
  providedIn: 'root'
})
export class MaskingService {

  constructor(private configService: ConfigService) { }
  unMaskedRepo = {};

  isMaskable(field: any, message: string): string {
    let maskable = '';

    if (this.configService.config.maskByXref) { return this.isXrefMaskable(field); }

    this.configService.config.maskRepository.forEach(x => {
      if (message.match(x.messageName)) {
        x.maskFields.forEach(m => {
          if (field.name.match(m.name)) {
            maskable = m.mask ? m.mask : this.configService.config.defaultMask;
          }
        });
      }
    });

    return maskable;
  }
  isXrefMaskable(field: any): string {
    let maskable = '';
    this.configService.config.maskXrefRepository.forEach(x => {
      if (field?.crossReference && field?.crossReference.match(x.xref)) {
        maskable = x.mask ? x.mask : this.configService.config.defaultMask;
      }
    });
    return maskable;
  }
  getMaskedValue(field: string, fallback: string): string {
    return this.unMaskedRepo[field]?.data || fallback;

  }
  getUnmaskedValue(field: string, fallback: string): string {
    return this.unMaskedRepo[field]?.maskedData || fallback;

  }

  applyMask(fieldValue: string, maskString: string): string {
    let maskedValue = '';
    if (fieldValue.trim().length === 0) { return fieldValue; }
    const masklength = fieldValue.trim().length < maskString.length ? fieldValue.trim().length : maskString.length;
    for (let i = 0; i < masklength; i++) {
      const c = maskString[i];
      if (c === '9') {
        maskedValue += fieldValue[i];
      } else {
        maskedValue += c;
      }
    }
    return maskedValue;
  }

  resetMaskingRepo(): void {
    this.unMaskedRepo = {};
  }
}
