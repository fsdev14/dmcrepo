import { TestBed } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ConfigService } from './config.service';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, SimpleChange, SimpleChanges } from '@angular/core';

import { MaskingService } from './masking.service';

class MockConfigService extends ConfigService{
  config={
    'remoteUrl': '',
    'loginRequest': '',
    'showSearch': null,
    'menuMessage': '',
    'searchRequest': '',
    'displayDashboard':null,
    'dashboardTitle': '',
    'loginPageTitle':'',
    'documentTitle':'',
    'defaultDateFormat':'DD/MM/YYYY',
    'enableRSA':true,
    'profileMessage':'',
    'makerChecker':'',
    'appCodes':'',
    'selectedTheme':null,
    'themeOptions': [],
    'defaultMask':'',
    'enableMask':true,
    'maskByXref': true,
    'maskXrefRepository':[],
    'maskRepository': [],
    'formChangesLimit':null,
    'languages':[],
    'timeOutDuration': null,
    'fileSetChange': '',
    'documentationFormat': '',
    'documentationRepository': '',
    'ssoLogin':null
  }

}

describe('MaskingService', () => {
  let service: MaskingService;
  let configService:ConfigService
  

  beforeEach(() => {
    TestBed.configureTestingModule({
    imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[{
        provide: ConfigService,
        useClass:MockConfigService
      }]
    });
  service = TestBed.inject(MaskingService);
  configService=TestBed.inject(ConfigService)
  service.unMaskedRepo={
    '4006': {
      'maskedData':'999XXXX999',
      'data':'9991234999'
  }
  }
 
});

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call isXrefMaskable in case of maskByXref have true value',()=>{
    const callCheck=spyOn(service,'isXrefMaskable');
    service.isMaskable('4006','testing');
    expect(callCheck).toHaveBeenCalled();
  })

  it('getmaskedValue should return correct data in case of no data in unmaskedrepo for the givenField',()=>{
    expect(service.getMaskedValue('4007','testingdata')).toBe('testingdata')
  })

  it('getmaskedValue should return correct data in case of  data in unmaskedrepo for the givenField',()=>{
    expect(service.getMaskedValue('4006','testingdata')).toBe('9991234999')
  })

  it('getUnmaskedValue should return correct data in case of no data in unmaskedrepo for the givenField',()=>{
    expect(service.getMaskedValue('4007','testingdata')).toBe('testingdata')
  })

  it('getUnmaskedValue should return correct data in case of  data in unmaskedrepo for the givenField',()=>{
    expect(service.getUnmaskedValue('4006','testingdata')).toBe('999XXXX999')
  })

  it('applymask should return correct value in case of empty fieldvalue data',()=>{
    expect(service.applyMask('','123456')).toBe('');
  })

  it('resetmaskingrepo should reset unMaskedRepo',()=>{
    service.resetMaskingRepo();
    expect(service.unMaskedRepo).toEqual({});
  })

  
});
