import { Injectable } from '@angular/core';
import { ConfigService } from './config.service';

@Injectable({
  providedIn: 'root'
})
export class mfaService {


  constructor(private configService: ConfigService) {

  }

  ciamBaseUrl = this.configService.config.ciamBaseUrl;
  userName: string;
  registrationUri: string;
  authId: string;
  deviceStatus: string;
  token: string;

  async generateToken(): Promise<any> {

    let svcAccount = this.configService.config.svcForMFA.svcAccount;
    let svcPassword = this.configService.config.svcForMFA.svcInfo;
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

    var urlencoded = new URLSearchParams();
    urlencoded.append("grant_type", "client_credentials");
    urlencoded.append("client_id", svcAccount);
    urlencoded.append("client_secret", svcPassword);

    var requestOptions = {
      method: 'POST',
      headers: myHeaders,
      body: urlencoded
    };

    let response = await fetch(this.ciamBaseUrl + "/ciam-mfa/v2/get/token", requestOptions);
    let tokenReponse = response.json();
    tokenReponse.then(result => {
      this.token = result.access_token;
    });

    return tokenReponse;
  }

  async createMFADevice(user: string): Promise<any> {
    let region = this.configService.config.remoteUrl.split('/')[3];
    this.userName = "LITEUI" + region.toUpperCase() + user;

    await this.generateToken();

    let myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    myHeaders.append("Authorization", "Bearer " + this.token);

    let raw = JSON.stringify({
      "deviceType": "TOTP",
      "devicename": "iphone5"
    });

    let requestOptions = {
      method: 'POST',
      headers: myHeaders,
      body: raw
    };

    let apiResponse = await fetch(this.ciamBaseUrl + "/ciam-mfa/v2/users/" + this.userName + "/mfadevices", requestOptions)
    let res = apiResponse.json();
    res.then(result => {
      if (result.registrationUri) {
        this.authId = result.authId;
      } 
    });
    return res;
  }

  async activateMFADevice(otp: number): Promise<any> {
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    myHeaders.append("Authorization", "Bearer " + this.token);

    var raw = JSON.stringify({
      "deviceType": "TOTP",
      "otp": otp
    });

    var requestOptions = {
      method: 'POST',
      headers: myHeaders,
      body: raw
    };

    let activateDeviceResponse = await fetch(this.ciamBaseUrl + "/ciam-mfa/v2/users/" + this.userName + "/mfadevices/" + this.authId, requestOptions);
    let deviceRes = activateDeviceResponse.json();
    return deviceRes;
  }

  async requestOTP(): Promise<any> {
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    myHeaders.append("Authorization", "Bearer " + this.token);

    var raw = JSON.stringify({
      "userName": this.userName,
      "deviceName": "iphone5",
      "deviceType": "TOTP"
    });

    var requestOptions = {
      method: 'POST',
      headers: myHeaders,
      body: raw
    };

    let response = await fetch(this.ciamBaseUrl + "/ciam-mfa/v2/deviceAuthentications", requestOptions);
    let requestOTPReponse = response.json();
    requestOTPReponse.then(result => {
      this.authId = result.authId;
    });
    return requestOTPReponse;
  }

  async verifyUser(otp: number): Promise<any> {
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    myHeaders.append("Authorization", "Bearer " + this.token);

    var raw = JSON.stringify({
      "deviceType": "TOTP",
      "otp": otp
    });

    var requestOptions = {
      method: 'POST',
      headers: myHeaders,
      body: raw
    };

    let response = await fetch(this.ciamBaseUrl + "/ciam-mfa/v2/deviceAuthentications/" + this.authId, requestOptions);
    let authenticateUserResponse = response.json();
    return authenticateUserResponse;
  }
}
