import { Router } from '@angular/router';
import { ConversionService } from './conversion.service';
import { RestService } from 'src/app/services/rest.service';
import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { Injectable } from '@angular/core';
import { Subject, lastValueFrom, BehaviorSubject, Observable} from 'rxjs';
import { DisabilityDescription } from '../disabilityDescription';

@Injectable({
  providedIn: 'root'
})
export class FormlinkService {
  linkType:any;
  shareData = new Subject<any>();
  existQuery:any;
  updateQuery:any;
  existApi:any;
  updateApi:any;
  apiMergeData = [];
  private vulnTriggered: BehaviorSubject<boolean>;
  disabilityDesc = new DisabilityDescription();
  selectedGroup : any[];

  constructor(
    private formValidatorService: FormvalidatorService,
    private restService: RestService,
    private conversionService : ConversionService,
    private router : Router
    ) {
      this.vulnTriggered = new BehaviorSubject<boolean>(false);
  }

  gotoPageNext(item: any, type: string){
    if (type === undefined ) {
      this.formValidatorService.clearOption();
      this.restService.gotoPage(item);
    } else {
      this.linkType = {};
      this.linkType.type = type;
      this.shareData.next(this.linkType);
      this.existQuery =  item.content;
      this.existQuery.messageMode = 'QUEUE-RECORD';
      this.updateQuery =  item.content;
      this.updateQuery.messageMode = 'UPDATE';
      this.linkQuery();
    }

  }

  async linkQuery() {
    const data1 = await lastValueFrom( this.restService.post(this.existQuery));
    this.existApi = this.conversionService.convert(this.restService.parse(data1));
    const data2 = await lastValueFrom(this.restService.post( this.updateQuery));
    this.apiMergeData = [];
    this.existApi.type = 'existData';
    this.apiMergeData.push(this.existApi);
    this.updateApi = this.conversionService.convert(this.restService.parse(data2));
    this.updateApi.type = 'updateData';
    this.apiMergeData.push(this.updateApi);
    this.shareData.next(this.apiMergeData);
  }

  openVulnPopup(dropdownValue: any, dropdownLabel: any) {
      var groupNames = new Array ();
      var lastResponse = this.restService.getLastResponse();
      const fieldLabel = lastResponse.schema.properties;
        groupNames.push(fieldLabel.object2?.properties['5023_1']?.title,
                      fieldLabel.object3?.properties['5033_1']?.title,
                      fieldLabel.object4?.properties['5043_1']?.title,
                      fieldLabel.object5?.properties['5053_1']?.title,
                      fieldLabel.object6?.properties['5063_1']?.title,
                      fieldLabel.object2?.properties['5023_2']?.title,
                      fieldLabel.object3?.properties['5033_2']?.title,
                      fieldLabel.object4?.properties['5043_2']?.title,
                      fieldLabel.object5?.properties['5053_2']?.title,
                      fieldLabel.object6?.properties['5063_2']?.title,


                      fieldLabel.object7?.properties['5023_1']?.title,
                      fieldLabel.object8?.properties['5033_1']?.title,
                      fieldLabel.object9?.properties['5043_1']?.title,
                      fieldLabel.object10?.properties['5053_1']?.title,
                      fieldLabel.object11?.properties['5063_1']?.title,
                      fieldLabel.object19?.properties['5023_2']?.title,
                      fieldLabel.object20?.properties['5033_2']?.title,
                      fieldLabel.object21?.properties['5043_2']?.title,
                      fieldLabel.object22?.properties['5053_2']?.title,
                      fieldLabel.object23?.properties['5063_2']?.title


                      );

      if (groupNames.includes(dropdownLabel)) {
        this.selectedGroup = this.disabilityDesc[dropdownValue];
        this.displayVulnPopup();
      }
  }

  displayVulnPopup() {
    this.vulnTriggered.next(true);
  }

  getSelectedGroup() {
    return this.selectedGroup;
  }

  clearVulnPopup() {
    this.vulnTriggered.next(false);
  }

  isVulnTriggered(): Observable<boolean> {
    return this.vulnTriggered.asObservable();
  }
}
