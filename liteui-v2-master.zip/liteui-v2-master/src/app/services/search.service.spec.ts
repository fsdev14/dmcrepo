import { TestBed } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthService } from '../auth/auth.service';
import { ConfigService } from './config.service';
import { RestService } from './rest.service';
import { HttpService } from './http.service';
import { tap } from 'rxjs/operators';
import { Node } from './node';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, SimpleChange, SimpleChanges } from '@angular/core';

import { SearchService } from './search.service';

describe('SearchService', () => {
  let service: SearchService;
  let restService:RestService;
  let configService:ConfigService;

  beforeEach(() => {
    TestBed.configureTestingModule({
    imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[RestService,ConfigService]
    });
  service = TestBed.inject(SearchService);
  
  
  
});

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('setfieldname method should executed properly',()=>{
    service.setFieldName('test');
    expect(service.fieldName).toEqual('test');
  })
});
