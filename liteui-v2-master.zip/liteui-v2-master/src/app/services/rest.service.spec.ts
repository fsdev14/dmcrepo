import { TestBed } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthService } from '../auth/auth.service';
import { ConfigService } from './config.service';
import { HttpService } from './http.service';
import { tap } from 'rxjs/operators';
import { Node } from './node';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, SimpleChange, SimpleChanges } from '@angular/core';

import { RestService } from './rest.service';
class MockConfigService extends ConfigService{
  messageHeader={
    'H_name': '00000ASHUBHAM',
    'H_context': '00001599277986135'
}
  config={
    'remoteUrl': 'https://d4dvwb001.1dc.com/devddmc',
    'loginRequest': '',
    'showSearch': null,
    'menuMessage': {
      'messageName': 'M.WSS.WMXACFS.ATOM.I',
      'messageVersion': 'R00000',
      'getMessageLinks': true
  },
    'searchRequest': '',
    'displayDashboard':null,
    'dashboardTitle': '',
    'loginPageTitle':'',
    'documentTitle':'',
    'defaultDateFormat':'DD/MM/YYYY',
    'enableRSA':true,
    'profileMessage':'',
    'makerChecker':'',
    'appCodes':'',
    'fileSetChange':{},
    'timeOutDuration':14,
    'selectedTheme':null,
    'themeOptions' : [],
    'defaultMask':'',
    'enableMask':true,
    'maskByXref': null,
    'maskXrefRepository':[],
    'maskRepository': [],
    'formChangesLimit':null,
    'languages':[],
    'documentationFormat': '',
    'documentationRepository': '',
    'ssoLogin':null
}
}

describe('RestService', () => {
  let service: RestService;

  beforeEach(() => {
    TestBed.configureTestingModule({
    imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[{
        provide: ConfigService,
        useClass:MockConfigService
    }]
    });
  service = TestBed.inject(RestService);
  
  
  
});

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('getLastResponse should return correct value',()=>{
    expect(service.getLastResponse()).toBe(service['lastResponse']);
  })

  it('getLastRequest should return correct value',()=>{
    expect(service.getLastRequest()).toBe(service['lastRequest']);
  })

  it('resetTableView should change the lastResponse.table',()=>{
    service.resetTableView();
    expect(service['lastResponse'].table).toBe(false);
  })

  it('gotoPage should call goTomenu method',()=>{
    let item={
      'groupName':'data'
    }
    const callCheck=spyOn(service,'gotoMenu');
    service.gotoPage(item);
    expect(callCheck).toHaveBeenCalled();
  })


  it('gotoPage should call goTomenu method',()=>{
    let item={
      'linkName':'test',
      'groupName':'data'
    }
    service.gotoPage(item);
    expect(service['lastRequest']).toBe(item);
  })
});
