import { Injectable } from '@angular/core';
import { ConfigService } from './config.service';
import { RestService } from './rest.service';

@Injectable({
  providedIn: 'root'
})
export class SearchService {
  fieldName = '';
 constructor(private restService: RestService, private configService: ConfigService) { }

  search(searchTerm: string) {
    const msg = this.configService.getConfig().searchRequest;
    msg.searchTerm = searchTerm;
    return this.restService.post(msg);
  }
  setFieldName(fieldName: string): void {
    this.fieldName = fieldName;
  }
}
