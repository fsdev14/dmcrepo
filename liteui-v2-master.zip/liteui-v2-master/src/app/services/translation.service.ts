import { Injectable } from '@angular/core';
import { ConfigService } from './config.service';
import { ErrorHandlingService } from './errorHandling.service';
import { HttpService } from './http.service';
import { RestService } from './rest.service';
import { Router,  Route} from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class TranslationService {

  constructor(private configService: ConfigService,
              private httpService: HttpService,
              private restService: RestService,
			  private router: Router,
              private errorHandlingService: ErrorHandlingService) { }

  language = 'EN';
  dictionary = {};

  loadDictionary(language: string): void {
	this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.router.onSameUrlNavigation = 'reload';
      if (language === 'EN') {
        this.dictionary = {};
		this.router.navigate([this.router.url], { 'skipLocationChange': false });
        return;
      }
      const languageDetails = this.configService.config.languages.find(x => x.code === language);
      if (languageDetails) {
      this.getFile(`assets/lang/${languageDetails.fileName}`).subscribe (
        data => {
          if (data) {
            this.dictionary = JSON.parse(data);
          } else {
            this.dictionary = {};
          }
		  this.router.navigate([this.router.url], {'skipLocationChange': false} );
        }
      );
      }
  }
  getFile(file: any): any {
    return this.httpService.get(file);

  }
  getLanguage(): string {
    return this.language;
  }
  setInitialLanguage(language: string) {
    this.language = language;
    this.loadDictionary(language);
  }

  setLanguage(language: string): void {
    this.setInitialLanguage(language);
    this.serviceLanguage();
  }

  serviceLanguage() {
    const profileMessage = this.configService.config.profileMessage;
    profileMessage['4001'] = this.configService.messageHeader.H_name.substring(0, 5);
    profileMessage['4002'] = this.configService.messageHeader.H_name.substring(5);
    profileMessage['4007'] = this.language;
    this.restService.post(profileMessage).subscribe(x => {
      try {
        const idx = x.lastIndexOf(',"postRender"');
        if (idx >= 0) {
          x = x.substring(0, idx) + '}';
        }
        const xRes = JSON.parse(x);
        if (xRes.schema && (xRes.schema.properties.ERR1.title?.indexOf('0027SF') > -1 || xRes.schema.properties.ERR1.title?.indexOf('0001EF') > -1 || xRes.schema.properties.ERR1.title?.indexOf('0001SF') > -1)) {
          this.restService.loginStateValid = false;
        }
        this.restService.fileSet = xRes.data?.H_fileSet || '';
        this.restService.token = xRes.data?.H_token || xRes.H_token || '';
      } catch (error) {
        console.log('Profile Service Failed to update. Retry?');
        this.errorHandlingService.errorHandler(error.stack,'UIERR0011');
      }
    });
  }

  translate(text: string): string {
    const result = this.dictionary[text?.trim()];
    return result === undefined ? text : result;
  }
}
