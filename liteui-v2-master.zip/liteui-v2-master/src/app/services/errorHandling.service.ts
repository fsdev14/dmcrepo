import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { ErrorCodes } from '../error-codes';

@Injectable({
  providedIn: 'root'
})
export class ErrorHandlingService {

  private errorTriggered: BehaviorSubject<boolean>;
  private errorCodes = new ErrorCodes();

constructor() { 
  this.errorTriggered = new BehaviorSubject<boolean>(false);
}

errors: any;
message: String;

errorHandler(errors: any, code: any) {
  this.errors = errors;
  this.message = this.errorCodes.errorArray[code];
  this.displayError();
}

getErrorsDetails() {
  return this.errors;
}

getMessage() {
  return this.message;
}

displayError() {
  this.errorTriggered.next(true);
}

clearPopup() {
  this.errorTriggered.next(false);
}

isErrorTriggered(): Observable<boolean> {
  return this.errorTriggered.asObservable();
} 

}
