import { Injectable } from '@angular/core';
import { ConfigService } from './config.service';
import { MaskingService } from './masking.service';

@Injectable({
  providedIn: 'root'
})
export class ConversionService {
  schemaMap: any = {};
  messageName = '';
  dependencyField = [];
  constructor(private maskingService: MaskingService, private configService: ConfigService) { }

  public convert(request: any): any {
    this.messageName = request.data?.inputMessageName || request.data?.H_messageName;
    this.flattenSchema(request.schema);
    this.dependencyField = [];
    const returnObject = this.buildObjectFromOptions(request.options, request.data, this.schemaMap,  request.view);
    returnObject.links = request.links;
    returnObject.pageName = request.schema.linkName;
    returnObject.messageName = this.messageName;
    returnObject.table = request.table;
    //console.log(returnObject);
    return returnObject;
  }

  private flattenSchema(schema: any) {
    for (const item of Object.keys(schema)) {
      if (item === 'properties') {
        this.flattenSchema(schema[item]);
      } else {
        if (schema[item].properties !== undefined) {
          this.flattenSchema(schema[item].properties);
        }
        if (schema[item].items?.properties !== undefined) {
          this.flattenSchema(schema[item].items.properties);
        }

        this.schemaMap[item] = schema[item];
      }
    }
  }

  private buildObjectFromOptions(options: any, _data: any, _schemaMap: any, _view: any): any {
    const data: any = {};

    if (options.type === 'table'  && (this.messageName.includes('SMMSAS.AS.QU') || 
    this.messageName.includes('SMMSAS.AS.UP') || this.messageName.includes('SMMSAS.AS.AD'))) {
      options.type='tableMaker'
      options.data.forEach( (d, i) => {
        Object.keys(d).forEach( key => {
          const mask = this.maskingService.isMaskable(options.fields[key], this.messageName);
          if (mask !== '') {
            const newval  = this.maskingService.applyMask(d[key], mask);
            this.maskingService.unMaskedRepo[`${key}_${i + 1}`] = {maskedData: d[key], data: newval};
            d[key] = newval;
            options.fields[d][i] = newval;
          }

        });

      });

    }
    else if(options.type === 'table' && this.messageName.includes('SCXRQFS')){
      options.type='table'
      options.data.forEach( (d, i) => {
        Object.keys(d).forEach( key => {
          const mask = this.maskingService.isMaskable(options.fields[key], this.messageName);
          if (mask !== '') {
            const newval  = this.maskingService.applyMask(d[key], mask);
            this.maskingService.unMaskedRepo[`${key}_${i + 1}`] = {maskedData: d[key], data: newval};
            d[key] = newval;
            options.fields[d][i] = newval;
          }
  
        });
  
      });
     }
   else
     if (options.type === 'table' && this.configService.getConfig().enableMask) {
      options.data.forEach( (d, i) => {
        Object.keys(d).forEach( key => {
          const mask = this.maskingService.isMaskable(options.fields[key], this.messageName);
          if (mask !== ''){
          // we are calling convserionService.convert multiple times. 
          // check to see if the value is already in the masking repository
            if ( this.maskingService.unMaskedRepo[`${key}_${i + 1}`]?.data === d[key]) { } else {
              const newval  = this.maskingService.applyMask(d[key], mask);
              this.maskingService.unMaskedRepo[`${key}_${i + 1}`] = {maskedData: d[key], data: newval};
              d[key] = newval;
              if (!options.fields[key].data) {
                options.fields[key].data = [];
              }
              options.fields[key].data[i] = newval;
            }
            
          }

        });

      });

    }
    for (const option of Object.keys(options)) {

      if (option === 'fields') {
        if (typeof data.fields === 'undefined') {
          data.fields = {};
        }

        const children = this.buildObjectFromOptions(options[option], _data, _schemaMap, _view);
        for (const child of Object.keys(children)) {

          data.fields[child] = children[child];
          if (data.fields[child].name === undefined || child.indexOf('_') > 0) {
            data.fields[child].name = child;
          }

          if(children[child].dependencies){
            const fields = children[child].dependencies.fields;
            fields.forEach((element) => {
              if(children[child].name.indexOf('_') > 0){
                this.dependencyField.push(element.fieldCode + '_' + children[child].name.split('_')[1]);
              }
              else{
                this.dependencyField.push(element.fieldCode);
              }
            });
          }

          if (data.fields[child].type === 'object') {
            data.fields[child].fieldClass = 'col-12';

          }

          if (data.fields[child].fieldClass === undefined) {
            data.fields[child].fieldClass = '';
          }

          if (data.fields[child].fieldClass === '') {
            data.fields[child].fieldClass = 'col-12';
          }
          if (data.fields[child].fieldClass.indexOf('col-lg-4') >= 0) {
            data.fields[child].fieldClass = data.fields[child].fieldClass + ' col-xxl-2';
          }
          if (data.fields[child].fieldClass.indexOf('col-lg-8') >= 0) {
            data.fields[child].fieldClass = data.fields[child].fieldClass + ' col-xxl-4';
          }
          if (data.fields[child].hidden) {
            data.fields[child].fieldClass = 'd-none';
          }
          if (child.indexOf('ERR') >= 0 || child.indexOf('H_statusMessage') >= 0) {
            data.fields[child].type = 'label';
            data.fields[child].fieldClass = '';
            data.fields[child].label = _schemaMap[child].title;
          } else {
            data.fields[child].data = _data === undefined ? null : _data[child];
            if (data.fields[child].data === undefined && _data[0] !== undefined) {
              // this likely an array
              data.fields[child].data = [];
              let index = 1;
              _data.forEach(x => {
                //handle masking for text fields  
                
                if (data.fields[child].type === 'text' && this.configService.getConfig().enableMask) {
                  data.fields[child].mask = this.maskingService.isMaskable(data.fields[child], this.messageName);
                  data.fields[child].data.push (this.setMask(data.fields, child, x[child], index));
                } else {
                  data.fields[child].data.push(x[child]);
                  
                }
                index = index + 1;
              });
            } else
            //handle masking for text fields
            if (data.fields[child].type === 'text' && this.configService.getConfig().enableMask) {
              data.fields[child].mask = this.maskingService.isMaskable(data.fields[child], this.messageName);
              data.fields[child].data = (this.setMask(data.fields, child, data.fields[child].data));
            } 

          }
          data.fields[child].view = _view?.layout?.bindings[child];
          data.fields[child].schema = _schemaMap[child];

          if (data.fields[child].type === undefined) {
            if (data.fields[child].schema.format === 'uppercase') {
              data.fields[child].type = 'text';
            }
            if (data.fields[child].schema.type === 'string') {
              data.fields[child].type = 'text';
            }
          }

          if (data.fields[child].type === 'uppercase') {
            data.fields[child].type = 'text';
            data.fields[child].schema.type = 'uppercase';
          } 
          const xRef = data.fields[child].crossReference;

          if (xRef !== undefined) {
            const globalXref = this.configService.globalCrossReferenceRepo[xRef];
            if (globalXref !== undefined && globalXref !== '00000' && globalXref !== null) {
              data.fields[child].data = globalXref;
              data.fields[child].readonly = true;
            }
          }

          if(data.fields[child] && data.fields[child].schema?.enum !== undefined){
            if (_schemaMap[child].enum !== undefined && data.fields[child].optionLabels === undefined) {
              data.fields[child].optionLabels = _schemaMap[child].enum;
            }
          }
          if (children[child].fields !== undefined) {
            data.fields[child] = {
              ...data.fields[child],
              ...this.buildObjectFromOptions(data.fields[child], data.fields[child].data, _schemaMap, {})
            };
          }
          

        }

      }
      data[option] = options[option];
    }
    return data;
  }


  setMask(dataField, child: string, childData: string, index?: number) {

    let maskedData = childData;


      if (dataField[child].mask !== '') {
        const localdata = maskedData;
        if (localdata !== undefined && typeof localdata === 'string') {
           maskedData = this.maskingService.applyMask(localdata, dataField[child].mask);
          if (maskedData.trim().length > 0) {
            if (index!== undefined) {
              if (this.maskingService.unMaskedRepo[`${child}_${index}`].data !== childData)
                this.maskingService.unMaskedRepo[`${child}_${index}`] = { maskedData: localdata, data: maskedData };
            } else 
            this.maskingService.unMaskedRepo[child] = { maskedData: localdata, data: maskedData };
          }
          return maskedData;
        }

      }
    return maskedData;
    }
  
  


}
