import { FormvalidatorService } from 'src/app/services/formvalidator.service';
import { HttpService } from './http.service';
import { Config, ConfigService } from './config.service';
import { Injectable } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { BehaviorSubject, Observable } from 'rxjs';
import { ErrorHandlingService } from './errorHandling.service';
import { mfaService } from './mfa.service';


@Injectable({
  providedIn: 'root'
})
export class RestService {

  config: Config;
  profileMessage: any;
  themeCode: any;
  savTheme: any;
  errors = [];
  fileSet = '';
  token = '';
  lastResponse: any = {};
  private lastRequest: any = {};
  loginStateValid = false;
  postRenderObj: any = {};
  postRenderBtn = {};
  emailSubmitted = false;
  user: any;
  registrationUri: any;
  externalUserFlag = false;
  externalUserVerified = new BehaviorSubject<boolean>(false);
  authenticationModal = new BehaviorSubject<boolean>(false);
  displayOTPSection = false;
  loadHomePage = false;

  constructor(
    private configService: ConfigService,
    private httpService: HttpService,
    private router: Router,
    private formValidatorService: FormvalidatorService,
    private errorHandlingService: ErrorHandlingService,
    private mfaService: mfaService
  ) {
    this.config = configService.getConfig();
  }

  post(content: any): Observable<any> {
    // TODO:  validate session, if not valid, route to login page;
    const newContent = { ...content, ...this.configService.messageHeader, ...{ H_token: this.token } };
    return this.httpService.post(this.config.remoteUrl, newContent);
  }

  parse(resp: string): any {
    this.postRenderObj = resp;
    const idx = resp?.lastIndexOf(',"postRender"');
    if (idx >= 0) {
      resp = resp.substring(0, idx) + '}';
    }

    // postrender button code for custom JS
    const postIdx = this.postRenderObj?.lastIndexOf('postRender":');
    const parseRes = JSON.parse(resp);
    if (postIdx >= 0 && parseRes.options.adhocButtonLayer === undefined) {
      this.postRenderObj = this.postRenderObj.substring(postIdx, this.postRenderObj.length);
      let myArray = this.postRenderObj.split("renderedForm.form");
      this.postRenderBtn = {};
      myArray.forEach((element, index) => {
        if (index != 0) {
          const val = element.split("getButtonEl('")[1]?.split("')")[1].split('val("')[1].split('")')[0];
          if (val) {
            this.postRenderBtn[element.split("getButtonEl('")[1]?.split("')")[0]] = Object.assign({}, ...val.split('|')
              .map(s => s.split('='))
              .map(([k, v]) => ({ [k]: v })));
          }
        }
      });
    }

    try {
      this.lastResponse = JSON.parse(resp);

      if (this.configService.config.enableMFA) {
        if (this.user?.substring(0, 5) != '00000' && this.user != undefined && this.user != "" && this.lastResponse.data?.H_status == 'P' && this.externalUserFlag == false) {
          this.externalUser();
        } else if (this.user?.substring(0, 5) == '00000' && this.externalUserVerified.value == false) {
          this.loadHomePage = true;
          this.externalUserVerified.next(true);                                 //to be changed for internal user authentication
        }
      } else {
        this.loadHomePage = true;
        this.externalUserVerified.next(true);
      }

      const res = JSON.parse(resp);
      if (res.schema && (res.schema.properties.ERR1.title?.indexOf('0027SF') > -1 || res.schema.properties.ERR1.title?.indexOf('0001EF') > -1 || res.schema.properties.ERR1.title?.indexOf('0001SF') > -1)) {
        this.loginStateValid = false;
        return res;
      }
      this.fileSet = this.lastResponse.data?.H_fileSet || this.fileSet ;
      this.token = this.lastResponse.data?.H_token || this.lastResponse.H_token || this.token;
      return this.lastResponse;
    } catch (error) {
      console.log(error);
      this.errorHandlingService.errorHandler(error.stack,'UIERR0010');
      return {};
    }
  }

  getLastResponse(): any {
    return this.lastResponse;
  }
  getLastRequest(): any {
    return this.lastRequest;
  }
  gotoLastRequestedPage() {
    this.gotoPage(this.lastRequest);
  }
  resetTableView(): any {
    this.lastResponse = { ...this.lastResponse, table: false };
  }
  gotoPage(item: any) {
    this.errors = [];
    if (typeof item.linkName !== 'undefined' || item.groupName === '') {
      this.lastRequest = item;
      this.post(item.content).subscribe(
        response => {

          this.parse(response);
          const err = this.lastResponse.schema.properties.ERR1.title;
          if (err.indexOf('0027') > 0 || err.indexOf('0001') > 0) {
            this.loginStateValid = false;
          }
          if (this.lastResponse.data === undefined) {
            this.errors.push(this.lastResponse);
          }

        },
        error => {
          this.errors.push(error);
        },
        () => {
          this.formValidatorService.clearOption();
          this.router.navigate(['/home/page', item.content.messageName]);
        }
      );
    } else {
      this.gotoMenu(item);
    }
  }

  navigateToPage(messageName) {
    this.router.onSameUrlNavigation = 'reload'
    this.router.navigate(['/home/page', messageName]);
  }

  gotoMenu(item: any) {
    this.router.navigate([`home/menu/${item.content.messageName || item.groupName}`]);
    this.formValidatorService.clearOption();
  }

  getFileSet(): string {
    return this.fileSet;
  }

  qrDialog() {
    return this.authenticationModal.asObservable();
  }

  externalUserVerify() {
    return this.externalUserVerified.asObservable();
  }

  async externalUser() {
    this.externalUserFlag = true;
    let res = await this.mfaService.createMFADevice(this.user);
    if (res.registrationUri && this.authenticationModal.value == false) {
      this.registrationUri = res.registrationUri;
      this.authenticationModal.next(true);
    } else {
      this.authenticationModal.next(true);
      this.displayOTPSection = true;
      await this.mfaService.requestOTP();
    }
  }
}
