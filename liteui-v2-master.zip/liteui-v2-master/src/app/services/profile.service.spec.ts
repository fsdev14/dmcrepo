import { TestBed } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { RestService } from 'src/app/services/rest.service';
import { AuthService } from '../auth/auth.service';
import { ConfigService } from './config.service';
import { NodemapService } from './nodemap.service';
import { TranslationService } from './translation.service';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, Inject, SimpleChange, SimpleChanges } from '@angular/core';

import { ProfileService } from './profile.service';

class MockConfigService extends ConfigService{
  messageHeader={
    'H_name': '00000ASHUBHAM',
    'H_context': '00001599277986135'
}
  config={
    'remoteUrl': 'https://d4dvwb001.1dc.com/devddmc',
    'loginRequest': '',
    'showSearch': null,
    'menuMessage': {},
    'searchRequest': '',
    'displayDashboard':null,
    'dashboardTitle': '',
    'loginPageTitle':'',
    'documentTitle':'',
    'defaultDateFormat':'DD/MM/YYYY',
    'enableRSA':true,
    'profileMessage':{
      'H_messageName': 'M.WSS.WMLPAS.AS.UP.UPDATE1',
      'H_messageVersion': 'R00000',
      'H_language': 'EN'
  },
    'makerChecker':'',
    'appCodes':'',
    'fileSetChange':{},
    'timeOutDuration':14,
    'selectedTheme':null,
    'themeOptions' : [],
    'defaultMask':'',
    'enableMask':true,
    'maskByXref': null,
    'maskXrefRepository':[],
    'maskRepository': [],
    'formChangesLimit':null,
    'languages':[],
    'documentationFormat': '',
    'documentationRepository': '',
    'ssoLogin':null
}
}

describe('ProfileService', () => {
  let service: ProfileService;
  let configService:ConfigService;

  beforeEach(() => {
    TestBed.configureTestingModule({
    imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[{
        provide: ConfigService,
        useClass:MockConfigService
    }]
    });
  service = TestBed.inject(ProfileService);
  configService=TestBed.inject(ConfigService)
  service.config={
    'remoteUrl': 'https://d4dvwb001.1dc.com/devddmc',
    'loginRequest': '',
    'showSearch': null,
    'menuMessage': {},
    'searchRequest': '',
    'displayDashboard':null,
    'dashboardTitle': '',
    'loginPageTitle':'',
    'documentTitle':'',
    'defaultDateFormat':'DD/MM/YYYY',
    'enableRSA':true,
    'profileMessage':{
      'H_messageName': 'M.WSS.WMLPAS.AS.UP.UPDATE1',
      'H_messageVersion': 'R00000',
      'H_language': 'EN'
  },
    'makerChecker':'',
    'appCodes':'',
    'fileSetChange':{},
    'timeOutDuration':14,
    'selectedTheme':null,
    'themeOptions' : [],
    'defaultMask':'',
    'enableMask':true,
    'maskByXref': null,
    'maskXrefRepository':[],
    'maskRepository': [],
    'formChangesLimit':null,
    'languages':[]
}
  
  
  
});

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
