import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ErrorHandlingService } from 'src/app/services/errorHandling.service';

@Component({
  selector: 'app-error-dialog',
  templateUrl: './error-dialog.component.html',
  styleUrls: ['./error-dialog.component.css']
})
export class ErrorDialogComponent implements OnInit {

  constructor(private router: Router,
              private errorHandlingService: ErrorHandlingService,
    ) { }

  errors: any;
  message : String; 
  show = false;

  ngOnInit() {
    this.errors = this.errorHandlingService.getErrorsDetails();
    this.message = this.errorHandlingService.getMessage();
  }

  goToHomePage() {
    this.router.navigate(['/home']);
  }

  closeErrorPopup() {
    this.errorHandlingService.clearPopup();
  }	

  toggle() {
    this.show = !this.show;
  }

}
