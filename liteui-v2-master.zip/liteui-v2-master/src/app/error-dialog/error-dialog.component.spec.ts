import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';

import { ErrorDialogComponent } from './error-dialog.component';

describe('ErrorDialogComponent', () => {
  let component: ErrorDialogComponent;
  let fixture: ComponentFixture<ErrorDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ErrorDialogComponent ],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([]),],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ErrorDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call toggle() on click openToggle',()=>{
    const openToggle=fixture.debugElement.query(By.css('#openToggle'))
    const callCheck=spyOn(component,'toggle');
    openToggle.triggerEventHandler(null,'click');
    expect(callCheck).toHaveBeenCalled();
  });

  it('should call goToHomePage() and closeErrorPopup() on click closeModal',()=>{
    const closeModal=fixture.debugElement.query(By.css('#closeModal'))
    const callCheck1=spyOn(component,'goToHomePage');
    const callCheck2=spyOn(component,'closeErrorPopup');
    closeModal.triggerEventHandler(null,'click');
    expect(callCheck1).toHaveBeenCalled();
    expect(callCheck2).toHaveBeenCalled();
  })
});
