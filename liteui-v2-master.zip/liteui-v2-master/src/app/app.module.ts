import { AuthGuard } from './auth/auth.guard';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { IsLoadingModule } from '@service-work/is-loading';
import { ReactiveFormsModule } from '@angular/forms'; 
import { NgxQRCodeModule } from '@techiediaries/ngx-qrcode';

import { AppComponent } from './app.component';
import { AuthModule } from './auth/auth.module';
import { SecretResetComponent } from './auth/secret-reset/secret-reset.component';
import { ConfigService } from './services/config.service';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AppRoutingModule } from './app-routing.module';
import { HomeModule } from './home/home.module';
import { CommonModule, CurrencyPipe, DecimalPipe} from '@angular/common';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { ErrorComponent } from './error/error.component';
import { HelpComponent } from './help/help.component';
import { TranslatePipe } from './translate.pipe';
import { TablePagePipe } from './table-page.pipe';
import { HttpCalIInterceptor } from './http.interceptor';
import { ExcelService } from './services/excel.service';
import { ErrorDialogComponent } from './error-dialog/error-dialog.component';
import { VulnerabilityDialogComponent } from './vulnerability-dialog/vulnerability-dialog.component';
import { confirmDialogComponent } from './confirm-dialog/confirm-dialog.component';
import { qrGeneratorComponent } from './qr-generator/qr-generator.component';
@NgModule({
  declarations: [AppComponent, PageNotFoundComponent, ErrorComponent, HelpComponent, ErrorDialogComponent, confirmDialogComponent, qrGeneratorComponent, VulnerabilityDialogComponent],

  imports: [
    AppRoutingModule,
    BrowserModule,
    BrowserAnimationsModule,
    CommonModule,
    IsLoadingModule,
    FormsModule,
    HttpClientModule,
    HomeModule,
    AuthModule,
    ReactiveFormsModule,
    NgxQRCodeModule
  ],
  providers: [ConfigService, CurrencyPipe, DecimalPipe, TranslatePipe, ExcelService, TablePagePipe, AuthGuard,

    {
      provide: APP_INITIALIZER,
      multi: true,
      deps: [ConfigService],
      useFactory: (configService: ConfigService) => {
        return () => {
          return configService.getConfigData();
        };
      }
    }, 
    {
      provide: LocationStrategy,
      useClass: HashLocationStrategy
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpCalIInterceptor,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
