import { RuleConversionService } from './../services/rule-conversion.service';
import { Component, OnInit} from '@angular/core';


@Component({
  selector: 'app-confirm-dialog',
  templateUrl: './confirm-dialog.component.html',
  styleUrls: ['./confirm-dialog.component.scss']
})
export class confirmDialogComponent implements OnInit {

  constructor( private ruleConversionService: RuleConversionService ) {
   
   }

  ngOnInit() {
   
  }

  public notifyDialog(action) {
    if(action === 'ok'){
      this.ruleConversionService.setdialogMsg(true);
    } else{
      this.ruleConversionService.setdialogMsg(false);
    }
    
  }

}
