import { RuleConversionService } from './../services/rule-conversion.service';
import { CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { confirmDialogComponent } from './confirm-dialog.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ConfigService } from 'src/app/services/config.service';
import { HttpClient } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { By } from '@angular/platform-browser';

class MockCRuleConversionService extends RuleConversionService{
  setdialogMsg(value: any): void {
    
  }
}

describe('confirmDialogComponent', () => {
  let component: confirmDialogComponent;
  let fixture: ComponentFixture<confirmDialogComponent>;
  let ruleConversionService: RuleConversionService;
  let configService:ConfigService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ confirmDialogComponent ],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([])],
       providers:[RuleConversionService,ConfigService, {
        provide: RuleConversionService,
        useClass:MockCRuleConversionService
    },],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(confirmDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    ruleConversionService=TestBed.inject(RuleConversionService)
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should execute notifyDilogue method', () => {
    fixture.detectChanges;
    let action='ok';
    const callCheck=spyOn(ruleConversionService,'setdialogMsg');
    component.notifyDialog(action);
    expect(callCheck).toHaveBeenCalled();

   //expect(component).toBeTruthy();
  });

  it('notifyDilog method should be called on "OK click',()=>{
    let link=fixture.debugElement.query(By.css('#confirmDialog'))
    const checkCall=spyOn(component,'notifyDialog');
    link.triggerEventHandler('click',null);
    expect(checkCall).toHaveBeenCalled();
  })

  it('notifyDilog method should be called on "cancel click',()=>{
    let link=fixture.debugElement.query(By.css('#cancelDialog'))
    const checkCall=spyOn(component,'notifyDialog');
    link.triggerEventHandler('click',null);
    expect(checkCall).toHaveBeenCalled();
  })
});


