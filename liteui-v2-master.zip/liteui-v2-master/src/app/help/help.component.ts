import { switchMap } from 'rxjs/operators';
import { AfterContentChecked, AfterContentInit,HostListener, AfterViewChecked, Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { HttpService } from '../services/http.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.css']
})
export class HelpComponent implements OnInit, AfterViewChecked{
  sections: any;
  data: any;
  selectedName: any;
  scroll=0;
  
  constructor(private route: ActivatedRoute,
              private httpService: HttpService) { }
			  
			  @HostListener("wheel", ["$event"])
              public onScroll(event: WheelEvent) {
                this.scroll++;
              }
  ngAfterViewChecked(): void {
    console.log('content checked');
	 if(this.scroll>0){
      this.selectedName=" ";
    }
    const elt = document.getElementById(this.selectedName);
    if (elt) {
      elt.scrollIntoView();
    }
  }

  ngOnInit(): void {
    const message = this.route.snapshot.paramMap.get('message');
    this.selectedName = this.route.snapshot.paramMap.get('name');
    const helpfile = 'assets/help/' + message.split('.')[2] + '.json';

    this.get(helpfile).subscribe(
       data => {
         data = data.replaceAll("\t", " ");
         this.setData(JSON.parse(data));
         
       }
    );
  }

  gotoSection(section) {
    const elt = document.getElementById(section);
    if (elt) {
      elt.scrollIntoView();
    }
  }

  get(file: any): any {
    return this.httpService.get(file);

  }
  setData(data: any) {
    this.data = data.data;
    this.sections = data.sections;

  }
  getData(): any {
    if (this.data) {
      return Object.keys(this.data);
    }
    return [];
  }


  getSections(): any {
    if ( this.data) {
      return Object.keys(this.sections);
    }
    return [];
  }
}
