import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, SimpleChange, SimpleChanges } from '@angular/core';
import { TranslatePipe } from 'src/app/translate.pipe';
import { ActivatedRoute, convertToParamMap } from '@angular/router';

import { HelpComponent } from './help.component';
import { By } from '@angular/platform-browser';

describe('HelpComponent', () => {
  let component: HelpComponent;
  let fixture: ComponentFixture<HelpComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ HelpComponent ,TranslatePipe],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes([]),],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[
        {
          provide: ActivatedRoute,
          useValue: {snapshot: {paramMap:convertToParamMap({'message': 'abc'})}},
        }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HelpComponent);
    component = fixture.componentInstance;
    let data={'data':{
      'section0':[
      ],'section1':[
      {
      'fieldCode':'4001',
      'fieldName':'BUSINESS UNIT',
      'fieldFormat':'3N',
      'helpText':'Business Unit number to which the category is assigned.'
      }
      ,{
      'fieldCode':'4002',
      'fieldName':'CATEGORY TABLE',
      'fieldFormat':'8N',
      'helpText':'Identification number of the category that CMS uses to locate the directory.'
      }
      ,{
      'fieldCode':'4003',
      'fieldName':'PRODUCT',
      'fieldFormat':'3N',
      'helpText':'Product number to which the category is assigned.'
      }
      ,{
      'fieldCode':'4004',
      'fieldName':'PROCESSING CONTROL TABLE',
      'fieldFormat':'3N',
      'helpText':'Processing Control Table (PCT) to which the category is assigned.'
      }
      ,{
      'fieldCode':'4005',
      'fieldName':'CARD HOLDER AFFILIATION',
      'fieldFormat':'5N',
      'helpText':'Cardholder affiliation or affinity group assigned to the category.'
      }
      ,{
      'fieldCode':'0110',
      'fieldName':'SEQUENTIAL FIELD NUMBER',
      'fieldFormat':'4N',
      'helpText':'Field Number assigned to the category.'
      }
      ]},'sections': {
      'section0':''
      ,
      'section1':'ARM0/ARQ0-Data Management Communication Control Table'
      }}
      component.setData(data);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('getData should return correct value in case data have values',()=>{
    expect(component.getData()).toEqual(Object.keys(component.data))
  })

  it('getdata should return empty array in case of no data',()=>{
    let data2=[];
    component.setData(data2);
    expect(component.getData()).toEqual([])
  })

  it('getsection should return correct value in case of data have values',()=>{
    expect(component.getSections()).toEqual(Object.keys(component.sections))
  })

  it('getsection should return empty array in case of no data',()=>{
    let data2=[];
    component.setData(data2);
    expect(component.getSections()).toEqual([])
  })

  it('should have correct section name',()=>{
    let sections=fixture.debugElement.queryAll(By.css('#sections'));
    expect(sections.length).toBe(component.getSections().length);
    component.getSections().forEach((item,index)=>{
      expect(sections[index].nativeElement.innerHTML).toBe(component.sections[component.getSections()[index]])
    })
  })

  it('section title name should call gotoSection method on click',()=>{
    let sections=fixture.debugElement.query(By.css('#sections'));
    const callCheck= spyOn(component,'gotoSection');
    sections.triggerEventHandler(null,'click');
    expect(callCheck).toHaveBeenCalled();
  })

  it('should have correct fieldName heading name',()=>{
    let fieldName=fixture.debugElement.queryAll(By.css('#fieldname'));
    for(let j=0;j<component.data.length;j++){
      for(let i=0;i<component.data[j].length;i++){
        expect(fieldName[i].nativeElement.innerHTML).toBe(component.data[j][i].fieldName)
       }
    }
  })


  it('should have correct field code name',()=>{
    let fieldCode=fixture.debugElement.queryAll(By.css('#fieldCode'));
    for(let j=0;j<component.data.length;j++){
      for(let i=0;i<component.data[j].length;i++){
        expect(fieldCode[i].nativeElement.innerHTML).toBe(component.data[j][i].fieldCode)
       }
    }
  })

  it('should have correct field format  name',()=>{
    let format=fixture.debugElement.queryAll(By.css('#format'));
    for(let j=0;j<component.data.length;j++){
      for(let i=0;i<component.data[j].length;i++){
        expect(format[i].nativeElement.innerHTML).toBe(component.data[j][i].fieldFormat)
       }
    }
  })

  it('innerhtml text should be formed',()=>{
    let innertext=fixture.debugElement.query(By.css('#innerText'));
    expect(innertext).toBeTruthy()
  })
  
});
