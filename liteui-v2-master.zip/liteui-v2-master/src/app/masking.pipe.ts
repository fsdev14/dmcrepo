import { Pipe, PipeTransform } from '@angular/core';
import { Config, Maskables, ConfigService } from './services/config.service';
import { MaskingService } from './services/masking.service';
import { RestService } from './services/rest.service';

@Pipe({
  name: 'masking',
  pure: true
})
export class MaskingPipe implements PipeTransform {
  config: Config;
  constructor(private configService: ConfigService,
              private restService: RestService,
              private maskingService: MaskingService) {
    this.config = configService.config;
  }

  transform(value: string, field: any): string {
    if (!this.config.enableMask ) { return value; }


    if ( typeof field === 'object') {
      const mask = this.maskingService.isXrefMaskable(field);
      if ( mask === '') {
        return value;
      }
      return this.maskingService.applyMask(value, mask);
    }
    /** the below code is for field based masking to be obsolete */
    const lastResponse = this.restService.getLastResponse();
    const messageName = lastResponse.data.H_messageName;
    const name =  field;

    let defaultMask = this.config.defaultMask;
    for (const item of this.config.maskRepository) {
      if (messageName.match(item.messageName)) {
        for (const m of item.maskFields) {
          if (m.name === name) {
            if (m.mask !== undefined && m.mask !== '') {
              defaultMask = m.mask;
            }
            return this.maskingService.applyMask(value, defaultMask);
          }
        }
      }
    }

    return value;
  }



}
