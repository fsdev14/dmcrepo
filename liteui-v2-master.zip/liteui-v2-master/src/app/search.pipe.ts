import { Pipe, PipeTransform } from '@angular/core';


@Pipe({
  name: 'tableDataFilter'
})
export class SearchPipe implements PipeTransform {

  transform(tableRows: any, searchParam: string, currentPage?: number, totalPages?: number, tableData?: any): any {
    if (!searchParam) { return tableRows; }
    // return JSON.stringify(item).toLowerCase().includes(args);
    return tableRows.filter(tableRow => {
        if (tableRow === null) { // getData from tableData;
        } return tableRow.containsString(searchParam.toLocaleLowerCase());
      });
  }
}
