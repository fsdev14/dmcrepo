/* eslint-disable quotes */
export class DisabilityDescription {
    1 : string[] = [                                                               //health
        "Physical disability",
        "Severe or long-term illness",
        "Hearing or visual impairment",
        "Mental health condition or disability",
        "Addiction",
        "Low mental capacity or cognitive disability"
    ];

    2 : string[] = [                                                               //lifeEvents
        "Retirement",
        "Bereavement",
        "Income Shock",
        "Relationship Breakdown",
        "Domestic abuse (including economic control)",
        "Caring responsibilities",
        "Other circumstances"
    ];

    3 : string[] = [                                                                //resilience
        "Inadequate (outgoings exceed income) or erratic income",
        "Over- indebtedness",
        "Low savings",
        "Low emotional resilience",
    ];

    4 : string[] = [                                                                //capability
        "Low knowledge or confidence in managing finances",
        "Poor literacy or numeracy skills",
        "Poor English language skills",
        "Poor or non-existent digital skills",
        "Learning difficulties",
        "No or low access to help or support"
    ];

    ' ' : string[] = [                                                              //No option selected
        "Please Select Correct Option"
    ]
}
