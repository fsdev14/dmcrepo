import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { IsLoadingService } from '@service-work/is-loading';
import { Observable } from 'rxjs/internal/Observable';
import { Router, NavigationStart, NavigationEnd, NavigationCancel, NavigationError } from '@angular/router';
import { filter, tap} from 'rxjs/operators';
import { Config, ConfigService } from './services/config.service';
import { ProfileService } from 'src/app/services/profile.service';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, SimpleChange, SimpleChanges } from '@angular/core';
import { TranslatePipe } from 'src/app/translate.pipe';
import { Node } from 'src/app/services/node';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; 
import { BrowserModule, By } from '@angular/platform-browser';

describe('AppComponent', () => {
  let component:AppComponent;
  let fixture: ComponentFixture<AppComponent>
  let configService:ConfigService;
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AppComponent],
      imports: [ HttpClientTestingModule,BrowserModule, BrowserAnimationsModule, RouterTestingModule.withRoutes([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA,ConfigService],
      providers:[ConfigService]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the app', () => {
   // const fixture = TestBed.createComponent(AppComponent);
    //const app = fixture.debugElement.componentInstance;
    expect(component).toBeTruthy();
  });

  it('should have as title \'liteui-v2\'', () => {
    expect(component.title).toEqual('liteui-v2');
  });

  it('should not open error dialog component when errorOcurred is false', () => {
    component.errorOccured = false;
    let errorDialog=fixture.debugElement.query(By.css('#errorDialog'));
    expect(errorDialog).not.toBeTruthy();
  });

  it('should open error dialog component when errorOcurred is true', () => {
    component.errorOccured = true;
    fixture.detectChanges();
    let errorDialog=fixture.debugElement.query(By.css('#errorDialog'));
    expect(errorDialog).toBeTruthy();
  });
  
  it('should not open confirm dialog component when errorOcurred is false', () => {
    component.confirmDialog = false;
    let confirmDialog=fixture.debugElement.query(By.css('#confirmDialog'));
    expect(confirmDialog).not.toBeTruthy();
  });

  it('should open confirm dialog component when errorOcurred is true', () => {
    component.confirmDialog = true;
    fixture.detectChanges();
    let confirmDialog=fixture.debugElement.query(By.css('#confirmDialog'));
    expect(confirmDialog).toBeTruthy();
  });

});
