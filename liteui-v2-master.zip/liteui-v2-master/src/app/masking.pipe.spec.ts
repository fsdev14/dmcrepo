
import { ConfigService } from './services/config.service';
import { TestBed } from '@angular/core/testing';
import { RestService } from './services/rest.service';
import { MaskingPipe } from 'src/app/masking.pipe';
import {MaskingService} from './services/masking.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
describe('MaskingPipe', () => {
  //let pipe: MaskingPipe;
  let configService: ConfigService;
  let restService: RestService;
  let maskingService:MaskingService;

  beforeEach(() => { 
    TestBed.configureTestingModule({ providers: [RestService, ConfigService, MaskingService], imports: [HttpClientTestingModule, RouterTestingModule] });
    restService = TestBed.inject(RestService);
    configService = TestBed.inject(ConfigService);
    configService.getConfigData();
    maskingService = TestBed.inject(MaskingService);
  } )


  it('should create a maskingPipe instance', () => {

    const pipe = new MaskingPipe(configService, restService, maskingService);
    expect(pipe).toBeTruthy();
  });

  it('should mask maskables', () => {});
});