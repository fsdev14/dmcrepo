import { RuleConversionService } from './services/rule-conversion.service';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { IsLoadingService } from '@service-work/is-loading';
import { Observable } from 'rxjs/internal/Observable';
import { Router, NavigationStart, NavigationEnd, NavigationCancel, NavigationError } from '@angular/router';
import { filter, tap} from 'rxjs/operators';
import { Config, ConfigService } from './services/config.service';
import { ErrorHandlingService } from './services/errorHandling.service';
import { FormlinkService } from './services/formlink.service';
import { RestService } from './services/rest.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'liteui-v2';
  isLoading: Observable<boolean>;
  config: Config;
  errorOccured = false;
  vulnPopup  = false;
  confirmDialog = false;
  authenticationModal = false;

  constructor(
    private isLoadingService: IsLoadingService,
    private router: Router,
    private configService: ConfigService,
    private errorHandlingService: ErrorHandlingService,
    private formlinkService: FormlinkService,
    private ruleConversionService: RuleConversionService,
    private restService: RestService
    
  ) {
    router.events.forEach((event) => {
      if(event instanceof NavigationStart) {
        if (event.navigationTrigger === 'popstate') {
          alert("Back browser button has been disabled due to security purpose.");
          this.router.navigate([this.router.url]); 
        }
      }
    });
  }
  ngOnInit() {

    this.errorHandlingService.isErrorTriggered().subscribe(resp => {
      this.errorOccured = resp;
    });

    this.formlinkService.isVulnTriggered().subscribe(response => {
      this.vulnPopup = response;
    });

    this.ruleConversionService.getDialogFlag.subscribe(message => { 
      this.confirmDialog = message;
     });

    this.restService.qrDialog().subscribe(res => {
      this.authenticationModal = res;
    }); 
     
     
    this.isLoading = this.isLoadingService.isLoading$();
    this.router.events
      .pipe(
        filter(
          event =>
            event instanceof NavigationStart ||
            event instanceof NavigationEnd ||
            event instanceof NavigationCancel ||
            event instanceof NavigationError
        )
      )
      .subscribe(event => {
        // If it's the start of navigation, `add()` a loading indicator
        if (event instanceof NavigationStart) {
          this.isLoadingService.add();
          return;
        }

        // Else navigation has ended, so `remove()` a loading indicator
        this.isLoadingService.remove();
      });

  }

}
