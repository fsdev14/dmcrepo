import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable, ReplaySubject, Subject, repeatWhen,timer} from 'rxjs';
import { takeUntil,map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { Config, ConfigService } from './services/config.service';

@Injectable()
export class HttpCalIInterceptor implements HttpInterceptor {
    destroy = new Subject();
    time= 0;
    observable$: Observable<any>;
    timeDuration: number;
    stopCounter: boolean = false;
    public worker: any;
    constructor( private router: Router, private configService: ConfigService) {
          
    }
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
      this.timeDuration = this.configService.config?.timeOutDuration * 60;
      this.luiSessionTimeout();
      return next.handle(request);
    }
   

    luiSessionTimeout() {      
      if (typeof Worker !== 'undefined') {
        this.time = this.time+1;
        if (this.worker == null){
          this.worker = new Worker(new URL('./timer.worker', import.meta.url));
        }
        if(this.time> 1){
          this.worker.postMessage('resetTimer:'+ this.timeDuration);
        }        
          this.worker.onmessage = ({ data }) => {
            if (data === this.timeDuration && !this.stopCounter) {              
              this.worker.terminate();
              this.stopCounter = true;
              this.worker = null;
              this.router.navigate(['/login']);            
            } else {     
            }
          }; 
      }
    }
}