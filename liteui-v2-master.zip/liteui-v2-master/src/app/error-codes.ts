export class ErrorCodes {
    errorArray: { [errorCode: string]: string } = {
        UIERR0001: 'There is an error in authentication.',
        UIERR0002: 'There is an error while loging in.',
        UIERR0003: 'There is an error in form-container.',
        UIERR0004: 'Error occurred navigating through Table button. Please check with developer.',
        UIERR0005: 'There is an error in table-control-maker.',
        UIERR0006: 'Fileset load failed. Feature will be turned off.',
        UIERR0007: 'Error Loading Favourites Data. Feature will be turned off.',
        UIERR0008: 'Error checking isFavourite.',
        UIERR0009: 'Profile Service Failed to update. Retry?',
        UIERR0010: 'There is an error in rest-service. Please check with developer.',
        UIERR0011: 'Profile Service Failed to update. Retry?'
    }
}
