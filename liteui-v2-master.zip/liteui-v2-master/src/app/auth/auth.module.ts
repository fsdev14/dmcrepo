import { NgModule, APP_INITIALIZER } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { LoginComponent } from './login/login.component';
import { AuthRoutingModule } from './auth-routing.module';
import { AuthService } from './auth.service';
import { FooterComponent } from '../footer/footer.component';
import { SsoComponent } from './sso/sso.component';

@NgModule({
  imports: [CommonModule, FormsModule, AuthRoutingModule],
  declarations: [LoginComponent, FooterComponent, SsoComponent],
  exports:[FooterComponent]
})
export class AuthModule {}
