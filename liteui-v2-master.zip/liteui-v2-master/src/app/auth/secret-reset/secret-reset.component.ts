import { EncryptionService } from './../../services/encryption.service';
import { AuthService } from './../auth.service';
import { RestService } from './../../services/rest.service';
import { Component, OnInit } from '@angular/core';
import { UntypedFormGroup, UntypedFormControl, Validators, ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { ConfigService } from '../../services/config.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-secret-reset',
  templateUrl: './secret-reset.component.html',
  styleUrls: ['./secret-reset.component.css']
})
export class SecretResetComponent implements OnInit {
  secretResetForm: UntypedFormGroup;
  isSecretMatch = false;
  isStrongPwd = false;
  isAdministrator: boolean;
  resetUserName: string;
  oldSecret: string;
  responseData: any;
  errorMessage = false;
  isSuccess = false;
  isRsa =false;

  constructor(private restService: RestService,
              private authService: AuthService,
              private configService: ConfigService,
              private router: Router,
              private encryption: EncryptionService) { }

  ngOnInit() {
    this.buildResetForm();
  }

  buildResetForm() {
    this.resetUserName = this.authService.loginMessage['4002'].substring(5);
    this.secretResetForm = new UntypedFormGroup({
      username: new UntypedFormControl('', Validators.required),
      secret: new UntypedFormControl('', Validators.required),
      enterSecret: new UntypedFormControl('', [Validators.required, this.secrectValidator()]),
      reEnterSecret: new UntypedFormControl('', [Validators.required, this.secrectValidator()])
    });
    this.secretResetForm.controls.username.patchValue(this.resetUserName);
    if (this.authService.loginMessage['4002'] === 'administrator') {
      this.isAdministrator = true;
    } else {
      this.isAdministrator = false;
    }
    this.isRsa = this.configService.config.enableRSA;

  }
  // Submit
  async onSubmit(secretResetForm: UntypedFormGroup) {
	this.isSecretMatch = false;
    this.isStrongPwd = false;
    if (secretResetForm.value.enterSecret !== secretResetForm.value.reEnterSecret || !this.checkCharacter(secretResetForm.value.enterSecret)) {
     if (!this.checkCharacter(secretResetForm.value.enterSecret)) {
        if (secretResetForm.value.enterSecret !== secretResetForm.value.reEnterSecret) {
          this.isSecretMatch = true;
          return;
        }
        else {
          this.isStrongPwd = true;
          return;
        }
      }
     if (this.checkCharacter(secretResetForm.value.enterSecret)) {
        if (secretResetForm.value.enterSecret !== secretResetForm.value.reEnterSecret) {
          this.isSecretMatch = true;
          return;
        }
      }
    }
     else {
      this.isSecretMatch = false;
      const loginMessage: any = {};
      if (this.authService.loginMessage['4002'] === 'administrator') {
        loginMessage['4001'] = this.authService.loginMessage['4002'].substring(0, 5);
        loginMessage['4002'] = this.authService.loginMessage['4002'].substring(5);
        loginMessage.H_messageName = 'M.WSS.WSXPRFS.ATOM.I';
        loginMessage.H_messageVersion = 'R00000';
      } else {
        loginMessage['4001'] = '2';
        loginMessage['4002'] = this.authService.loginMessage['4002'];
        loginMessage.H_name = this.authService.loginMessage['4002'];
        loginMessage.H_messageName = 'M.WSS.SVCSIGNON.UPD.I';
        loginMessage.H_messageVersion = 'R00000';
      }
      if (this.isRsa) {
        await this.encryption.encryptMessage(secretResetForm.value.secret);
        loginMessage['4020'] = this.encryption.ciphertext.toUpperCase();

        await this.encryption.encryptMessage(secretResetForm.value.enterSecret);
        loginMessage['4021'] = this.encryption.ciphertext.toUpperCase();

        await this.encryption.encryptMessage(secretResetForm.value.reEnterSecret);
        loginMessage['4022'] = this.encryption.ciphertext.toUpperCase();
      } else {
        loginMessage['4004'] = secretResetForm.value.secret;
        loginMessage['4006'] = secretResetForm.value.enterSecret;
        loginMessage['4007'] = secretResetForm.value.reEnterSecret;
      }


      this.restService
        .post(loginMessage).subscribe(res => {
          this.responseData = this.restService.parse(res);

          if (this.responseData.data.H_status === 'P') {
            this.isSuccess = true;
			this.errorMessage = false;
          } else {
            this.errorMessage = true;
            this.isSuccess = false;
            this.errorMessage = this.responseData.schema.properties.ERR1.title;
          }

        }
        );

    }
  }

  gotoLogin() {
      this.router.navigate(['/home']);
  }
  checkCharacter(enteredValue: string): boolean {
    const characterCheck = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
    const numCheck = /[0-9]/;
    const lowerCaseCheck = /[a-z]/;
    const upperCaseCheck = /[A-Z]/
    if (!characterCheck.test(enteredValue)) {
      return false;
    }
    if (!numCheck.test(enteredValue)) {
      return false;
    }
    if (!lowerCaseCheck.test(enteredValue)) {
      return false;
    }
    if (!upperCaseCheck.test(enteredValue)) {
      return false;
    }
    return true;
  }

secrectValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const isValid = this.checkCharacter(control.value);
    return isValid ? null : { error: { value: control.value } };
  };
}

}

