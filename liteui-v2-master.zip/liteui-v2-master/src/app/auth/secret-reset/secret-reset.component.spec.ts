import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { UntypedFormControl, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { UntypedFormGroup } from '@angular/forms';
import { ConfigService } from '../../services/config.service';
import { validUser,blankUser,secretMatch } from 'src/assets/mock/secretResetMock';
import {Config} from '../../services/config.service';
import { Component, DebugElement, Input, NgModule, NO_ERRORS_SCHEMA, OnChanges, OnDestroy, OnInit, SimpleChange, SimpleChanges } from '@angular/core';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule, By } from '@angular/platform-browser';
import { TranslatePipe } from 'src/app/translate.pipe';
import { AuthService } from './../auth.service';
import { RestService } from './../../services/rest.service';


import { SecretResetComponent } from './secret-reset.component';
import { CommonModule } from '@angular/common';

describe('SecretResetComponent', () => {
  let component: SecretResetComponent;
  let fixture: ComponentFixture<SecretResetComponent>;
  let authService:AuthService;
  let configService:ConfigService;
  let loginMessage: any = {};
  
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule, RouterTestingModule.withRoutes([]),FormsModule, ReactiveFormsModule],
      schemas: [NO_ERRORS_SCHEMA,CUSTOM_ELEMENTS_SCHEMA],
      providers:[AuthService,ConfigService],
      declarations: [SecretResetComponent]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecretResetComponent);
    component = fixture.componentInstance;
    authService=TestBed.inject(AuthService);
    configService=TestBed.inject(ConfigService);
    configService.config={
      'remoteUrl': '',
      'loginRequest': '',
      'showSearch': null,
      'menuMessage': '',
      'searchRequest': '',
      'displayDashboard':null,
      'dashboardTitle': '',
      'loginPageTitle':'',
      'documentTitle':'',
      'defaultDateFormat':'',
      'enableRSA':true,
      'profileMessage':'',
      'makerChecker':'',
      'appCodes':'',
      'selectedTheme':null,
      'themeOptions': [],
      'defaultMask':'',
      'enableMask':true,
      'maskByXref': null,
      'maskXrefRepository':[],
      'maskRepository': [],
      'formChangesLimit':null,
      'languages':[],
      'timeOutDuration': null,
      'fileSetChange': ''
    }
    //config.enableRSA=true;
    //config=TestBed.get(config.enableRSA)
    //configService.config.enableRSA=true;
    loginMessage={
      '4001':'',
      '4002':'',
      'H_messageName':''

    }
    authService.loginMessage={
      '4002': '00000ashubham'
    }

    fixture.detectChanges();
   // component.ngOnInit();
    });

  

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should verify administrator after execution of buildreset method',()=>{
    authService.loginMessage={
      '4002': 'administrator'
    }
    component.buildResetForm();
    expect(component.isAdministrator).toBe(true);

    authService.loginMessage={
      '4002': '00000ashubham'
    }

    component.buildResetForm();
    expect(component.isAdministrator).toBe(false);

  })
it('should send correct request',()=>{
  let formData = new UntypedFormGroup({
    username: new UntypedFormControl(validUser.username, Validators.required),
    secret: new UntypedFormControl(validUser.secret, Validators.required),
    enterSecret: new UntypedFormControl(secretMatch.secret, Validators.required),
    reEnterSecret: new UntypedFormControl(secretMatch.reSecret, Validators.required)
  });

  component.onSubmit(formData);
  expect(component.isSecretMatch).toBe(true);
})

it('should not have password do not match message in case of issecretMatch have false value',()=>{
  let pwdMatch=fixture.debugElement.query(By.css('#pwdNotmatch'))
  expect(pwdMatch).not.toBeTruthy();
})

it('should  have password do not match message in case of issecretMatch have true value',()=>{
  component.isSecretMatch=true;
  fixture.detectChanges();
  let pwdMatch=fixture.debugElement.query(By.css('#pwdNotmatch'))
  expect(pwdMatch).toBeTruthy();
})



it('should not have password reset message in case of issuccess have false value',()=>{
  let pwdReset=fixture.debugElement.query(By.css('#pwdReset'))
  expect(pwdReset).not.toBeTruthy();
})

it('should  have password reset message in case of issuccess have true value',()=>{
  component.isSuccess=true;
  fixture.detectChanges();
  let pwdReset=fixture.debugElement.query(By.css('#pwdReset'))
  expect(pwdReset).toBeTruthy();
})


it('should not have error message in case of erromessage have false value',()=>{
  let error=fixture.debugElement.query(By.css('#error'))
  expect(error).not.toBeTruthy();
})

it('should  have error message in case of erromessage have true value',()=>{
  component.errorMessage=true;
  fixture.detectChanges();
  let error=fixture.debugElement.query(By.css('#error'))
  expect(error).toBeTruthy();
})

it('should not have form in case of issuccess have true value',()=>{
  component.isSuccess=true;
  fixture.detectChanges();
  let resetForm=fixture.debugElement.query(By.css('#resetForm'))
  expect(resetForm).not.toBeTruthy();
})

it('should  have form in case of issuccess have false value',()=>{
  let resetForm=fixture.debugElement.query(By.css('#resetForm'))
  expect(resetForm).toBeTruthy();
})

it('should not have username in case of isAdministrator have false value',()=>{
  let userName=fixture.debugElement.query(By.css('#username'))
  expect(userName).not.toBeTruthy();
})

it('should  have username in case of isAdministrator have true value',()=>{
  component.isAdministrator=true;
  fixture.detectChanges();
  let userName=fixture.debugElement.query(By.css('#username'))
  expect(userName).toBeTruthy();
})

it('should bind the value of input to username',()=>{
  component.isAdministrator=true;
  fixture.detectChanges();
  const userName=fixture.nativeElement;
  const  userNameInput:HTMLInputElement=userName.querySelector('#username');
   userNameInput.value=validUser.username;
  userNameInput.dispatchEvent(new Event('input'));
  expect( userNameInput.value).toBe(validUser.username);
  
})


it('should bind the value of input to old password',()=>{
  const olderPwd=fixture.nativeElement;
  const  olderPwdInput:HTMLInputElement=olderPwd.querySelector('#olderPwd');
  olderPwdInput.value=validUser.password;
  olderPwdInput.dispatchEvent(new Event('input'));
  expect( olderPwdInput.value).toBe(validUser.password);
  
})

it('should bind the value of input new password',()=>{
  const newPwd=fixture.nativeElement;
  const  newPwdInput:HTMLInputElement=newPwd.querySelector('#newPwd');
  newPwdInput.value=validUser.password;
  newPwdInput.dispatchEvent(new Event('input'));
  expect( newPwdInput.value).toBe(validUser.password);
    
  })

it('should bind the value of input re enter password',()=>{
    const reEnter=fixture.nativeElement;
    const reEnterInput:HTMLInputElement=reEnter.querySelector('#reEnter');
    reEnterInput.value=secretMatch.secret;
    reEnterInput.dispatchEvent(new Event('input'));
    expect(reEnterInput.value).toBe(secretMatch.secret);
    })

it('cancel button should execute gotoLogin method on click',()=>{
      const callCheck=spyOn(component,'gotoLogin');
      let cancel=fixture.debugElement.query(By.css('#cancel'));
      cancel.triggerEventHandler(null,'click');
      expect(callCheck).toHaveBeenCalled();

  })

  it('should execute onSubmit method on form submit',()=>{
    const callCheck=spyOn(component,'onSubmit');
    let resetForm=fixture.debugElement.query(By.css('#resetForm'));
    resetForm.triggerEventHandler(null,'ngSubmit');
    expect(callCheck).toHaveBeenCalled();
  })

it('should have invalid form in the beginning',()=>{

 expect(component.secretResetForm.valid).toBeFalsy();
 
 expect(component.secretResetForm.controls['username'].valid).toBeTruthy();
 expect(component.secretResetForm.controls['secret'].valid).toBeFalsy();
 expect(component.secretResetForm.controls['enterSecret'].valid).toBeFalsy();
 expect(component.secretResetForm.controls['reEnterSecret'].valid).toBeFalsy();
})



});
