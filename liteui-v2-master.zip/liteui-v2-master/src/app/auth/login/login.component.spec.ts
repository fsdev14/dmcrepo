import { ComponentFixture, TestBed, waitForAsync,fakeAsync, async } from '@angular/core/testing';
import { FormsModule, NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { LoginComponent } from './login.component';
import { Router } from '@angular/router';
import { validUser,blankUser } from 'src/assets/mock/secretResetMock';
import { Config, ConfigService } from '../../services/config.service';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { config } from 'process';
import { AuthService } from '../auth.service';
import { RestService } from '../../services/rest.service';
import { By } from '@angular/platform-browser';
import { Location } from '@angular/common';
import path from 'path';
import { ErrorComponent } from 'src/app/error/error.component';
import { AuthGuard } from '../auth.guard';
import { HomeComponent } from 'src/app/home/home.component';
import { SecretResetComponent } from '../secret-reset/secret-reset.component';


describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let configService: ConfigService;
  let restService:RestService;
  let authService:AuthService;
  let router: Router;
  
 
  beforeEach(waitForAsync(() => {  
    TestBed.configureTestingModule({
      declarations: [ LoginComponent ],
      imports: [ HttpClientTestingModule,RouterTestingModule.withRoutes(
        [{path:'error',component:ErrorComponent},
        {
          path: 'home',
          component:HomeComponent,
          canLoad: [AuthGuard]
        },
        {
          path: 'secret',
          component: SecretResetComponent,
          canActivate: [AuthGuard]
        },
      ]),FormsModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers:[AuthService,ConfigService]
      
    })
    .compileComponents();
  }));
  

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    configService=TestBed.inject(ConfigService)
    restService=TestBed.inject(RestService)
    authService=TestBed.inject(AuthService)
    configService.config={
      'remoteUrl': '',
      'loginRequest': '',
      'showSearch': null,
      'menuMessage': '',
      'searchRequest': '',
      'displayDashboard':null,
      'dashboardTitle': '',
      'loginPageTitle':'Welcome to login Page',
      'documentTitle':'',
      'defaultDateFormat':'DD/MM/YYYY',
      'enableRSA':true,
      'profileMessage':'',
      'makerChecker':'',
      'appCodes':'',
      'selectedTheme':null,
      'themeOptions': [],
      'defaultMask':'',
      'enableMask':true,
      'maskByXref': null,
      'maskXrefRepository':[],
      'maskRepository': [],
      'formChangesLimit':null,
      'languages':[],
      'timeOutDuration': null,
      'fileSetChange': ''
    }
    
  router = TestBed.inject(Router);
  router.initialNavigation();
  authService.loginMessage={
    '4002': '00000ashubham'
  }
   
    fixture.detectChanges();
 
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have attribute type,placeholder with name client-id',()=>{
  
    const clientId1=fixture.debugElement.query(By.css('.form-control')).nativeElement;
    expect(clientId1).toBeTruthy();
    expect(clientId1.getAttribute('type')).toEqual('text');
    expect(clientId1.getAttribute('name')).toEqual('client');
    expect(clientId1.getAttribute('placeholder')).toEqual('client-id');
    
  })

  it('should have attribute type,placeholder with name username',()=>{
  
    const username=fixture.debugElement.query(By.css('#username')).nativeElement;
    expect(username).toBeTruthy();
    expect(username.getAttribute('type')).toEqual('text');
    expect(username.getAttribute('name')).toEqual('user');
    expect(username.getAttribute('placeholder')).toEqual('username');
    
  })


  it('should have attribute type,placeholder with name Password',()=>{
  
    const username=fixture.debugElement.query(By.css('#pwd')).nativeElement;
    expect(username).toBeTruthy();
    expect(username.getAttribute('type')).toEqual('password');
    expect(username.getAttribute('name')).toEqual('secret');
    expect(username.getAttribute('placeholder')).toEqual('password');
    
  })

  it('should bind the value of input client id',()=>{
    const clientIdElement=fixture.nativeElement;
    const clientInput:HTMLInputElement=clientIdElement.querySelector('#clientId');
   // fixture.detectChanges();
   const btn = fixture.debugElement.nativeElement.querySelector('#btn');
    clientInput.value='0';
    clientInput.dispatchEvent(new Event('input'));
    expect(clientInput.value).toEqual('0');
  })


  it('should bind the value of input username',()=>{
    const userNameElement=fixture.nativeElement;
    const userNameInput:HTMLInputElement=userNameElement.querySelector('#username');
   // fixture.detectChanges();
   //const btn = fixture.debugElement.nativeElement.querySelector('#btn');
   userNameInput.value=blankUser.username;
    userNameInput.dispatchEvent(new Event('input'));
     expect(userNameInput.value).toEqual(blankUser.username);
  })

  it('should bind the value of input password',()=>{
    const pwdElement=fixture.nativeElement;
    const pwdInput:HTMLInputElement=pwdElement.querySelector('#pwd');
   // fixture.detectChanges();
   //const btn = fixture.debugElement.nativeElement.querySelector('#btn');
   pwdInput.value=blankUser.secret;
    pwdInput.dispatchEvent(new Event('input'));
    expect(pwdInput.value).toEqual(blankUser.secret);
  })
  it('should have correct error message',()=>{
    component.errorMessage='error';
    fixture.detectChanges();
    let error=fixture.debugElement.query(By.css('#error'));
    expect(error.nativeElement.innerText).toBe(component.errorMessage)
  })

  it('should have correct heading',()=>{
    let heading=fixture.debugElement.query(By.css('#h3'));
    expect(heading.nativeElement.innerText).toBe(component.loginPageTitle)
  })

  it('should have is loading div in case of isloading have true value',()=>{
    component.isLoading=true;
    fixture.detectChanges();
    let loading=fixture.debugElement.query(By.css('#loading'));
    expect(loading).toBeTruthy();
  })

  it('should have is loading div in case of isloading have false value',()=>{
    let loading=fixture.debugElement.query(By.css('#loading'));
    expect(loading).not.toBeTruthy();
  })

  it('cancel button should call clear method on click',()=>{
    let cancel=fixture.debugElement.query(By.css('#cancel'));
    const callCheck=spyOn(component,'clear');
    cancel.triggerEventHandler(null,'click');
    expect(callCheck).toHaveBeenCalled();
  })

  it('should have correct error message',()=>{

    const testInput1=<NgForm>{
      value:{
        user:'0',
        client:'Ashubham',
        secret:''
      }
    }
     const event1={
       submitter:{
         name:'submit'
       }
     }
     component.verify(testInput1,event1);
    expect(component.errorMessage).toBeUndefined;
   const testInput2=<NgForm>{
     value:{
       user:'',
       client:'',
       secret:''
     }
   }
    const event2={
      submitter:{
        name:'submit'
      }
    }
    component.verify(testInput2,event2);
    expect(component.errorMessage).toEqual('Client-id is required');


    const testInput3=<NgForm>{
      value:{
        client:'test',
        secret:''
      }
    }
     const event3={
       submitter:{
         name:'submit'
       }
     }
     component.verify(testInput3,event3);
     expect(component.errorMessage).toEqual('Username is required');
  })




  

  

  
  




});
