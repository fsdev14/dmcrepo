import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Config, ConfigService } from '../../services/config.service';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { RestService } from '../../services/rest.service';
import { ErrorHandlingService } from 'src/app/services/errorHandling.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  config: Config;
  client='';
  user = '';
  secret = '';
  errorMessage: string;
  submitEnabled = false;
  loginPageTitle: string;
  isLoading = false;
  constructor(
    private configService: ConfigService,
    public authService: AuthService,
    private router: Router,
    private restService: RestService,
    private errorHandlingService: ErrorHandlingService
  ) {
  }

  ngOnInit() {
    this.config = this.configService.config;
    const lastResponse = this.restService.getLastResponse();
    if(lastResponse.schema?.properties.ERR1.title.indexOf('0027SF') > -1 || lastResponse.schema?.properties.ERR1.title.indexOf('0001EF') > -1){
      this.errorMessage = lastResponse.schema.properties.ERR1.title;
    }
    this.loginPageTitle = this.config.loginPageTitle;
    try {
      this.authService.getLoginMessage();
    } catch (error) {
      // this.router.navigate(['/error']);
      this.errorHandlingService.errorHandler(error.stack,'UIERR0002');
    }
  }

  showLoader() {
    this.isLoading = true;
  }
  verify(form: NgForm, event) {
    this.showLoader();
    this.user = form.value.user;
    this.client = form.value.client;
    this.secret = form.value.secret;
    if(event.submitter.name == 'submit'){
    if (this.client === undefined || this.client.trim().length === 0) {
      this.errorMessage = 'Client-id is required';
      return;
    }
    if (this.user === undefined || this.user.trim().length === 0) {
      this.errorMessage = 'Username is required';
      return;
    }
    this.login();
  }
  }
  login() {
    const fullUser = this.pad(this.client, 5) + this.user;

    this.authService.login(fullUser, this.secret).then(
      obj => obj.subscribe(resp => {
        try {
          const res = this.restService.parse(resp);

          if (res.schema.properties.ERR1.title.indexOf('VMES0026EF') > -1) {
            this.router.navigate(['/secret']);
            return;
          }
          this.errorMessage = this.authService.errorMessage;
          if (this.authService.isLoggedIn) {
            this.configService.globalCrossReferenceRepo.WSSCLIENT = this.configService.messageHeader.H_name.substring(0, 5);
            this.router.navigate(['/home']);
          }
        } catch (error) {
          // this.router.navigate(['/error']);
          this.errorHandlingService.errorHandler(error.stack,'UIERR0002');
        }

      }));
    this.clear();
  }

  clear() {
    this.user = '';
    this.secret = '';
    this.isLoading = false;
  }

  pad(data: string, count: number): string {
    while(data.trim().length < count) {
      data = '0'+data.trim();
    }
    return data;
  }

}
