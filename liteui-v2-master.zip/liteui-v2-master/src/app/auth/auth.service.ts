import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { tap, delay } from 'rxjs/operators';
import { Config, ConfigService } from '../services/config.service';
import { EncryptionService } from '../services/encryption.service';
import { RestService } from '../services/rest.service';
import { TranslationService } from '../services/translation.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  [x: string]: any;
  isLoggedIn = false;
  loginMessage: any;
  loginResponse: any;
  errorMessage: string;
  config: Config;
  user: string;
  secret: string;
  ssoUser: string;
  redirectUrl: string;
  messageHeader: any = {};
  typeOneUser = false;

  constructor(
    private configService: ConfigService,
    private encryptionService: EncryptionService,
    private translationService: TranslationService,
    private restService: RestService,
    private router: Router
  ) {
    this.config = this.configService.config;
    console.log(this.config);
  }

  loadPublicKey() {
    let pkeyHex = '';
    for (let i = 4010; i < 4020; i++) {
      pkeyHex = pkeyHex + this.loginMessage[i];
    }
    this.encryptionService.importKey(pkeyHex);
  }

  getLoginMessage() {
    this.configService.resetCrossReferenceRepo();
    this.configService.setMessageHeader({});
    this.configService.globalCrossReferenceRepo = { WSSCLIENT: null };
    this.restService
      .post(this.configService.getLoginRequest())
      .subscribe(x => {
        try {
          this.loginMessage = this.restService.parse(x).data;
          if (this.configService.config.ssoLogin) {
            this.ssoLogin(this.ssoUser);
          }
          if (this.config.enableRSA) { this.loadPublicKey(); }
        } catch (error) {
          this.router.navigate(['error']);
        }
      });
  }
  // store the URL so we can redirect after logging in


  async login(user: string, secret: string) {
    this.loginMessage['4001'] = '1';
    this.loginMessage['4002'] = user;
    this.loginMessage.requestType = "loginRequest";
    if (this.config.enableRSA) {
      await this.encryptionService.encryptMessage(secret);
      this.loginMessage['4020'] = this.encryptionService.ciphertext.toUpperCase();
      this.loginMessage.enableRSA = this.config.enableRSA;
    } else if (this.config.secretEncryption && !this.config.enableRSA) {
      this.loginMessage['4020'] = this.encryptionService.encryptWithPublicKey(secret);
      this.loginMessage.enableRSA = this.config.enableRSA;
    } else {
      this.loginMessage['4004'] = secret;
    }

    this.loginMessage.H_name = user;
    this.restService.user = user;
    return this.restService
      .post(this.loginMessage).pipe(
        tap(x => this.processResponse(x))
      );
  }

  logout(): any {
  let logoutReq = { ...this.configService.getLoginRequest() };
    logoutReq['4001'] = '0';
    logoutReq['4002'] = this.configService.messageHeader.H_name;
    logoutReq['4003'] = this.configService.messageHeader.H_context;
    logoutReq['4004'] = '';
    logoutReq['4005'] = '';
    logoutReq['4006'] = '';
    logoutReq['4007'] = '';
    logoutReq['4008'] = '';
    logoutReq['4009'] = '';
    return this.restService
      .post(logoutReq).subscribe(x => {
        this.restService.parse(x);
        this.isLoggedIn = false;
        this.messageHeader = {};
        this.configService.setMessageHeader({});
      });
  }

  processResponse(resp: any) {
    this.loginResponse = this.restService.parse(resp);
    if (this.loginResponse.data?.['5007'] == 1) {
      this.typeOneUser = true;
    }
    else {
      this.typeOneUser = false;
    }
    if (this.loginResponse.data === undefined || this.loginResponse.data.H_status === 'F') {
      this.errorMessage = this.loginResponse.schema.properties.ERR1.title;
      if (this.errorMessage.indexOf('VMES0026EF') >= 0) {
        this.isLoggedIn = true;
        this.restService.loginStateValid = true;
      }
    } else {
      this.isLoggedIn = true;
      this.restService.loginStateValid = true;
      this.messageHeader.H_name = this.loginResponse.data.H_name;
      this.messageHeader.H_context = this.loginResponse.data['5001'];
      this.configService.setMessageHeader(this.messageHeader);
      this.configService.setMasking(this.loginResponse.data['5008'] !== 'N');
    }
  }
  async setSsoParams(userData: string) {
    this.ssoUser = userData;
    await this.getLoginMessage();
  }

  ssoLogin(ssoUser: string) {
    this.login(ssoUser, '').then(
      obj => obj.subscribe(resp => {
        try {
          this.configService.globalCrossReferenceRepo.WSSCLIENT = this.configService.messageHeader.H_name.substring(0, 5);
          this.router.navigate(['/home']);

        } catch (error) {
          this.router.navigate(['/error']);
          this.errorHandlingService.errorHandler(error.stack, 'UIERR0002');
        }

      }));
  }
  isloggedInstateValid() {
    return this.restService.loginStateValid;
  }

}
