import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfigService } from 'src/app/services/config.service';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-sso',
  templateUrl: './sso.component.html',
  styleUrls: ['./sso.component.css']
})
export class SsoComponent implements OnInit {

  constructor(private route: ActivatedRoute, private authService: AuthService,
    private configService: ConfigService,
    private router: Router) {
    if (!this.configService.config.ssoLogin) {
      this.router.navigate(["login"]);
    }
    this.route.params.subscribe((params) => {
      this.authService.setSsoParams(params.username);
    })
   }

  ngOnInit(): void {
  }

}
