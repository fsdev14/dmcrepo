import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth.guard';

import { LoginComponent } from './login/login.component';
import { SecretResetComponent } from './secret-reset/secret-reset.component';

const authRoutes: Routes = [{ path: 'login', component: LoginComponent },
  { path: 'secret', component: SecretResetComponent, canActivate: [AuthGuard] }
];

@NgModule({
  imports: [RouterModule.forChild(authRoutes)],
  exports: [RouterModule]
})
export class AuthRoutingModule {}
