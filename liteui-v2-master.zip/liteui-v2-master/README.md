# LiteUI version 2

## Developer Setup

### Install Dependencies

After cloning the repository, run

`npm install`

This will install all the dependant libraries. Angular version is 13.3.5. You will need NPM and nodejs versions that match this angular version. Please visit [angular.io](https://angular.io/) for further details.

## Build

To build LiteUI please run the following command

`ng build`

To build and start LiteUI, run the following command at localhost:4200

`ng serve`

## Build for Production

To build for production deployment run the command:

`ng buildprod`

This will compile LiteUI with --aot and production environment flags. This compile output will be available in the `dist` directory.

## Deployment Configuration

LiteUI has the following configurable items in the config.json file in assets.

1. `remoteUrl`  
This is the path to the DMC endpoint. Ex: <https://example.com/ds1odmc>.\
    __Note: Browsers may block cross-origin requests if the LiteUI server hostname and DMC hostname dont match.__

2. `loginRequest`  
This is the login message name and version LiteUI will use to login to the WSS. Even though the message name and version are in the configuration file, this should not change without change the Auth Service in LiteUI

3. `makerChecker`  
`selectValue` points to the field that displays the metadata for Field Security Maker Checker Page.

4. `appCodes`  
These are Standard VisionPLUS application and file codes. You can add your own application codes if you have any custom Vision applications.  

5. `showSearch`  
Flag that turns on or off the Search function on LiteUI. Default value is `true`.  

6. `menuMessage`  
Message that retrieves list of message the user has access to. LiteUI sends the username and client name by default along with the request.  

7. `searchRequest`  
Message used by DMC to trigger Field search. Response format is same as `menuMessage` response.

8. `displayDashboard` __Deprecated__  
Flag to turn the Dashboard on or off. Default is `false`.

9. `dashboardTitle`  
Title to display on the dashboard

10. `loginPageTitle`  
Title to display on Login Page

11. `documentTitle`  
Title to display on the browser tab/window.

12. `defaultDateFormat`  
Date format to use while displaying dates. Default is `DD/MM/YYYY`

13. `enableRSA`  
Turn on or off RSA encryption for passwords. Encryption public key to be provided in the loginRequest

14. `ssoLogin`  
Turn on or off SSO Login. If true, login screen will be bypassed. SSO service is expected to redirect to https://liteui/#/user/\<username\>.  
If this flag is false and user tries to access this url, user will be redirected to login page. 

15. `profileMessage`  
Message to load/update user profile.

16. `timeOutDuration`  
Time in minutes LiteUI will use to keep the user session active before automatically logging off.

17. `fileSetChange`  
Message that provides FileSet change functions.

18. `themeOptions`  
User selectable UI themes configuration. This is the repository the defines what colours to use to render the various aspects of LiteUI

19. `languages`  
Languages supported by LiteUI and the paths to the translation files. Translation files are to be placed in assets/lang directory.

20. `defaultMask`  
The default masking string to use when masking is turned on in the user profile.

21. `enableMask`  
Flag that turns masking on or off.

22. `maskByXref`  
Flag that directs LiteUI masking to use the XREF or static description to select fields to mask.

23. `maskXrefRepository`  
Repository of XREFs/static descriptions and their masking strings to select fields to mask.

24. `maskRepository` __Deprecated__  
Deprecated repository of fields and messages to select for masking.

25. `formChangesLimit`  
The number of field changes that Add forms will allow before reminding user to Save.

26. `documentationFormat`  
Format of the documentation files. Default is json. If documentation files are in PDF format, please set this value to pdf. 

27. `documentationRepository`  
This is the URL to documentation repository if hosted externally. This has to be the direct path to the location where documentation PDFs are hosted. Default value is default which looks for PDFs in assets/docs/ relative to current LiteUI installation.
